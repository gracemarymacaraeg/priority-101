﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LMTFBP
{
    public partial class bHomepage : Form
    {
        public bHomepage()
        {
            InitializeComponent();
        }

        private void AddNew_Click(object sender, EventArgs e)
        {
            var uc1 = new businessApplication();
            panel3.Controls.Clear();
            panel3.Controls.Add(uc1);
        }

        private void ViewRecords_Click(object sender, EventArgs e)
        {
            var uc1 = new tViewRecords();
            var uc2 = new bRecords();
            panel3.Controls.Clear();
            panel3.Controls.Add(uc1);
            uc1.panel2.Controls.Clear();
            uc1.panel2.Controls.Add(uc2);
            uc1.NewRecords.Text = "New Permit Record";
            uc1.bunifuFlatButton1.Text = "Renew permit Record";
            uc1.bunifuFlatButton2.Text = "Archive Permit Record";
            uc1.ExpiredBtn.Visible = false;
        }

        private void LogOut_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Sure to Logout?", "Warning!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }

        }

        private void bHomepage_Load(object sender, EventArgs e)
        {
            if (Search.text == "")
            {
                SearchBtn.Visible = false;
            }
            else
            {
                SearchBtn.Visible = true;
            }

            if (uTypeLbl.Text == "Admin")
            {
                AddNew.Visible = false;
                bunifuFlatButton3.Visible = true;
            }
            else
            {
                AddNew.Visible = true;
                bunifuFlatButton3.Visible = false;
            }
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            var uc1 = new Account();
            panel3.Controls.Clear();
            panel3.Controls.Add(uc1);
            uc1.pending.Text = "Pending Lists";
            uc1.NewRecords.Text = "Approved Lists";
        }
    }
}
