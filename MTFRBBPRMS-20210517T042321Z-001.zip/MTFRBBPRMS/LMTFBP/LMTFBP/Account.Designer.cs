﻿namespace LMTFBP
{
    partial class Account
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Account));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3 = new System.Windows.Forms.Panel();
            this.TypeCB = new System.Windows.Forms.ComboBox();
            this.DeptCB = new System.Windows.Forms.ComboBox();
            this.repassTB = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.bdayDTP = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.pass = new System.Windows.Forms.TextBox();
            this.userTB = new System.Windows.Forms.TextBox();
            this.contactTB = new System.Windows.Forms.TextBox();
            this.genderCB = new System.Windows.Forms.ComboBox();
            this.suffixTB = new System.Windows.Forms.TextBox();
            this.lnameTB = new System.Windows.Forms.TextBox();
            this.mnameTB = new System.Windows.Forms.TextBox();
            this.fnameTB = new System.Windows.Forms.TextBox();
            this.Usertype = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.IDtb = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.NewRecords = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pending = new Bunifu.Framework.UI.BunifuFlatButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(192, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(10, 550);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Location = new System.Drawing.Point(200, 30);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(969, 10);
            this.panel2.TabIndex = 7;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(210, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 18);
            this.label1.TabIndex = 6;
            this.label1.Text = "Account List.";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column7,
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column6,
            this.Column4,
            this.Column5,
            this.Column8});
            this.dataGridView1.Location = new System.Drawing.Point(208, 46);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(372, 357);
            this.dataGridView1.TabIndex = 8;
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column7.HeaderText = "ID";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 43;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "First Name";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Middle Name";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Last Name";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Suffix";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Birthday";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Gender";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Contact No.";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.TypeCB);
            this.panel3.Controls.Add(this.DeptCB);
            this.panel3.Controls.Add(this.repassTB);
            this.panel3.Controls.Add(this.checkBox1);
            this.panel3.Controls.Add(this.bdayDTP);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.pass);
            this.panel3.Controls.Add(this.userTB);
            this.panel3.Controls.Add(this.contactTB);
            this.panel3.Controls.Add(this.genderCB);
            this.panel3.Controls.Add(this.suffixTB);
            this.panel3.Controls.Add(this.lnameTB);
            this.panel3.Controls.Add(this.mnameTB);
            this.panel3.Controls.Add(this.fnameTB);
            this.panel3.Controls.Add(this.Usertype);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.IDtb);
            this.panel3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(586, 46);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(582, 357);
            this.panel3.TabIndex = 33;
            // 
            // TypeCB
            // 
            this.TypeCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TypeCB.Font = new System.Drawing.Font("Arial", 9.75F);
            this.TypeCB.FormattingEnabled = true;
            this.TypeCB.Location = new System.Drawing.Point(169, 222);
            this.TypeCB.Name = "TypeCB";
            this.TypeCB.Size = new System.Drawing.Size(137, 24);
            this.TypeCB.TabIndex = 71;
            // 
            // DeptCB
            // 
            this.DeptCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DeptCB.Font = new System.Drawing.Font("Arial", 9.75F);
            this.DeptCB.FormattingEnabled = true;
            this.DeptCB.Items.AddRange(new object[] {
            "Office of the Mayor",
            "Licensing Office",
            "Treasury Office"});
            this.DeptCB.Location = new System.Drawing.Point(15, 222);
            this.DeptCB.Name = "DeptCB";
            this.DeptCB.Size = new System.Drawing.Size(137, 24);
            this.DeptCB.TabIndex = 70;
            this.DeptCB.SelectedIndexChanged += new System.EventHandler(this.DeptCB_SelectedIndexChanged);
            // 
            // repassTB
            // 
            this.repassTB.Location = new System.Drawing.Point(324, 167);
            this.repassTB.Name = "repassTB";
            this.repassTB.Size = new System.Drawing.Size(137, 22);
            this.repassTB.TabIndex = 69;
            this.repassTB.UseSystemPasswordChar = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(467, 170);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(108, 18);
            this.checkBox1.TabIndex = 68;
            this.checkBox1.Text = "Show Password";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // bdayDTP
            // 
            this.bdayDTP.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bdayDTP.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.bdayDTP.Location = new System.Drawing.Point(15, 103);
            this.bdayDTP.Name = "bdayDTP";
            this.bdayDTP.Size = new System.Drawing.Size(137, 22);
            this.bdayDTP.TabIndex = 67;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(321, 149);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(107, 15);
            this.label13.TabIndex = 66;
            this.label13.Text = "Re-type Password:";
            // 
            // pass
            // 
            this.pass.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pass.Location = new System.Drawing.Point(169, 167);
            this.pass.Name = "pass";
            this.pass.Size = new System.Drawing.Size(137, 22);
            this.pass.TabIndex = 65;
            this.pass.UseSystemPasswordChar = true;
            // 
            // userTB
            // 
            this.userTB.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userTB.Location = new System.Drawing.Point(15, 167);
            this.userTB.Name = "userTB";
            this.userTB.Size = new System.Drawing.Size(137, 22);
            this.userTB.TabIndex = 64;
            // 
            // contactTB
            // 
            this.contactTB.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactTB.Location = new System.Drawing.Point(324, 107);
            this.contactTB.Name = "contactTB";
            this.contactTB.Size = new System.Drawing.Size(137, 22);
            this.contactTB.TabIndex = 63;
            // 
            // genderCB
            // 
            this.genderCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.genderCB.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genderCB.FormattingEnabled = true;
            this.genderCB.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.genderCB.Location = new System.Drawing.Point(169, 105);
            this.genderCB.Name = "genderCB";
            this.genderCB.Size = new System.Drawing.Size(137, 24);
            this.genderCB.TabIndex = 62;
            // 
            // suffixTB
            // 
            this.suffixTB.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.suffixTB.Location = new System.Drawing.Point(478, 47);
            this.suffixTB.Name = "suffixTB";
            this.suffixTB.Size = new System.Drawing.Size(97, 22);
            this.suffixTB.TabIndex = 61;
            // 
            // lnameTB
            // 
            this.lnameTB.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnameTB.Location = new System.Drawing.Point(324, 47);
            this.lnameTB.Name = "lnameTB";
            this.lnameTB.Size = new System.Drawing.Size(137, 22);
            this.lnameTB.TabIndex = 60;
            // 
            // mnameTB
            // 
            this.mnameTB.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnameTB.Location = new System.Drawing.Point(169, 47);
            this.mnameTB.Name = "mnameTB";
            this.mnameTB.Size = new System.Drawing.Size(137, 22);
            this.mnameTB.TabIndex = 59;
            // 
            // fnameTB
            // 
            this.fnameTB.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fnameTB.Location = new System.Drawing.Point(15, 47);
            this.fnameTB.Name = "fnameTB";
            this.fnameTB.Size = new System.Drawing.Size(137, 22);
            this.fnameTB.TabIndex = 58;
            // 
            // Usertype
            // 
            this.Usertype.AutoSize = true;
            this.Usertype.Location = new System.Drawing.Point(166, 204);
            this.Usertype.Name = "Usertype";
            this.Usertype.Size = new System.Drawing.Size(59, 15);
            this.Usertype.TabIndex = 57;
            this.Usertype.Text = "Usertype:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 204);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 15);
            this.label12.TabIndex = 56;
            this.label12.Text = "Department:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(166, 149);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 15);
            this.label11.TabIndex = 55;
            this.label11.Text = "Password:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 149);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 15);
            this.label10.TabIndex = 54;
            this.label10.Text = "Username:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(321, 87);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 15);
            this.label9.TabIndex = 53;
            this.label9.Text = "Contact No.:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(166, 87);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 15);
            this.label7.TabIndex = 52;
            this.label7.Text = "Gender:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 15);
            this.label6.TabIndex = 51;
            this.label6.Text = "Birthday:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(475, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 15);
            this.label5.TabIndex = 50;
            this.label5.Text = "Suffix:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(321, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 15);
            this.label4.TabIndex = 49;
            this.label4.Text = "Last Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(166, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 15);
            this.label3.TabIndex = 48;
            this.label3.Text = "Middle Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 15);
            this.label2.TabIndex = 47;
            this.label2.Text = "First Name:";
            // 
            // IDtb
            // 
            this.IDtb.Location = new System.Drawing.Point(467, 305);
            this.IDtb.Name = "IDtb";
            this.IDtb.Size = new System.Drawing.Size(100, 22);
            this.IDtb.TabIndex = 46;
            this.IDtb.Visible = false;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(452, 409);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 32);
            this.button1.TabIndex = 34;
            this.button1.Text = "View Information";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(318, 409);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(128, 32);
            this.button4.TabIndex = 35;
            this.button4.Text = "Refresh List";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button2
            // 
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(1046, 409);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(123, 32);
            this.button2.TabIndex = 36;
            this.button2.Text = "Approved Account";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(1046, 447);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(123, 32);
            this.button3.TabIndex = 37;
            this.button3.Text = "Remove Account";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // NewRecords
            // 
            this.NewRecords.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.NewRecords.BackColor = System.Drawing.Color.Transparent;
            this.NewRecords.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.NewRecords.BorderRadius = 0;
            this.NewRecords.ButtonText = "Approved Accounts";
            this.NewRecords.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NewRecords.DisabledColor = System.Drawing.Color.Gray;
            this.NewRecords.ForeColor = System.Drawing.Color.Black;
            this.NewRecords.Iconcolor = System.Drawing.Color.Transparent;
            this.NewRecords.Iconimage = null;
            this.NewRecords.Iconimage_right = null;
            this.NewRecords.Iconimage_right_Selected = null;
            this.NewRecords.Iconimage_Selected = null;
            this.NewRecords.IconMarginLeft = 0;
            this.NewRecords.IconMarginRight = 0;
            this.NewRecords.IconRightVisible = true;
            this.NewRecords.IconRightZoom = 0D;
            this.NewRecords.IconVisible = true;
            this.NewRecords.IconZoom = 40D;
            this.NewRecords.IsTab = false;
            this.NewRecords.Location = new System.Drawing.Point(9, 30);
            this.NewRecords.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.NewRecords.Name = "NewRecords";
            this.NewRecords.Normalcolor = System.Drawing.Color.Transparent;
            this.NewRecords.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.NewRecords.OnHoverTextColor = System.Drawing.Color.Black;
            this.NewRecords.selected = false;
            this.NewRecords.Size = new System.Drawing.Size(177, 35);
            this.NewRecords.TabIndex = 38;
            this.NewRecords.Text = "Approved Accounts";
            this.NewRecords.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NewRecords.Textcolor = System.Drawing.Color.Black;
            this.NewRecords.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewRecords.Click += new System.EventHandler(this.NewRecords_Click);
            // 
            // pending
            // 
            this.pending.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.pending.BackColor = System.Drawing.Color.Transparent;
            this.pending.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pending.BorderRadius = 0;
            this.pending.ButtonText = "Pending Accounts";
            this.pending.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pending.DisabledColor = System.Drawing.Color.Gray;
            this.pending.ForeColor = System.Drawing.Color.Black;
            this.pending.Iconcolor = System.Drawing.Color.Transparent;
            this.pending.Iconimage = null;
            this.pending.Iconimage_right = null;
            this.pending.Iconimage_right_Selected = null;
            this.pending.Iconimage_Selected = null;
            this.pending.IconMarginLeft = 0;
            this.pending.IconMarginRight = 0;
            this.pending.IconRightVisible = true;
            this.pending.IconRightZoom = 0D;
            this.pending.IconVisible = true;
            this.pending.IconZoom = 40D;
            this.pending.IsTab = false;
            this.pending.Location = new System.Drawing.Point(9, 73);
            this.pending.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pending.Name = "pending";
            this.pending.Normalcolor = System.Drawing.Color.Transparent;
            this.pending.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.pending.OnHoverTextColor = System.Drawing.Color.Black;
            this.pending.selected = false;
            this.pending.Size = new System.Drawing.Size(177, 35);
            this.pending.TabIndex = 38;
            this.pending.Text = "Pending Accounts";
            this.pending.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.pending.Textcolor = System.Drawing.Color.Black;
            this.pending.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pending.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.pending);
            this.Controls.Add(this.NewRecords);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "Account";
            this.Size = new System.Drawing.Size(1169, 548);
            this.Load += new System.EventHandler(this.Account_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.DataGridView dataGridView1;
        public System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        public System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        public System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        public System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        public System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        public System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        public System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        public System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        public System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.ComboBox TypeCB;
        public System.Windows.Forms.ComboBox DeptCB;
        public System.Windows.Forms.TextBox repassTB;
        public System.Windows.Forms.CheckBox checkBox1;
        public System.Windows.Forms.DateTimePicker bdayDTP;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.TextBox pass;
        public System.Windows.Forms.TextBox userTB;
        public System.Windows.Forms.TextBox contactTB;
        public System.Windows.Forms.ComboBox genderCB;
        public System.Windows.Forms.TextBox suffixTB;
        public System.Windows.Forms.TextBox lnameTB;
        public System.Windows.Forms.TextBox mnameTB;
        public System.Windows.Forms.TextBox fnameTB;
        public System.Windows.Forms.Label Usertype;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox IDtb;
        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.Button button4;
        public System.Windows.Forms.Button button2;
        public System.Windows.Forms.Button button3;
        public Bunifu.Framework.UI.BunifuFlatButton NewRecords;
        public Bunifu.Framework.UI.BunifuFlatButton pending;
    }
}
