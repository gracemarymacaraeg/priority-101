﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class UpdateArchive : UserControl
    {
        MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public UpdateArchive()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
            label33.Text = DateTime.Now.ToShortDateString();
            label35.Text = DateTime.Now.ToString("yyyy");
        }

        private void UpdateArchive_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Start();
            label33.Text = DateTime.Now.ToShortDateString();
            label35.Text = DateTime.Now.ToString("yyyy");
            if (textBox2.Text == "Renewal")
            {
                con.Open();
                com = con.CreateCommand();
                com.CommandText = " SELECT * FROM t_amotor WHERE Applicant_ID LIKE '" + textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    Make.Text = reader[2].ToString();
                    Model.Text = reader[3].ToString();
                    MotorNo.Text = reader[4].ToString();
                    ChassisNo.Text = reader[5].ToString();
                    PlateNo.Text = reader[6].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM t_archive WHERE Applicant_ID LIKE '" + textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    Toda.Text = reader[17].ToString();
                    Position.Text = reader[18].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = " SELECT * FROM t_afranchise WHERE Applicant_ID LIKE '" + textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    CaseNo.Text = reader[2].ToString();
                    StartDTP.Text = reader[4].ToString();
                    EndDTP.Text = reader[4].ToString();
                    NoUnits.Text = reader[5].ToString();
                    OwnerType.Text = reader[6].ToString();
                    OtherType.Text = reader[7].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                GETmaxID();
                con.Open();
                com = con.CreateCommand();
                com.CommandText = " SELECT * FROM t_amotor WHERE Applicant_ID LIKE '" + textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    Make.Text = reader[2].ToString();
                    Model.Text = reader[3].ToString();
                    MotorNo.Text = reader[4].ToString();
                    ChassisNo.Text = reader[5].ToString();
                    PlateNo.Text = reader[6].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM t_archive WHERE Applicant_ID LIKE '" + textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    Toda.Text = reader[17].ToString();
                    Position.Text = reader[18].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = " SELECT * FROM t_afranchise WHERE Applicant_ID LIKE '" + textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    CaseNo.Text = reader[2].ToString();
                    StartDTP.Text = reader[4].ToString();
                    EndDTP.Text = reader[4].ToString();
                    NoUnits.Text = reader[5].ToString();
                    OwnerType.Text = reader[6].ToString();
                    OtherType.Text = reader[7].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();
                con.Close();
            }
        }
        public void GETmaxID()
        {
            string proID;
            string query = "SELECT Applicant_ID FROM t_renew ORDER BY Applicant_ID desc";

            con.Open();
            MySqlCommand com = new MySqlCommand(query, con);
            MySqlDataReader dr = com.ExecuteReader();

            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                proID = id.ToString("0");
            }
            else if (Convert.IsDBNull(dr))
            {
                proID = ("1");
            }
            else
            {
                proID = ("1");
            }
            con.Close();

            AppNo.Text = proID.ToString();
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (Lname.Text == "")
            {
                MessageBox.Show("Input Last Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (Fname.Text == "")
            {
                MessageBox.Show("Input First Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (MI.Text == "")
            {
                MessageBox.Show("Input Middle Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (Brgy.Text == "")
            {
                MessageBox.Show("Input Barangay", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (City.Text == "")
            {
                MessageBox.Show("Input City/Municipality", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (EndDTP.Text == StartDTP.Text)
            {
                MessageBox.Show("Indentify the range of Validity", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                DialogResult result = MessageBox.Show("Information Complete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    renewal();
                    Delete();
                    print();
                    clear();
                }
            }
        }
        public void renewal()
        {
            con.Open();
            com = con.CreateCommand();
            com.CommandText = "INSERT into t_renew (Applicant_ID, Applicant_Type, Lname, Fname, Mname, Suffix, Gender, House_No, Street, Brgy, City, Province, Contact, Citizenship, Dual_Ctzn, License_No, Toda, Position, Start_Val, End_Val) VALUES ('" +
                AppNo.Text + "','" + AppType.Text + "','" + Lname.Text + "','" + Fname.Text + "','" + MI.Text + "','" + Suff.Text + "','" +
                Gender.Text + "','" + HouseNo.Text + "','" + Street.Text + "','" + Brgy.Text + "','" + City.Text + "','" + Province.Text + "','" +
                ContactNo.Text + "','" + Citizenship.Text + "','" + DualCtzn.Text + "','" + LicenseNo.Text + "','" + Toda.Text + "','" +
                Position.Text + "','" + StartDTP.Text + "','" + EndDTP.Text + "')";
            com.ExecuteNonQuery();

            com.CommandText = "INSERT into t_rmotor (Applicant_ID, Make, Model, Motor_No, Chassis_No, Plate_No) VALUES ('" +
                AppNo.Text + "','" + Make.Text + "','" + Model.Text + "','" + MotorNo.Text + "','" +
                ChassisNo.Text + "','" + PlateNo.Text + "')";
            com.ExecuteNonQuery();

            com.CommandText = "INSERT into t_rfranchise (Applicant_ID, Case_No, Start_Val, End_Val, No_Unit, Owner_Type, Other_Type) VALUES ('" +
                AppNo.Text + "','" + CaseNo.Text + "','" + StartDTP.Text + "','" + EndDTP.Text + "','" + NoUnits.Text + "','" +
                OwnerType.Text + "','" + OtherType.Text + "')";
            com.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Save Complete! Ready to Print", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        public void Delete()
        {
            
           
                con.Open();
                com = con.CreateCommand();
                com.CommandText = "DELETE FROM t_archive WHERE Applicant_ID = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM t_amotor WHERE Applicant_ID = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM t_afranchise WHERE Applicant_ID = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();
                con.Close();
            
        }
        public void clear()
        {
            Fname.ResetText();
            MI.ResetText();
            Lname.ResetText();
            Suff.ResetText();
            Gender.Items.Clear();
            Gender.Items.Add("Male");
            Gender.Items.Add("Female");
            HouseNo.ResetText();
            Street.ResetText();
            Brgy.ResetText();
            City.ResetText();
            ContactNo.ResetText();
            Citizenship.ResetText();
            DualCtzn.ResetText();
            LicenseNo.ResetText();
            Make.ResetText();
            Model.ResetText();
            MotorNo.ResetText();
            ChassisNo.ResetText();
            PlateNo.ResetText();
            Toda.ResetText();
            Position.Items.Clear();
            Position.Items.Add("President");
            Position.Items.Add("Vice-President");
            Position.Items.Add("Secretary");
            Position.Items.Add("Tresurer");
            Position.Items.Add("Auditor");
            Position.Items.Add("Chairman");
            Position.Items.Add("Board member");
            Position.Items.Add("Member");
            Position.Items.Add("None");
            CaseNo.ResetText();
            EndDTP.ResetText();
            NoUnits.ResetText();
            OwnerType.Items.Clear();
            OwnerType.Items.Add("Single Proprietorship");
            OwnerType.Items.Add("Cooperative");
            OwnerType.Items.Add("Corporation");
            OwnerType.Items.Add("Others...");
            OtherType.ResetText();
        }
        public void print()
        {
            PrintPreviewDialog dlg = new PrintPreviewDialog();
            dlg.PrintPreviewControl.Zoom = 1.0;
            dlg.Document = printDocument1;
            printDocument1.PrinterSettings.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("210 x 279 mm", 800, 800);
            //this.printDocument1.DefaultPageSettings.Landscape = true;
            dlg.ShowDialog();

            print2();
        }

        public void print2()
        {
            PrintPreviewDialog dlg = new PrintPreviewDialog();
            dlg.PrintPreviewControl.Zoom = 1.0;
            dlg.Document = printDocument2;
            printDocument2.PrinterSettings.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("210 x 279 mm", 800, 800);
            //this.printDocument1.DefaultPageSettings.Landscape = true;
            dlg.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(Properties.Resources.Logo, 100, 40, 80, 80);
            e.Graphics.DrawString("Republic of the Philippines", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(345, 60));
            e.Graphics.DrawString("Province of Laguna", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(370, 80));
            e.Graphics.DrawString("Municipality of Lumban", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(355, 100));
            e.Graphics.DrawString("MUNICIPAL TRICYCLE FRANCHISING AND REGULATORY BOARD", new Font("Calibri", 12, FontStyle.Italic), Brushes.Black, new Point(220, 130));
            e.Graphics.DrawString("TRICYCLE FRANCHISE APPLICATION", new Font("Calibri", 13, FontStyle.Bold), Brushes.Black, new Point(300, 160));
            e.Graphics.DrawString("Applicant No.: ____________________", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(75, 200));
            e.Graphics.DrawString(AppNo.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(200, 200));
            e.Graphics.DrawString("Date: ____________________", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(552, 200));
            e.Graphics.DrawString(label33.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(600, 198));
            e.Graphics.DrawString("[  ] New     [  ] Renewal", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(552, 220));
            e.Graphics.DrawString("Name of Applicant: _________________________________________________________________", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(75, 260));
            e.Graphics.DrawString(Lname.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(260, 255));
            e.Graphics.DrawString(Fname.Text + " " + Suff.Text + "", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(440, 255));
            e.Graphics.DrawString(MI.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(650, 255));
            e.Graphics.DrawString("(Family Name)", new Font("Calibri", 10, FontStyle.Italic), Brushes.Black, new Point(265, 280));
            e.Graphics.DrawString("(Given Name)", new Font("Calibri", 10, FontStyle.Italic), Brushes.Black, new Point(440, 280));
            e.Graphics.DrawString("(Middle Initial)", new Font("Calibri", 10, FontStyle.Italic), Brushes.Black, new Point(615, 280));
            e.Graphics.DrawString("Address:", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(74, 310));
            e.Graphics.DrawString("__________________________________________________________________________", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(142, 310));
            e.Graphics.DrawString(HouseNo.Text + " " + Street.Text + " st., Brgy. " + Brgy.Text + " " + City.Text + ", " + Province.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(230, 305));
            e.Graphics.DrawString("(House No./Street/Barangay/Municipality/Province)", new Font("Calibri", 10, FontStyle.Italic), Brushes.Black, new Point(275, 330));
            e.Graphics.DrawString("Citizenship: ________________________________", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(75, 360));
            e.Graphics.DrawString(Citizenship.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(200, 355));
            e.Graphics.DrawString("Others (Specify) _________________________", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(433, 360));
            e.Graphics.DrawString(DualCtzn.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(550, 355));
            e.Graphics.DrawString("Primary Occupation:", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(75, 400));
            e.Graphics.DrawString("________________________________________________________________", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(225, 400));
            e.Graphics.DrawString("TRICYCLE OPERATOR/DRIVER", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(325, 395));
            e.Graphics.DrawString("(If employed, state name of employer and address)", new Font("Calibri", 10, FontStyle.Italic), Brushes.Black, new Point(330, 420));
            e.Graphics.DrawString("Type of Ownership", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(75, 450));
            e.Graphics.DrawString("[  ] Single Proprietorship", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(250, 470));
            e.Graphics.DrawString("[  ] Cooperative", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(250, 490));
            e.Graphics.DrawString("[  ] Corporation", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(450, 470));
            e.Graphics.DrawString("[  ] Others, specify", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(450, 490));
            e.Graphics.DrawString(OtherType.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(600, 490));
            e.Graphics.DrawString("______________________", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(577, 490));
            e.Graphics.DrawString("Number of unit(s) Applied:  __________", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 530));
            e.Graphics.DrawString(NoUnits.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(300, 530));
            e.Graphics.DrawString("Description of Unit(s)", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 550));
            e.Graphics.DrawString("MAKE", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(130, 580));
            e.Graphics.DrawString(Make.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(130, 600));
            e.Graphics.DrawString("MODEL", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(240, 580));
            e.Graphics.DrawString(Model.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(240, 600));
            e.Graphics.DrawString("MOTOR NO.", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(355, 580));
            e.Graphics.DrawString(MotorNo.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(355, 600));
            e.Graphics.DrawString("CHASSIS NO.", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(500, 580));
            e.Graphics.DrawString(ChassisNo.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(500, 600));
            e.Graphics.DrawString("PLATE NO.", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(650, 580));
            e.Graphics.DrawString(PlateNo.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(650, 600));
            e.Graphics.DrawString("Checked and Inspected by", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 650));
            e.Graphics.DrawString("____________________________________________________________", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(259, 650));
            e.Graphics.DrawString("IMELDA M. HERNANDEZ", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(550, 645));
            e.Graphics.DrawString("Acting Municipal Treasurer", new Font("Calibri", 12, FontStyle.Italic), Brushes.Black, new Point(550, 670));
            e.Graphics.DrawString("(Chief of Police/MTFRB Representative)", new Font("Calibri", 10, FontStyle.Italic), Brushes.Black, new Point(280, 670));
            e.Graphics.DrawString("Findings/Recommendation", new Font("Calibri", 12, FontStyle.Italic), Brushes.Black, new Point(75, 705));
            e.Graphics.DrawString("____________________________________________________________", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(259, 707));
            e.Graphics.DrawString("APPLICATION FOR FRANCHISE", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(400, 705));
            e.Graphics.DrawString("__________________________________________________________________________________", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 730));
            e.Graphics.DrawString("I HEREBY CERTIFY that all the information given above, as well as the information", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(155, 775));
            e.Graphics.DrawString("contained in the attachments to this application are true and correct.  I acknowledge also that", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 795));
            e.Graphics.DrawString("any misrepresentation on my part maybe grounded for the disapproval of this application and/", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 815));
            e.Graphics.DrawString("or revocation of the Provisional Authority that maybe granted.", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 835));
            e.Graphics.DrawString("_________________________", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(552, 870));
            e.Graphics.DrawString("(Applicant's Name and Signature)", new Font("Calibri", 10, FontStyle.Bold), Brushes.Black, new Point(555, 890));
            e.Graphics.DrawString(Fname.Text + " " + MI.Text + " " + Lname.Text + " " + Suff.Text + "", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(565, 868));
            e.Graphics.DrawString("SUBSCRIBED AND SWORN to before me this _______ day of ____________, ", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(155, 920));
            e.Graphics.DrawString(label35.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(680, 920));
            e.Graphics.DrawString("Affiant exhibiting his/her CTC No. __________________ issued on _____________________ at", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 940));
            e.Graphics.DrawString("Lumban, Laguna", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 960));
            e.Graphics.DrawString("ROLANDO G. UBATAY", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(500, 1010));
            e.Graphics.DrawString("Municipal Mayor", new Font("Calibri", 10, FontStyle.Bold), Brushes.Black, new Point(530, 1030));
        }

        private void printDocument2_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(Properties.Resources.Logo, 100, 40, 80, 80);
            e.Graphics.DrawString("Republic of the Philippines", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(345, 50));
            e.Graphics.DrawString("Province of Laguna", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(370, 70));
            e.Graphics.DrawString("Municipality of Lumban", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(355, 90));
            e.Graphics.DrawString("MUNICIPAL TRICYCLE FRANCHISING AND REGULATORY BOARD", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(220, 120));
            e.Graphics.DrawString("MOTORIZED TRICYCLE OPERATOR'S PERMIT", new Font("Calibri", 13, FontStyle.Bold), Brushes.Black, new Point(300, 150));
            e.Graphics.DrawString("Applicant:", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 190));
            e.Graphics.DrawString("______________________________________________", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(145, 190));
            e.Graphics.DrawString(Fname.Text + "\t\t" + MI.Text + ".\t" + Lname.Text + "\t " + Suff.Text + "", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(150, 190));
            e.Graphics.DrawString("Case No.:", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(535, 190));
            e.Graphics.DrawString(" _____________________", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(600, 190));
            e.Graphics.DrawString(CaseNo.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(605, 190));
            e.Graphics.DrawString("Address:", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 220));
            e.Graphics.DrawString(" _____________________________________________________________________________", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(133, 220));
            e.Graphics.DrawString("\t\t" + HouseNo.Text + "  " + Street.Text + " st.,  Brgy. " + Brgy.Text + "  " + City.Text + ",  " + Province.Text + "", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(138, 220));
            e.Graphics.DrawString("(No./Street/Barangay/Municipal?Province)", new Font("Calibri", 10, FontStyle.Italic), Brushes.Black, new Point(350, 238));
            e.Graphics.DrawString("Applicants is hereby Authorized to operate a Motorized Tricycle services for hire on the route", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(140, 270));
            e.Graphics.DrawString(" ____________________________________________________________________________________", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 290));
            e.Graphics.DrawString(" LUMBAN, LAGUNA", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(350, 290));
            e.Graphics.DrawString("Using ____       Tricycle/s described as follows:", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 320));
            e.Graphics.DrawString(NoUnits.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(125, 320));
            e.Graphics.DrawString("MAKE\t\tMOTOR No.\t\tCHASSIS NO.\t\tPLATE NO.", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(100, 350));
            e.Graphics.DrawString(Make.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(100, 365));
            e.Graphics.DrawString(MotorNo.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(235, 365));
            e.Graphics.DrawString(ChassisNo.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(433, 365));
            e.Graphics.DrawString(PlateNo.Text, new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(635, 365));
            e.Graphics.DrawString("Subject for the following conditions:", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(75, 410));
            e.Graphics.DrawString("1.   Applicant/Operator shall comply with the rules/regulations prescribed under existing", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(140, 440));
            e.Graphics.DrawString("Municipal Ordinance, failure to comply thereof and any of the cconditions herein set forth shall be\nsufficient cause for the suspension or cancellation of the authority herein granted;", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 460));
            e.Graphics.DrawString("2.   The unit    shall be registered as for HIRE with the Land  Transportation   Office (LTO)", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(140, 510));
            e.Graphics.DrawString("Pila, Laguna in accordance with its prescribed rules and regulations;", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 540));
            e.Graphics.DrawString("3.   within  the  authorized  route,  applicant  shall  charged  the  following  fare  rate  per", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(140, 560));
            e.Graphics.DrawString("passenger trip, subject to the provisions of Municipal Ordinance No. ____ 15, S. 2007", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 580));
            e.Graphics.DrawString("4.   This special  authority  shall be  valid for  one (1) year  for  the date  hereof  and  shall", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(140, 610));
            e.Graphics.DrawString("constitute  franchise  certificate  giving  the  operator  the  privilege  to  operate  the  unit/s  herein\nprescribed for hire and/or compensation;", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 630));
            e.Graphics.DrawString("5.   Without previous authority from the Sangguniang Bayan, operator  shall  not increase", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(140, 680));
            e.Graphics.DrawString("transfer drop and/or substitute unit/s, as well as suspend or abandon the service herein authorized\notherwise the authority herein granted shall declared forfeited or cancelled.", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 700));
            e.Graphics.DrawString("6.   Applicant/Operator shall pay the Office of the Municipal Treasurer SUPERVISION FEE", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(140, 750));
            e.Graphics.DrawString("in  the  amount  of  P50.00 on or before 20th day of january of every year subjected to  penalty and\nsurcharge in the case of late payment;", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 770));
            e.Graphics.DrawString("7.   Protect this document. its lost and destruction may effect your legal rights to operate", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(140, 820));
            e.Graphics.DrawString("the service, any addition or deletion not otherwise authorized will invalidate this documents.", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 840));
            e.Graphics.DrawString("SO ORDERED", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(75, 900));
            e.Graphics.DrawString("Lumban, Laguna", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(75, 915));
            e.Graphics.DrawString("ROLANDO G. UBATAY", new Font("Calibri", 12, FontStyle.Bold), Brushes.Black, new Point(630, 940));
            e.Graphics.DrawString("Municipal Mayor", new Font("Calibri", 10, FontStyle.Italic), Brushes.Black, new Point(655, 955));
            e.Graphics.DrawString("Cc:", new Font("Calibri", 10, FontStyle.Regular), Brushes.Black, new Point(75, 970));
            e.Graphics.DrawString("Applicant\nOM\nLumban Police Station\nOffice of the Treasurer", new Font("Calibri", 10, FontStyle.Italic), Brushes.Black, new Point(140, 970));
            e.Graphics.DrawString("Fee Paid\t  :\nOR No.\t  :\nDate Issued:", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(610, 1030));
            e.Graphics.DrawString("__________\n__________\n__________", new Font("Calibri", 12, FontStyle.Regular), Brushes.Black, new Point(700, 1030));
        }
    }
}
