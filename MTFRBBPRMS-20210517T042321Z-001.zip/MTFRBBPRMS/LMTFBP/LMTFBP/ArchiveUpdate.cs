﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class ArchiveUpdate : UserControl
    {
        MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public ArchiveUpdate()
        {
            InitializeComponent();
        }

        private void ArchiveUpdate_Load_1(object sender, EventArgs e)
        {
            if (textBox2.Text == "Renewal")
            {
                con.Open();
                com = con.CreateCommand();
                com.CommandText = "SELECT * FROM t_rmotor WHERE Applicant_ID LIKE '" + textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    Make.Text = reader[2].ToString();
                    Model.Text = reader[3].ToString();
                    MotorNo.Text = reader[4].ToString();
                    ChassisNo.Text = reader[5].ToString();
                    PlateNo.Text = reader[6].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM t_renew WHERE Applicant_ID LIKE '" + textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    Toda.Text = reader[17].ToString();
                    Position.Text = reader[18].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = " SELECT * FROM t_rfranchise WHERE Applicant_ID LIKE '" + textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    CaseNo.Text = reader[2].ToString();
                    StartDTP.Text = reader[4].ToString();
                    EndDTP.Text = reader[4].ToString();
                    NoUnits.Text = reader[5].ToString();
                    OwnerType.Text = reader[6].ToString();
                    OtherType.Text = reader[7].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                con.Open();
                com = con.CreateCommand();
                com.CommandText = " SELECT * FROM t_motorcycle WHERE Applicant_ID LIKE '" + textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    Make.Text = reader[2].ToString();
                    Model.Text = reader[3].ToString();
                    MotorNo.Text = reader[4].ToString();
                    ChassisNo.Text = reader[5].ToString();
                    PlateNo.Text = reader[6].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM t_records WHERE Applicant_ID LIKE '" + textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    Toda.Text = reader[17].ToString();
                    Position.Text = reader[18].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = " SELECT * FROM t_franchise WHERE Applicant_ID LIKE '" + textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    CaseNo.Text = reader[2].ToString();
                    StartDTP.Text = reader[4].ToString();
                    EndDTP.Text = reader[4].ToString();
                    NoUnits.Text = reader[5].ToString();
                    OwnerType.Text = reader[6].ToString();
                    OtherType.Text = reader[7].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();
                con.Close();
            }
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Archive_Click(object sender, EventArgs e)
        {
            ArchiveRec();
        }

        public void ArchiveRec()
        {
            DialogResult result = MessageBox.Show("Remove This Record?", "Warning!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                con.Open();
                com = con.CreateCommand();
                com.CommandText = "INSERT into t_archive (Applicant_ID, Applicant_Type, Lname, Fname, Mname, Suffix, Gender, House_No, Street, Brgy, Town, Province, Contact_No, Citizenship, Other_Ctzn, License_No, Toda, Position, End_Val) VALUES ('" +
                 AppNo.Text + "','" + AppType.Text + "','" + Lname.Text + "','" + Fname.Text + "','" + MI.Text + "','" + Suff.Text + "','" +
                 Gender.Text + "','" + HouseNo.Text + "','" + Street.Text + "','" + Brgy.Text + "','" + City.Text + "','" + Province.Text + "','" +
                 ContactNo.Text + "','" + Citizenship.Text + "','" + DualCtzn.Text + "','" + LicenseNo.Text + "','" + Toda.Text + "','" + Position.Text + "','" + EndDTP.Text + "')";
                com.ExecuteNonQuery();

                com.CommandText = "INSERT into t_amotor (Applicant_ID, Make, Model, Motor_No, Chassis_No, Plate_No, Contact_No) VALUES ('" +
                    AppNo.Text + "','" + Make.Text + "','" + Model.Text + "','" + MotorNo.Text + "','" +
                    ChassisNo.Text + "','" + PlateNo.Text + "','" + ContactNo.Text + "')";
                com.ExecuteNonQuery();

                com.CommandText = "INSERT into t_afranchise (Applicant_ID, Case_No, Start_Val, End_Val, No_Unit, Owner_Type, Other_Type, Contact_No) VALUES ('" +
                    AppNo.Text + "','" + CaseNo.Text + "','" + StartDTP.Text + "','" + EndDTP.Text + "','" + NoUnits.Text + "','" +
                    OwnerType.Text + "','" + OtherType.Text + "','" + ContactNo.Text + "')";
                com.ExecuteNonQuery();
                con.Close();
                Delete();
                MessageBox.Show("Applicant moved to archived.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                clear();
            }
        }
        public void Delete()
        {
            if (textBox2.Text == "New")
            {
                con.Open();
                com = con.CreateCommand();
                com.CommandText = "DELETE FROM t_records WHERE Applicant_ID = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM t_motorcycle WHERE Applicant_ID = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM t_franchise WHERE Applicant_ID = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                con.Open();
                com = con.CreateCommand();
                com.CommandText = "DELETE FROM t_renew WHERE Applicant_ID = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM t_rmotor WHERE Applicant_ID = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM t_rfranchise WHERE Applicant_ID = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();
                con.Close();
            }
        }
        public void clear()
        {
            Fname.ResetText();
            MI.ResetText();
            Lname.ResetText();
            Suff.ResetText();
            Gender.Items.Clear();
            Gender.Items.Add("Male");
            Gender.Items.Add("Female");
            HouseNo.ResetText();
            Street.ResetText();
            Brgy.ResetText();
            City.ResetText();
            ContactNo.ResetText();
            Citizenship.ResetText();
            DualCtzn.ResetText();
            LicenseNo.ResetText();
            Make.ResetText();
            Model.ResetText();
            MotorNo.ResetText();
            ChassisNo.ResetText();
            PlateNo.ResetText();
            Toda.ResetText();
            Position.Items.Clear();
            Position.Items.Add("President");
            Position.Items.Add("Vice-President");
            Position.Items.Add("Secretary");
            Position.Items.Add("Tresurer");
            Position.Items.Add("Auditor");
            Position.Items.Add("Chairman");
            Position.Items.Add("Board member");
            Position.Items.Add("Member");
            Position.Items.Add("None");
            CaseNo.ResetText();
            EndDTP.ResetText();
            NoUnits.ResetText();
            OwnerType.Items.Clear();
            OwnerType.Items.Add("Single Proprietorship");
            OwnerType.Items.Add("Cooperative");
            OwnerType.Items.Add("Corporation");
            OwnerType.Items.Add("Others...");
            OtherType.ResetText();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }
    }
}
