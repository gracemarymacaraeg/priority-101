﻿namespace LMTFBP
{
    partial class tView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(tView));
            this.ViewRecords = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.PrintBtn = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Archive = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton2 = new Bunifu.Framework.UI.BunifuFlatButton();
            ((System.ComponentModel.ISupportInitialize)(this.ViewRecords)).BeginInit();
            this.SuspendLayout();
            // 
            // ViewRecords
            // 
            this.ViewRecords.AllowUserToAddRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ViewRecords.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.ViewRecords.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.ViewRecords.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.ViewRecords.BackgroundColor = System.Drawing.Color.SkyBlue;
            this.ViewRecords.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ViewRecords.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.DeepSkyBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ViewRecords.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.ViewRecords.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ViewRecords.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column16,
            this.Column17,
            this.Column18,
            this.Column15});
            this.ViewRecords.DoubleBuffered = true;
            this.ViewRecords.EnableHeadersVisualStyles = false;
            this.ViewRecords.GridColor = System.Drawing.Color.White;
            this.ViewRecords.HeaderBgColor = System.Drawing.Color.DeepSkyBlue;
            this.ViewRecords.HeaderForeColor = System.Drawing.Color.Black;
            this.ViewRecords.Location = new System.Drawing.Point(59, 49);
            this.ViewRecords.Name = "ViewRecords";
            this.ViewRecords.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.ViewRecords.Size = new System.Drawing.Size(842, 425);
            this.ViewRecords.TabIndex = 0;
            this.ViewRecords.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ViewRecords_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Applicant No.";
            this.Column1.Name = "Column1";
            this.Column1.Width = 110;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Applicant Type";
            this.Column2.Name = "Column2";
            this.Column2.Width = 117;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "First Name";
            this.Column3.Name = "Column3";
            this.Column3.Width = 96;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Middle Initial";
            this.Column4.Name = "Column4";
            this.Column4.Width = 104;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Last Name";
            this.Column5.Name = "Column5";
            this.Column5.Width = 95;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Suffix";
            this.Column6.Name = "Column6";
            this.Column6.Width = 64;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Gender";
            this.Column7.Name = "Column7";
            this.Column7.Width = 74;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "House No.";
            this.Column8.Name = "Column8";
            this.Column8.Width = 93;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Street";
            this.Column9.Name = "Column9";
            this.Column9.Width = 67;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "Brgy";
            this.Column10.Name = "Column10";
            this.Column10.Width = 59;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Municipality";
            this.Column11.Name = "Column11";
            this.Column11.Width = 101;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "Province";
            this.Column12.Name = "Column12";
            this.Column12.Width = 81;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "Contact No";
            this.Column13.Name = "Column13";
            this.Column13.Width = 97;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "Citizenship";
            this.Column14.Name = "Column14";
            this.Column14.Width = 96;
            // 
            // Column16
            // 
            this.Column16.HeaderText = "License No.";
            this.Column16.Name = "Column16";
            this.Column16.Width = 101;
            // 
            // Column17
            // 
            this.Column17.HeaderText = "Start Validity";
            this.Column17.Name = "Column17";
            this.Column17.Width = 106;
            // 
            // Column18
            // 
            this.Column18.HeaderText = "End Validity";
            this.Column18.Name = "Column18";
            this.Column18.Width = 101;
            // 
            // Column15
            // 
            this.Column15.HeaderText = "Process By";
            this.Column15.Name = "Column15";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(56, 477);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(161, 17);
            this.label4.TabIndex = 19;
            this.label4.Text = "Total No. of Applicants:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(223, 477);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 17);
            this.label2.TabIndex = 20;
            this.label2.Text = "label2";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(28, 3);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(173, 22);
            this.textBox3.TabIndex = 366;
            this.textBox3.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(697, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 16);
            this.label3.TabIndex = 367;
            this.label3.Text = "label1";
            this.label3.Visible = false;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // PrintBtn
            // 
            this.PrintBtn.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.PrintBtn.BackColor = System.Drawing.Color.Transparent;
            this.PrintBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PrintBtn.BorderRadius = 0;
            this.PrintBtn.ButtonText = "Print Daily Report";
            this.PrintBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PrintBtn.DisabledColor = System.Drawing.Color.Gray;
            this.PrintBtn.Iconcolor = System.Drawing.Color.Transparent;
            this.PrintBtn.Iconimage = ((System.Drawing.Image)(resources.GetObject("PrintBtn.Iconimage")));
            this.PrintBtn.Iconimage_right = null;
            this.PrintBtn.Iconimage_right_Selected = null;
            this.PrintBtn.Iconimage_Selected = null;
            this.PrintBtn.IconMarginLeft = 0;
            this.PrintBtn.IconMarginRight = 0;
            this.PrintBtn.IconRightVisible = true;
            this.PrintBtn.IconRightZoom = 0D;
            this.PrintBtn.IconVisible = true;
            this.PrintBtn.IconZoom = 55D;
            this.PrintBtn.IsTab = false;
            this.PrintBtn.Location = new System.Drawing.Point(358, 499);
            this.PrintBtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.PrintBtn.Name = "PrintBtn";
            this.PrintBtn.Normalcolor = System.Drawing.Color.Transparent;
            this.PrintBtn.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.PrintBtn.OnHoverTextColor = System.Drawing.Color.Black;
            this.PrintBtn.selected = false;
            this.PrintBtn.Size = new System.Drawing.Size(177, 35);
            this.PrintBtn.TabIndex = 21;
            this.PrintBtn.Text = "Print Daily Report";
            this.PrintBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PrintBtn.Textcolor = System.Drawing.Color.Black;
            this.PrintBtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintBtn.Visible = false;
            this.PrintBtn.Click += new System.EventHandler(this.PrintBtn_Click);
            // 
            // Archive
            // 
            this.Archive.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.Archive.BackColor = System.Drawing.Color.Transparent;
            this.Archive.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Archive.BorderRadius = 0;
            this.Archive.ButtonText = "Archive Records";
            this.Archive.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Archive.DisabledColor = System.Drawing.Color.Gray;
            this.Archive.ForeColor = System.Drawing.Color.Black;
            this.Archive.Iconcolor = System.Drawing.Color.Transparent;
            this.Archive.Iconimage = ((System.Drawing.Image)(resources.GetObject("Archive.Iconimage")));
            this.Archive.Iconimage_right = null;
            this.Archive.Iconimage_right_Selected = null;
            this.Archive.Iconimage_Selected = null;
            this.Archive.IconMarginLeft = 0;
            this.Archive.IconMarginRight = 0;
            this.Archive.IconRightVisible = true;
            this.Archive.IconRightZoom = 0D;
            this.Archive.IconVisible = true;
            this.Archive.IconZoom = 45D;
            this.Archive.IsTab = false;
            this.Archive.Location = new System.Drawing.Point(541, 499);
            this.Archive.Margin = new System.Windows.Forms.Padding(3, 7, 3, 7);
            this.Archive.Name = "Archive";
            this.Archive.Normalcolor = System.Drawing.Color.Transparent;
            this.Archive.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.Archive.OnHoverTextColor = System.Drawing.Color.Black;
            this.Archive.selected = false;
            this.Archive.Size = new System.Drawing.Size(177, 35);
            this.Archive.TabIndex = 4;
            this.Archive.Text = "Archive Records";
            this.Archive.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Archive.Textcolor = System.Drawing.Color.Black;
            this.Archive.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Archive.Visible = false;
            this.Archive.Click += new System.EventHandler(this.Archive_Click);
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 0;
            this.bunifuFlatButton2.ButtonText = "Update Records";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton2.ForeColor = System.Drawing.Color.Black;
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton2.Iconimage")));
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = true;
            this.bunifuFlatButton2.IconZoom = 45D;
            this.bunifuFlatButton2.IsTab = false;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(724, 499);
            this.bunifuFlatButton2.Margin = new System.Windows.Forms.Padding(3, 7, 3, 7);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.Black;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(177, 35);
            this.bunifuFlatButton2.TabIndex = 3;
            this.bunifuFlatButton2.Text = "Update Records";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.Black;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton2.Visible = false;
            this.bunifuFlatButton2.Click += new System.EventHandler(this.bunifuFlatButton2_Click);
            // 
            // tView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.PrintBtn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Archive);
            this.Controls.Add(this.bunifuFlatButton2);
            this.Controls.Add(this.ViewRecords);
            this.Font = new System.Drawing.Font("Arial", 9.75F);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "tView";
            this.Size = new System.Drawing.Size(968, 550);
            this.Load += new System.EventHandler(this.tView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ViewRecords)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label2;
        public Bunifu.Framework.UI.BunifuCustomDataGrid ViewRecords;
        public Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton2;
        public Bunifu.Framework.UI.BunifuFlatButton Archive;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        public System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Timer timer1;
        public Bunifu.Framework.UI.BunifuFlatButton PrintBtn;
        public System.Windows.Forms.Label label3;
    }
}
