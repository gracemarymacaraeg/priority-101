﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using DGVPrinterHelper;

namespace LMTFBP
{
    public partial class tView : UserControl
    {
        MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public tView()
        {
            InitializeComponent();
        }

        private void tView_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Start();
            label3.Text = DateTime.Now.ToShortDateString();
            con.Open();
            ViewRecords.Rows.Clear();
            com = con.CreateCommand();
            com.CommandText = " SELECT* from t_records ORDER by Applicant_No Asc ";
            reader = com.ExecuteReader();
            while (reader.Read())
            {
                ViewRecords.Rows.Add(reader[1].ToString(), reader[2].ToString(),
                reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), reader[6].ToString(),
                reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString(),
                reader[11].ToString(), reader[12].ToString(), reader[13].ToString(),
                reader[14].ToString(), reader[16].ToString(),
                reader[19].ToString(), reader[20].ToString(), reader[21].ToString());
            }
            reader.Close();
            com.ExecuteNonQuery();

            com.CommandText = "SELECT * FROM t_renew ORDER BY Applicant_No Asc ";
            reader = com.ExecuteReader();
            while (reader.Read())
            {
                ViewRecords.Rows.Add(reader[1].ToString(), reader[2].ToString(),
                reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), reader[6].ToString(),
                reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString(),
                reader[11].ToString(), reader[12].ToString(), reader[13].ToString(),
                reader[14].ToString(), reader[16].ToString(),
                reader[19].ToString(), reader[20].ToString(), reader[21].ToString());
            }
            reader.Close();
            com.ExecuteNonQuery();
            con.Close();
            label2.Text = ViewRecords.Rows.Count.ToString();
        }

        private void Archive_Click(object sender, EventArgs e)
        {
            Update ud = new Update();
            var uc1 = new ArchiveUpdate();
            ud.panel1.Controls.Clear();
            ud.panel1.Controls.Add(uc1);
            const string message = "View Profile?";
            const string caption = "View";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                uc1.AppType.Text = this.ViewRecords.CurrentRow.Cells[1].Value.ToString();
                uc1.textBox2.Text = this.ViewRecords.CurrentRow.Cells[1].Value.ToString();
                uc1.textBox1.Text = this.ViewRecords.CurrentRow.Cells[0].Value.ToString();
                uc1.AppNo.Text = this.ViewRecords.CurrentRow.Cells[0].Value.ToString();
                uc1.Lname.Text = this.ViewRecords.CurrentRow.Cells[2].Value.ToString();
                uc1.Fname.Text = this.ViewRecords.CurrentRow.Cells[3].Value.ToString();
                uc1.MI.Text = this.ViewRecords.CurrentRow.Cells[4].Value.ToString();
                uc1.Suff.Text = this.ViewRecords.CurrentRow.Cells[5].Value.ToString();
                uc1.Gender.Text = this.ViewRecords.CurrentRow.Cells[6].Value.ToString();
                uc1.HouseNo.Text = this.ViewRecords.CurrentRow.Cells[7].Value.ToString();
                uc1.Street.Text = this.ViewRecords.CurrentRow.Cells[8].Value.ToString();
                uc1.Brgy.Text = this.ViewRecords.CurrentRow.Cells[9].Value.ToString();
                uc1.City.Text = this.ViewRecords.CurrentRow.Cells[10].Value.ToString();
                uc1.ContactNo.Text = this.ViewRecords.CurrentRow.Cells[12].Value.ToString();
                uc1.Citizenship.Text = this.ViewRecords.CurrentRow.Cells[13].Value.ToString();
                uc1.DualCtzn.Text = this.ViewRecords.CurrentRow.Cells[14].Value.ToString();
                uc1.LicenseNo.Text = this.ViewRecords.CurrentRow.Cells[15].Value.ToString();
                ud.Show();
            }
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            if (bunifuFlatButton2.Text == "Update Records")
            {
                Update ud = new Update();
                var uc1 = new UpdateRecord();
                uc1.textBox3.Text = textBox3.Text;
                ud.panel1.Controls.Clear();
                ud.panel1.Controls.Add(uc1);
                const string message = "View Profile?";
                const string caption = "View";
                var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    uc1.AppType.Text = "Renewal";
                    uc1.textBox2.Text = this.ViewRecords.CurrentRow.Cells[1].Value.ToString();
                    uc1.textBox1.Text = this.ViewRecords.CurrentRow.Cells[0].Value.ToString();
                    uc1.AppNo.Text = this.ViewRecords.CurrentRow.Cells[0].Value.ToString();
                    uc1.Lname.Text = this.ViewRecords.CurrentRow.Cells[2].Value.ToString();
                    uc1.Fname.Text = this.ViewRecords.CurrentRow.Cells[3].Value.ToString();
                    uc1.MI.Text = this.ViewRecords.CurrentRow.Cells[4].Value.ToString();
                    uc1.Suff.Text = this.ViewRecords.CurrentRow.Cells[5].Value.ToString();
                    uc1.Gender.Text = this.ViewRecords.CurrentRow.Cells[6].Value.ToString();
                    uc1.HouseNo.Text = this.ViewRecords.CurrentRow.Cells[7].Value.ToString();
                    uc1.Street.Text = this.ViewRecords.CurrentRow.Cells[8].Value.ToString();
                    uc1.Brgy.Text = this.ViewRecords.CurrentRow.Cells[9].Value.ToString();
                    uc1.City.Text = this.ViewRecords.CurrentRow.Cells[10].Value.ToString();
                    uc1.ContactNo.Text = this.ViewRecords.CurrentRow.Cells[12].Value.ToString();
                    uc1.Citizenship.Text = this.ViewRecords.CurrentRow.Cells[13].Value.ToString();
                    uc1.DualCtzn.Text = this.ViewRecords.CurrentRow.Cells[14].Value.ToString();
                    uc1.LicenseNo.Text = this.ViewRecords.CurrentRow.Cells[15].Value.ToString();
                    ud.Show();
                }
            }
            else
            {
                Update ud = new Update();
                var uc1 = new UpdateArchive();
                uc1.textBox3.Text = textBox3.Text;
                ud.panel1.Controls.Clear();
                ud.panel1.Controls.Add(uc1);
                const string message = "View Profile?";
                const string caption = "View";
                var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    uc1.AppType.Text = "Renewal";
                    uc1.textBox2.Text = this.ViewRecords.CurrentRow.Cells[1].Value.ToString();
                    uc1.textBox1.Text = this.ViewRecords.CurrentRow.Cells[0].Value.ToString();
                    uc1.AppNo.Text = this.ViewRecords.CurrentRow.Cells[0].Value.ToString();
                    uc1.Lname.Text = this.ViewRecords.CurrentRow.Cells[2].Value.ToString();
                    uc1.Fname.Text = this.ViewRecords.CurrentRow.Cells[3].Value.ToString();
                    uc1.MI.Text = this.ViewRecords.CurrentRow.Cells[4].Value.ToString();
                    uc1.Suff.Text = this.ViewRecords.CurrentRow.Cells[5].Value.ToString();
                    uc1.Gender.Text = this.ViewRecords.CurrentRow.Cells[6].Value.ToString();
                    uc1.HouseNo.Text = this.ViewRecords.CurrentRow.Cells[7].Value.ToString();
                    uc1.Street.Text = this.ViewRecords.CurrentRow.Cells[8].Value.ToString();
                    uc1.Brgy.Text = this.ViewRecords.CurrentRow.Cells[9].Value.ToString();
                    uc1.City.Text = this.ViewRecords.CurrentRow.Cells[10].Value.ToString();
                    uc1.ContactNo.Text = this.ViewRecords.CurrentRow.Cells[12].Value.ToString();
                    uc1.Citizenship.Text = this.ViewRecords.CurrentRow.Cells[13].Value.ToString();
                    uc1.DualCtzn.Text = this.ViewRecords.CurrentRow.Cells[14].Value.ToString();
                    uc1.LicenseNo.Text = this.ViewRecords.CurrentRow.Cells[15].Value.ToString();
                    ud.Show();
                }
            }
        }

        private void ViewRecords_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void PrintBtn_Click(object sender, EventArgs e)
        {
            tprint();
            DGVPrinter printer = new DGVPrinter();
            printer.Title = "Today's Report";
            printer.TitleFont = new Font("Calibri", 12, FontStyle.Bold);
            printer.SubTitle = label3.Text;
            printer.SubTitleFormatFlags = StringFormatFlags.LineLimit | StringFormatFlags.NoClip;
            printer.PageNumbers = true;
            printer.PageNumberInHeader = false;
            printer.PorportionalColumns = true;
            printer.HeaderCellAlignment = StringAlignment.Near;
            printer.Footer = label4.Text + " " + label2.Text;
            printer.FooterSpacing = 15;
            printer.printDocument.DefaultPageSettings.Landscape = true;
            printer.PrintDataGridView(ViewRecords);
            printer.PageSettings.Landscape = true;

        }

        public void tprint()
        {
            con.Open();
            ViewRecords.Rows.Clear();
            com = con.CreateCommand();
            com.CommandText = " SELECT* FROM t_records WHERE Start_Val = '" + label3.Text + "' ORDER by Applicant_Type DESC ";
            reader = com.ExecuteReader();
            while (reader.Read())
            {
                ViewRecords.Rows.Add(reader[1].ToString(), reader[2].ToString(),
                reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), reader[6].ToString(),
                reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString(),
                reader[11].ToString(), reader[12].ToString(), reader[13].ToString(),
                reader[14].ToString(), reader[15].ToString(), reader[16].ToString(),
                reader[19].ToString(), reader[20].ToString(),reader[21].ToString());
            }
            reader.Close();
            com.ExecuteNonQuery();

            com.CommandText = " SELECT* FROM t_renew WHERE Start_Val = '" + label3.Text + "' ORDER by Applicant_Type DESC ";
            reader = com.ExecuteReader();
            while (reader.Read())
            {
                ViewRecords.Rows.Add(reader[1].ToString(), reader[2].ToString(),
                reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), reader[6].ToString(),
                reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString(),
                reader[11].ToString(), reader[12].ToString(), reader[13].ToString(),
                reader[14].ToString(), reader[15].ToString(), reader[16].ToString(),
                reader[19].ToString(), reader[20].ToString(), reader[21].ToString());
            }
            reader.Close();
            com.ExecuteNonQuery();
            con.Close();
            label2.Text = ViewRecords.Rows.Count.ToString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
            label3.Text = DateTime.Now.ToShortDateString();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
