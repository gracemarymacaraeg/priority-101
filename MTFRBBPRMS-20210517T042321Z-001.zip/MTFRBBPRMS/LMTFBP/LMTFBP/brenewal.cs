﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class brenewal : UserControl
    {
        MySqlConnection cn = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=bplo; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public brenewal()
        {
            InitializeComponent();
        }

        public void getnewID()
        {
            string newID;
            string query = "SELECT Applicant_No FROM b_r_renewinfo ORDER BY Applicant_No Desc";

            cn.Open();
            MySqlCommand com = new MySqlCommand(query, cn);
            MySqlDataReader dr = com.ExecuteReader();

            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                newID = id.ToString("0");
            }
            else if (Convert.IsDBNull(dr))
            {
                newID = ("1");
            }
            else
            {
                newID = ("1");
            }
            cn.Close();

            appNo.Text = newID.ToString();
        }
        public void renewal()
        {
            getnewID();
            cn.Open();
                com = cn.CreateCommand();
                com.CommandText = "SELECT * FROM b_r_information WHERE Applicant_No LIKE '" + textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    psuffix.Text = reader[15].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();
                cn.Close();
        }
        public void clear()
        {
            appType.Clear();
            appNo.Clear();
            textBox1.Clear();
            applicant_type.Clear();
            paymentCB.Items.Clear();
            appDate.ResetText();
            lnameTB.Clear();
            fnameTB.Clear();
            mnameTB.Clear();
            suffixTB.Clear();
            bnameTB.Clear();
            bplateTB.Clear();
            tnameTB.Clear();
            plname.Clear();
            pfname.Clear();
            pmname.Clear();
            psuffix.Clear();
            transferCB.Items.Clear();
            AmmendCB.Items.Clear();
            referenceTB.Clear();
            dtiDate.ResetText();
            dtiNo.Clear();
            ctcNo.Clear();
            tinTB.Clear();
            orgCB.Items.Clear();
            govtCB.Items.Clear();
            specify.Clear();
            pinTB.Clear();
            establishTB.Clear();
            lguTB.Clear();
            cfnameTB.Clear();
            ctelnoTB.Clear();
            ohouseTB.Clear();
            obldgTB.Clear();
            ounitTB.Clear();
            ostreetTB.Clear();
            obrgyTB.Clear();
            osubdTB.Clear();
            omunTB.Clear();
            oprovTB.Clear();
            otelnoTB.Clear();
            oemailTB.Clear();
            bhouseTB.Clear();
            bbldgTB.Clear();
            bunitTB.Clear();
            bstreetTB.Clear();
            bbrgyTB.Clear();
            bsubdTB.Clear();
            bmunTB.Clear();
            bprovinceTB.Clear();
            btelnoTB.Clear();
            bemailTB.Clear();
            llnameTB.Clear();
            lfnameTB.Clear();
            lmiTB.Clear();
            lmonthlyTB.Clear();
            lhouseTB.Clear();
            lstreetTB.Clear();
            lbrgyTB.Clear();
            lmunTB.Clear();
            lprovTB.Clear();
            ltelnoTB.Clear();
            lemailTB.Clear();
            buscodeTB.Clear();
            busilineTB.Clear();
            bnounitTB.Clear();
            bcapitalTB.Clear();
            bessentialTB.Clear();
            bnonessentialTB.Clear();

        }
        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Save Information?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                addrenew();
                remove();
                clear();
            }
        }

        public void archive()
        {
            cn.Open();
            com = cn.CreateCommand();
            com.CommandText = "INSERT into b_a_information (Applicant_No, Applicant_Type, Payment_type, Transfer, Ammendment_type, App_date, lname, fname, mname, suffix, bname, bplate, tname, plname, pfname, pmname, psuffix) VALUES ('" +
                appNo.Text + "','" + appType.Text + "','" + paymentCB.Text + "','" + transferCB.Text + "','" + AmmendCB.Text + "','" + appDate.Text + "','" +
                lnameTB.Text + "','" + fnameTB.Text + "','" + mnameTB.Text + "','" + suffixTB.Text + "','" + bnameTB.Text + "','" + bplateTB.Text + "','" +
                tnameTB.Text + "','" + plname.Text + "','" + pfname.Text + "','" + pmname.Text + "','" + psuffix.Text + "')";
            com.ExecuteNonQuery();

            com.CommandText = "INSERT into b_a_raddress (Applicant_no, llname, lfname, lmname, monthly, house_No, street, Brgy, Municipal, Province, Tel_no, Email) VALUES ('" +
                 appNo.Text + "','" + llnameTB.Text + "','" + lfnameTB.Text + "','" + lmiTB.Text + "','" + lmonthlyTB.Text + "','" + lhouseTB.Text + "','" +
                lstreetTB.Text + "','" + lbrgyTB.Text + "','" + lmunTB.Text + "','" + lprovTB.Text + "','" + ltelnoTB.Text + "','" + lemailTB.Text + "')";
            com.ExecuteNonQuery();

            com.CommandText = "INSERT into b_a_baddress (Applicant_No, House_No, Bldg_name, Unit_No, Street, brgy, Subd, Municipal, province, Tel_No, Email) VALUES ('" +
                appNo.Text + "','" + bhouseTB.Text + "','" + bbldgTB.Text + "','" + bunitTB.Text + "','" + bstreetTB.Text + "','" + bbrgyTB.Text + "','" +
                bsubdTB.Text + "','" + bmunTB.Text + "','" + bprovinceTB.Text + "','" + btelnoTB.Text + "','" + bemailTB.Text + "')";
            com.ExecuteNonQuery();

            com.CommandText = " INSERT into b_a_oaddress (Applicant_No, House_No, Bldg_Name, Unit_no, Street, Brgy, Subd, Municipal, Province, tel_No, Email) VALUES ('" +
                appNo.Text + "','" + ohouseTB.Text + "','" + obldgTB.Text + "','" + ounitTB.Text + "','" + ostreetTB.Text + "','" + obrgyTB.Text + "','" +
                osubdTB.Text + "','" + omunTB.Text + "','" + oprovTB.Text + "','" + otelnoTB.Text + "','" + oemailTB.Text + "')";
            com.ExecuteNonQuery();

            com.CommandText = "INSERT into b_a_requirements (Applicant_No, Reference_no, DTI_date, DTI_no, CTC_no, TIN_no, Org_type, Govt_entity, Specify, PIN, No_Employee, Employee_LGU, Contact_Person, CPerson_No) VALUES ('" +
                appNo.Text + "','" + referenceTB.Text + "','" + dtiDate.Text + "','" + dtiNo.Text + "','" + ctcNo.Text + "','" + tinTB.Text + "','" + orgCB.Text + "','" +
                govtCB.Text + "','" + specify.Text + "','" + pinTB.Text + "','" + establishTB.Text + "','" + lguTB.Text + "','" + cfnameTB.Text + "','" + ctelnoTB.Text + "')";
            com.ExecuteNonQuery();

            com.CommandText = "INSERT into b_a_activity (Applicant_No, b_code, b_line, b_units, b_capital, bg_essential, bg_nonessential) VALUES ('" +
                appNo.Text + "','" + buscodeTB.Text + "','" + busilineTB.Text + "','" + bnounitTB.Text + "','" + bcapitalTB.Text + "','" +
                bessentialTB.Text + "','" + bnonessentialTB.Text + "')";
            com.ExecuteNonQuery();
            MessageBox.Show("Application moved to archive.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            cn.Close();
        }
        public void remove()
        {
            if (applicant_type.Text == "New")
            {
                cn.Open();
                com = cn.CreateCommand();
                com.CommandText = "DELETE FROM b_i_information WHERE Applicant_No = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM b_i_requirements WHERE Applicant_No = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM b_i_oaddress WHERE Applicant_No = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM b_i_baddress WHERE Applicant_No = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM b_i_raddress WHERE Applicant_No = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM b_i_activity WHERE Applicant_No = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();
                cn.Close();
            }
            else
            {
                cn.Open();
                com = cn.CreateCommand();
                com.CommandText = "DELETE FROM b_r_renewinfo WHERE Applicant_No = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM b_r_requirements WHERE Applicant_No = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM b_r_oaddress WHERE Applicant_No = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM b_r_baddress WHERE Applicant_No = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM b_r_raddress WHERE Applicant_No = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM b_r_acrtivity WHERE Applicant_No = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();
                cn.Close();
            }
        }

        public void addrenew()
        {
            if (appType.Text == "Renewal")
            {
                cn.Open();
                com = cn.CreateCommand();
                com.CommandText = "INSERT into b_r_renewinfo (Applicant_No, Applicant_Type, Payment_type, Transfer, Ammendment_type, App_date, lname, fname, mname, suffix, bname, bplate, tname, plname, pfname, pmname, psuffix) VALUES ('" +
                    appNo.Text + "','" + appType.Text + "','" + paymentCB.Text + "','" + transferCB.Text + "','" + AmmendCB.Text + "','" + appDate.Text + "','" +
                    lnameTB.Text + "','" + fnameTB.Text + "','" + mnameTB.Text + "','" + suffixTB.Text + "','" + bnameTB.Text + "','" + bplateTB.Text + "','" +
                    tnameTB.Text + "','" + plname.Text + "','" + pfname.Text + "','" + pmname.Text + "','" + psuffix.Text + "')";
                com.ExecuteNonQuery();

                com.CommandText = "INSERT into b_r_requirements (Applicant_No, Reference_no, DTI_date, DTI_no, CTC_no, TIN_no, Org_type, Govt_entity, Specify, PIN, No_Employee, Employee_LGU, Contact_Person, Cperson_No) VALUES ('" +
                    appNo.Text + "','" + referenceTB.Text + "','" + dtiDate.Text + "','" + dtiNo.Text + "','" + ctcNo.Text + "','" + tinTB.Text + "','" + orgCB.Text + "','" + govtCB.Text + "','" +
                    specify.Text + "','" + pinTB.Text + "','" + establishTB.Text + "','" + lguTB.Text + "','" + cfnameTB.Text + "','" + ctelnoTB.Text + "')";
                com.ExecuteNonQuery();

                com.CommandText = "INSERT into b_r_oaddress (Applicant_No, House_No, Bldg_Name, Unit_no, Street, Brgy, Subd, Municipal, Province, tel_No, Email) VALUES ('" +
                    appNo.Text + "','" + ohouseTB.Text + "','" + obldgTB.Text + "','" + ounitTB.Text + "','" + ostreetTB.Text + "','" + obrgyTB.Text + "','" +
                    osubdTB.Text + "','" + omunTB.Text + "','" + oprovTB.Text + "','" + otelnoTB.Text + "','" + oemailTB.Text + "')";
                com.ExecuteNonQuery();

                com.CommandText = "INSERT into b_r_baddress (Applicant_No, House_No, Bldg_name, Unit_No, Street, brgy, Subd, Municipal, province, Tel_No, Email) VALUES ('" +
                    appNo.Text + "','" + bhouseTB.Text + "','" + bbldgTB.Text + "','" + bunitTB.Text + "','" + bstreetTB.Text + "','" + bbrgyTB.Text + "','" + bsubdTB.Text + "','" +
                    bmunTB.Text + "','" + bprovinceTB.Text + "','" + btelnoTB.Text + "','" + bemailTB.Text + "')";
                com.ExecuteNonQuery();

                com.CommandText = "INSERT into b_r_raddress (Applicant_no, llname, lfname, lmname, monthly, house_No, street, Brgy, Municipal, Province, Tel_no, Email) VALUES ('" +
                    appNo.Text + "','" + llnameTB.Text + "','" + lfnameTB.Text + "','" + lmiTB.Text + "','" + lmonthlyTB.Text + "','" +
                    lhouseTB.Text + "','" + lstreetTB.Text + "','" + lbrgyTB.Text + "','" + lmunTB.Text + "','" + lprovTB.Text + "','" + ltelnoTB.Text + "','" + lemailTB.Text + "')";
                com.ExecuteNonQuery();

                com.CommandText = "INSERT Into b_r_acrtivity (Applicant_No, b_code, b_line, b_units, b_capital, bg_essential, bg_nonessential) VALUES ('" +
                    appNo.Text + "','" + buscodeTB.Text + "','" + busilineTB.Text + "','" + bnounitTB.Text + "','" + bcapitalTB.Text + "','" +
                    bessentialTB.Text + "','" + bnonessentialTB.Text + "')";
                com.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Save Complete! Ready to Print", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                cn.Open();
                com = cn.CreateCommand();
                com.CommandText = "UPDATE b_r_acrtivity set b_code = '" + buscodeTB.Text + "', b_line = '" + busilineTB.Text + "', b_units = '" +
                    bnounitTB.Text + "', b_capital = '" + bcapitalTB.Text + "', bg_essential = '" + bessentialTB.Text + "', bg_nonessential = '" +
                    bnonessentialTB.Text + "' WHERE Applicant_No = '" + textBox1.Text + "'";
                com.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Save Complete! Ready to Print", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                groupBox7.Enabled = true;
                llnameTB.ResetText();
                lfnameTB.ResetText();
                lmiTB.ResetText();
                lmonthlyTB.ResetText();
                lmunTB.ResetText();
                lprovTB.ResetText();
                ltelnoTB.ResetText();
                lemailTB.ResetText();
                lhouseTB.ResetText();
                lstreetTB.ResetText();
                lbrgyTB.ResetText();
            }
            else
            {
                groupBox7.Enabled = false;
                llnameTB.Text = "N/A";
                lfnameTB.Text = "N/A";
                lmiTB.Text = "N/A";
                lmonthlyTB.Text = "N/A";
                lmunTB.Text = "N/A";
                lprovTB.Text = "N/A";
                ltelnoTB.Text = "N/A";
                lemailTB.Text = "N/A";
                lhouseTB.Text = "N/A";
                lstreetTB.Text = "N/A";
                lbrgyTB.Text = "N/A";
            }
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                bhouseTB.Text = ohouseTB.Text;
                bbldgTB.Text = obldgTB.Text;
                bunitTB.Text = ounitTB.Text;
                bstreetTB.Text = ostreetTB.Text;
                bbrgyTB.Text = obrgyTB.Text;
                bsubdTB.Text = osubdTB.Text;
                bmunTB.Text = omunTB.Text;
                bprovinceTB.Text = oprovTB.Text;
                btelnoTB.Text = otelnoTB.Text;
                bemailTB.Text = oemailTB.Text;
            }
            
        }

        private void brenewal_Load(object sender, EventArgs e)
        {
            if (applicant_type.Text == "New")
            {
                getnewID();
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void applicant_type_TextChanged(object sender, EventArgs e)
        {

        }

        private void govtCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (govtCB.Text == "Yes")
            {
                specify.Visible = true;
            }
            else
            {
                specify.Visible = false;
            }
        }
    }
}
