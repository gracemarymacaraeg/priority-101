﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class tApplication : UserControl
    {
        MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public tApplication()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void tApplication_Load(object sender, EventArgs e)
        {
            GETmaxID();
        }

        private void SaveToda_Click(object sender, EventArgs e)
        {
            if (oNameTB.Text == "")
            {
                MessageBox.Show("input your organization Name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (requirementCB.Text == "Not Complete")
                {
                    MessageBox.Show("Application Pending due to incomplete Requirements.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    pendingtoda();
                    reset();
                }
                else
                {
                    DialogResult result = MessageBox.Show("Save Application?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        todainfo();
                        MessageBox.Show("Application Approved.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        reset();
                    }
                }
            }
        }

        public void reset()
        {
            oNameTB.ResetText();
            AddressTB.ResetText();
            ContactTB.ResetText();
            DateDTP.ResetText();
            otherAgency.ResetText();
            AgencyCB.Items.Clear();
            AgencyCB.Items.Add("Securities and Exchange Commission");
            AgencyCB.Items.Add("Cooperatives Development Authority");
            AgencyCB.Items.Add("Department of Labor and Employment");
            AgencyCB.Items.Add("Department of Social Welfare and Development");
            AgencyCB.Items.Add("Others... (Please Specify)...");
            otherLevel.ResetText();
            LevelCB.Items.Clear();
            LevelCB.Items.Add("Barangay-Based");
            LevelCB.Items.Add("Chapter");
            LevelCB.Items.Add("Affiliate of a Larger Organization");
            LevelCB.Items.Add("Others... (Please Specify)...");
            cyTB.ResetText();
            projectTB.ResetText();
            costsTB.ResetText();
            benefitTB.ResetText();
            StatusTB.ResetText();
            purposeTB.ResetText();
            financingTB.ResetText();
            ProvideTB.ResetText();
            requirementCB.ResetText();
            presTB.ResetText();
            viceTB.ResetText();
            treasurerTB.ResetText();
            SecretaryTB.ResetText();
            auditorTB.ResetText();
            chairmanTB.ResetText();
            bm1TB.ResetText();
            bm2TB.ResetText();
            bm3TB.ResetText();
            bm4TB.ResetText();
        }
        public void pendingtoda()
        {
            con.Open();
            com = con.CreateCommand();
            com.CommandText = " INSERT into t_ptodainfo (Toda_ID, Requirements, ReqList, Toda_name, Address, Contact_No, Date_Org, Register_Agency, Specify_Agency, Org_lvl, Specify_lvl, CY, Project, Costs, Benificiaries, Status, Purpose, Proj_financing, org_provide) VALUES ('" +
                textBox1.Text + "','" + requirementCB.Text + "','" + requirementTB.Text + "','" + oNameTB.Text + "','" + AddressTB.Text + "','" + ContactTB.Text + "','" + DateDTP.Text + "','" + AgencyCB.Text + "','" +
                otherAgency.Text + "','" + LevelCB.Text + "','" + otherLevel.Text + "','" + cyTB.Text + "','" + projectTB.Text + "','" + costsTB.Text + "','" +
                benefitTB.Text + "','" + StatusTB.Text + "','" + purposeTB.Text + "','" + financingTB.Text + "','" + ProvideTB.Text + "')";
            com.ExecuteNonQuery();

            com.CommandText = "INSERT into t_ptofficers (Toda_ID, Toda_Name, President, Vice_pres, Secretary, Treasurer, Auditor, Chairman, bMember1, bMember2, bMember3, bMember4, bMember5) VALUES ('" +
                textBox1.Text + "','" + oNameTB.Text + "','" + presTB.Text + "','" + viceTB.Text + "','" + SecretaryTB.Text + "','" + treasurerTB.Text + "','" + auditorTB.Text + "','" + chairmanTB.Text + "','" +
                bm1TB.Text + "','" + bm2TB.Text + "','" + bm3TB.Text + "','" + bm4TB.Text + "','" + bm5TB.Text + "')";
            com.ExecuteNonQuery();
            con.Close();
        }

        public void todainfo()
        {
            con.Open();
            com = con.CreateCommand();
            com.CommandText = " INSERT into t_todainfo (Toda_ID, Requirements, ReqList, Toda_name, Address, Contact_No, Date_Org, Register_Agency, Specify_Agency, Org_lvl, Specify_lvl, CY, Project, Costs, Benificiaries, Status, Purpose, Proj_financing, org_provide) VALUES ('" +
                textBox1.Text + "','" + requirementCB.Text + "','" + requirementTB.Text + "','" + oNameTB.Text + "','" + AddressTB.Text + "','" + ContactTB.Text + "','" + DateDTP.Text + "','" + AgencyCB.Text + "','" +
                otherAgency.Text + "','" + LevelCB.Text + "','" + otherLevel.Text + "','" + cyTB.Text + "','" + projectTB.Text + "','" + costsTB.Text + "','" +
                benefitTB.Text + "','" + StatusTB.Text + "','" + purposeTB.Text + "','" + financingTB.Text + "','" + ProvideTB.Text + "')";
            com.ExecuteNonQuery();

            com.CommandText = "INSERT into t_tofficer (Toda_ID,Toda_Name, President, Vice_pres, Secretary, Treasurer, Auditor, Chairman, bMember1, bMember2, bMember3, bMember4) VALUES ('" +
                textBox1.Text + "','" + oNameTB.Text + "','" + presTB.Text + "','" + viceTB.Text + "','" + SecretaryTB.Text + "','" + treasurerTB.Text + "','" + auditorTB.Text + "','" + chairmanTB.Text + "','" +
                bm1TB.Text + "','" + bm2TB.Text + "','" + bm3TB.Text + "','" + bm4TB.Text + "','" + bm5TB.Text + "')";
            com.ExecuteNonQuery();
            con.Close();

        }
        public void GETmaxID()
        {
            string proID;
            string query = "SELECT Toda_ID FROM t_todainfo ORDER BY Toda_ID desc";

            con.Open();
            MySqlCommand com = new MySqlCommand(query, con);
            MySqlDataReader dr = com.ExecuteReader();

            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                proID = id.ToString("0000");
            }
            else if (Convert.IsDBNull(dr))
            {
                proID = ("0001");
            }
            else
            {
                proID = ("0001");
            }
            con.Close();

            textBox1.Text = proID.ToString();
        }

        private void requirementCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (requirementCB.Text == "Complete")
            {
                requirementTB.Clear();
                requirementTB.Enabled = false;
            }
            else
            {
                requirementTB.Enabled = true;
            }
        }

        private void LevelCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (LevelCB.Text == "Others... (Please Specify)...")
            {
                otherLevel.Visible = true;
            }
            else
            {
                otherLevel.Visible = false;
            }
        }

        private void AgencyCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (AgencyCB.Text == "Others... (Please Specify)...")
            {
                otherAgency.Visible = true;
            }
            else
            {
                otherAgency.Visible = false;
            }
        }

        private void Remove_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void viceTB_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
