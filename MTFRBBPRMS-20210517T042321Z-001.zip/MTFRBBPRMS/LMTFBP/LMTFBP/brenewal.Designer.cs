﻿namespace LMTFBP
{
    partial class brenewal
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(brenewal));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.specify = new System.Windows.Forms.TextBox();
            this.govtCB = new System.Windows.Forms.ComboBox();
            this.dtiNo = new System.Windows.Forms.TextBox();
            this.orgCB = new System.Windows.Forms.ComboBox();
            this.tinTB = new System.Windows.Forms.TextBox();
            this.ctcNo = new System.Windows.Forms.TextBox();
            this.referenceTB = new System.Windows.Forms.TextBox();
            this.dtiDate = new System.Windows.Forms.DateTimePicker();
            this.appDate = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tnameTB = new System.Windows.Forms.TextBox();
            this.bplateTB = new System.Windows.Forms.TextBox();
            this.bnameTB = new System.Windows.Forms.TextBox();
            this.suffixTB = new System.Windows.Forms.TextBox();
            this.lnameTB = new System.Windows.Forms.TextBox();
            this.mnameTB = new System.Windows.Forms.TextBox();
            this.fnameTB = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.psuffix = new System.Windows.Forms.TextBox();
            this.plname = new System.Windows.Forms.TextBox();
            this.pmname = new System.Windows.Forms.TextBox();
            this.pfname = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ctelnoTB = new System.Windows.Forms.TextBox();
            this.cfnameTB = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.oemailTB = new System.Windows.Forms.TextBox();
            this.otelnoTB = new System.Windows.Forms.TextBox();
            this.oprovTB = new System.Windows.Forms.TextBox();
            this.omunTB = new System.Windows.Forms.TextBox();
            this.osubdTB = new System.Windows.Forms.TextBox();
            this.obrgyTB = new System.Windows.Forms.TextBox();
            this.ostreetTB = new System.Windows.Forms.TextBox();
            this.ounitTB = new System.Windows.Forms.TextBox();
            this.obldgTB = new System.Windows.Forms.TextBox();
            this.ohouseTB = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.bemailTB = new System.Windows.Forms.TextBox();
            this.btelnoTB = new System.Windows.Forms.TextBox();
            this.bprovinceTB = new System.Windows.Forms.TextBox();
            this.bmunTB = new System.Windows.Forms.TextBox();
            this.bsubdTB = new System.Windows.Forms.TextBox();
            this.bbrgyTB = new System.Windows.Forms.TextBox();
            this.bstreetTB = new System.Windows.Forms.TextBox();
            this.bunitTB = new System.Windows.Forms.TextBox();
            this.bbldgTB = new System.Windows.Forms.TextBox();
            this.bhouseTB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.lemailTB = new System.Windows.Forms.TextBox();
            this.ltelnoTB = new System.Windows.Forms.TextBox();
            this.lprovTB = new System.Windows.Forms.TextBox();
            this.lmunTB = new System.Windows.Forms.TextBox();
            this.lbrgyTB = new System.Windows.Forms.TextBox();
            this.lstreetTB = new System.Windows.Forms.TextBox();
            this.lhouseTB = new System.Windows.Forms.TextBox();
            this.lmonthlyTB = new System.Windows.Forms.TextBox();
            this.llnameTB = new System.Windows.Forms.TextBox();
            this.lmiTB = new System.Windows.Forms.TextBox();
            this.lfnameTB = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.lguTB = new System.Windows.Forms.TextBox();
            this.bareaTB = new System.Windows.Forms.TextBox();
            this.establishTB = new System.Windows.Forms.TextBox();
            this.pinTB = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.bnonessentialTB = new System.Windows.Forms.TextBox();
            this.bessentialTB = new System.Windows.Forms.TextBox();
            this.bcapitalTB = new System.Windows.Forms.TextBox();
            this.bnounitTB = new System.Windows.Forms.TextBox();
            this.busilineTB = new System.Windows.Forms.TextBox();
            this.buscodeTB = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.paymentCB = new System.Windows.Forms.ComboBox();
            this.appType = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.transferCB = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.AmmendCB = new System.Windows.Forms.ComboBox();
            this.label41 = new System.Windows.Forms.Label();
            this.applicant_type = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.appNo = new WindowsFormsControlLibrary1.BunifuCustomTextbox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(0, 36);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1171, 10);
            this.panel1.TabIndex = 331;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 18);
            this.label1.TabIndex = 332;
            this.label1.Text = "Label1";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.specify);
            this.groupBox1.Controls.Add(this.govtCB);
            this.groupBox1.Controls.Add(this.dtiNo);
            this.groupBox1.Controls.Add(this.orgCB);
            this.groupBox1.Controls.Add(this.tinTB);
            this.groupBox1.Controls.Add(this.ctcNo);
            this.groupBox1.Controls.Add(this.referenceTB);
            this.groupBox1.Controls.Add(this.dtiDate);
            this.groupBox1.Controls.Add(this.appDate);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.groupBox1.Location = new System.Drawing.Point(48, 71);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1038, 73);
            this.groupBox1.TabIndex = 333;
            this.groupBox1.TabStop = false;
            // 
            // specify
            // 
            this.specify.Location = new System.Drawing.Point(860, 41);
            this.specify.Name = "specify";
            this.specify.Size = new System.Drawing.Size(154, 20);
            this.specify.TabIndex = 35;
            this.specify.Text = "Please Specify";
            this.specify.Visible = false;
            // 
            // govtCB
            // 
            this.govtCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.govtCB.FormattingEnabled = true;
            this.govtCB.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.govtCB.Location = new System.Drawing.Point(733, 41);
            this.govtCB.Name = "govtCB";
            this.govtCB.Size = new System.Drawing.Size(121, 21);
            this.govtCB.TabIndex = 34;
            this.govtCB.SelectedIndexChanged += new System.EventHandler(this.govtCB_SelectedIndexChanged);
            // 
            // dtiNo
            // 
            this.dtiNo.Location = new System.Drawing.Point(461, 42);
            this.dtiNo.Name = "dtiNo";
            this.dtiNo.Size = new System.Drawing.Size(95, 20);
            this.dtiNo.TabIndex = 33;
            // 
            // orgCB
            // 
            this.orgCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.orgCB.FormattingEnabled = true;
            this.orgCB.Items.AddRange(new object[] {
            "Single",
            "Partnership",
            "Corporation",
            "Cooperative",
            "Non-Profit Organization"});
            this.orgCB.Location = new System.Drawing.Point(849, 13);
            this.orgCB.Name = "orgCB";
            this.orgCB.Size = new System.Drawing.Size(165, 21);
            this.orgCB.TabIndex = 32;
            // 
            // tinTB
            // 
            this.tinTB.Location = new System.Drawing.Point(616, 15);
            this.tinTB.Name = "tinTB";
            this.tinTB.Size = new System.Drawing.Size(115, 20);
            this.tinTB.TabIndex = 31;
            // 
            // ctcNo
            // 
            this.ctcNo.Location = new System.Drawing.Point(468, 15);
            this.ctcNo.Name = "ctcNo";
            this.ctcNo.Size = new System.Drawing.Size(115, 20);
            this.ctcNo.TabIndex = 30;
            // 
            // referenceTB
            // 
            this.referenceTB.Location = new System.Drawing.Point(300, 15);
            this.referenceTB.Name = "referenceTB";
            this.referenceTB.Size = new System.Drawing.Size(115, 20);
            this.referenceTB.TabIndex = 29;
            // 
            // dtiDate
            // 
            this.dtiDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtiDate.Location = new System.Drawing.Point(184, 41);
            this.dtiDate.Name = "dtiDate";
            this.dtiDate.Size = new System.Drawing.Size(105, 20);
            this.dtiDate.TabIndex = 28;
            // 
            // appDate
            // 
            this.appDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.appDate.Location = new System.Drawing.Point(93, 14);
            this.appDate.Name = "appDate";
            this.appDate.Size = new System.Drawing.Size(129, 20);
            this.appDate.TabIndex = 27;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(562, 45);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(164, 13);
            this.label13.TabIndex = 24;
            this.label13.Text = "Enjoying Any Government Entity?";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(735, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(108, 13);
            this.label10.TabIndex = 19;
            this.label10.Text = "Type of Organization:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(587, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(28, 13);
            this.label12.TabIndex = 21;
            this.label12.Text = "TIN:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(419, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "CTC No.:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(226, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "Reference No.:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 13);
            this.label6.TabIndex = 26;
            this.label6.Text = "Application Date:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(295, 45);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(160, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "DTI/SEC/CDA Registration No.:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 44);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(166, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "DTI/SEC/CDA Registration Date:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tnameTB);
            this.groupBox2.Controls.Add(this.bplateTB);
            this.groupBox2.Controls.Add(this.bnameTB);
            this.groupBox2.Controls.Add(this.suffixTB);
            this.groupBox2.Controls.Add(this.lnameTB);
            this.groupBox2.Controls.Add(this.mnameTB);
            this.groupBox2.Controls.Add(this.fnameTB);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.groupBox2.Location = new System.Drawing.Point(48, 147);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(269, 197);
            this.groupBox2.TabIndex = 334;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Business Information";
            // 
            // tnameTB
            // 
            this.tnameTB.Location = new System.Drawing.Point(138, 170);
            this.tnameTB.Name = "tnameTB";
            this.tnameTB.Size = new System.Drawing.Size(131, 20);
            this.tnameTB.TabIndex = 33;
            // 
            // bplateTB
            // 
            this.bplateTB.Location = new System.Drawing.Point(138, 144);
            this.bplateTB.Name = "bplateTB";
            this.bplateTB.Size = new System.Drawing.Size(131, 20);
            this.bplateTB.TabIndex = 32;
            // 
            // bnameTB
            // 
            this.bnameTB.Location = new System.Drawing.Point(138, 118);
            this.bnameTB.Name = "bnameTB";
            this.bnameTB.Size = new System.Drawing.Size(131, 20);
            this.bnameTB.TabIndex = 31;
            // 
            // suffixTB
            // 
            this.suffixTB.Location = new System.Drawing.Point(138, 92);
            this.suffixTB.Name = "suffixTB";
            this.suffixTB.Size = new System.Drawing.Size(131, 20);
            this.suffixTB.TabIndex = 30;
            // 
            // lnameTB
            // 
            this.lnameTB.Location = new System.Drawing.Point(138, 66);
            this.lnameTB.Name = "lnameTB";
            this.lnameTB.Size = new System.Drawing.Size(131, 20);
            this.lnameTB.TabIndex = 29;
            // 
            // mnameTB
            // 
            this.mnameTB.Location = new System.Drawing.Point(138, 40);
            this.mnameTB.Name = "mnameTB";
            this.mnameTB.Size = new System.Drawing.Size(131, 20);
            this.mnameTB.TabIndex = 28;
            // 
            // fnameTB
            // 
            this.fnameTB.Location = new System.Drawing.Point(138, 14);
            this.fnameTB.Name = "fnameTB";
            this.fnameTB.Size = new System.Drawing.Size(131, 20);
            this.fnameTB.TabIndex = 27;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(10, 173);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(120, 13);
            this.label20.TabIndex = 23;
            this.label20.Text = "Trade Name/Franchise:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(10, 147);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(79, 13);
            this.label19.TabIndex = 24;
            this.label19.Text = "Business Plate:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(10, 95);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(36, 13);
            this.label17.TabIndex = 20;
            this.label17.Text = "Suffix:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(10, 121);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(83, 13);
            this.label18.TabIndex = 25;
            this.label18.Text = "Business Name:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(10, 43);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(68, 13);
            this.label16.TabIndex = 21;
            this.label16.Text = "Middle Initial:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(11, 17);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(60, 13);
            this.label15.TabIndex = 22;
            this.label15.Text = "First Name:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(10, 69);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 13);
            this.label14.TabIndex = 26;
            this.label14.Text = "Last Name:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.psuffix);
            this.groupBox3.Controls.Add(this.plname);
            this.groupBox3.Controls.Add(this.pmname);
            this.groupBox3.Controls.Add(this.pfname);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.groupBox3.Location = new System.Drawing.Point(48, 345);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(269, 120);
            this.groupBox3.TabIndex = 335;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "President/Treasurer of Corporation";
            // 
            // psuffix
            // 
            this.psuffix.Location = new System.Drawing.Point(138, 93);
            this.psuffix.Name = "psuffix";
            this.psuffix.Size = new System.Drawing.Size(131, 20);
            this.psuffix.TabIndex = 27;
            // 
            // plname
            // 
            this.plname.Location = new System.Drawing.Point(138, 67);
            this.plname.Name = "plname";
            this.plname.Size = new System.Drawing.Size(131, 20);
            this.plname.TabIndex = 26;
            // 
            // pmname
            // 
            this.pmname.Location = new System.Drawing.Point(138, 41);
            this.pmname.Name = "pmname";
            this.pmname.Size = new System.Drawing.Size(131, 20);
            this.pmname.TabIndex = 25;
            // 
            // pfname
            // 
            this.pfname.Location = new System.Drawing.Point(138, 15);
            this.pfname.Name = "pfname";
            this.pfname.Size = new System.Drawing.Size(131, 20);
            this.pfname.TabIndex = 24;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(11, 98);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(36, 13);
            this.label24.TabIndex = 23;
            this.label24.Text = "Suffix:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(11, 70);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(61, 13);
            this.label21.TabIndex = 20;
            this.label21.Text = "Last Name:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(11, 22);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(60, 13);
            this.label22.TabIndex = 21;
            this.label22.Text = "First Name:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(11, 45);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(68, 13);
            this.label23.TabIndex = 22;
            this.label23.Text = "Middle Initial:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.ctelnoTB);
            this.groupBox4.Controls.Add(this.cfnameTB);
            this.groupBox4.Controls.Add(this.label31);
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.groupBox4.Location = new System.Drawing.Point(48, 465);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(269, 68);
            this.groupBox4.TabIndex = 336;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "groupBox4";
            // 
            // ctelnoTB
            // 
            this.ctelnoTB.Location = new System.Drawing.Point(138, 42);
            this.ctelnoTB.Name = "ctelnoTB";
            this.ctelnoTB.Size = new System.Drawing.Size(131, 20);
            this.ctelnoTB.TabIndex = 26;
            // 
            // cfnameTB
            // 
            this.cfnameTB.Location = new System.Drawing.Point(138, 16);
            this.cfnameTB.Name = "cfnameTB";
            this.cfnameTB.Size = new System.Drawing.Size(131, 20);
            this.cfnameTB.TabIndex = 25;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(11, 45);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(104, 13);
            this.label31.TabIndex = 24;
            this.label31.Text = "Tel. No./Mobile No.:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(10, 19);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(55, 13);
            this.label30.TabIndex = 23;
            this.label30.Text = "Full name:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.oemailTB);
            this.groupBox5.Controls.Add(this.otelnoTB);
            this.groupBox5.Controls.Add(this.oprovTB);
            this.groupBox5.Controls.Add(this.omunTB);
            this.groupBox5.Controls.Add(this.osubdTB);
            this.groupBox5.Controls.Add(this.obrgyTB);
            this.groupBox5.Controls.Add(this.ostreetTB);
            this.groupBox5.Controls.Add(this.ounitTB);
            this.groupBox5.Controls.Add(this.obldgTB);
            this.groupBox5.Controls.Add(this.ohouseTB);
            this.groupBox5.Controls.Add(this.label47);
            this.groupBox5.Controls.Add(this.label43);
            this.groupBox5.Controls.Add(this.label48);
            this.groupBox5.Controls.Add(this.label42);
            this.groupBox5.Controls.Add(this.label46);
            this.groupBox5.Controls.Add(this.label44);
            this.groupBox5.Controls.Add(this.label51);
            this.groupBox5.Controls.Add(this.label45);
            this.groupBox5.Controls.Add(this.label49);
            this.groupBox5.Controls.Add(this.label50);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.groupBox5.Location = new System.Drawing.Point(319, 147);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(383, 145);
            this.groupBox5.TabIndex = 337;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Owner\'s Address";
            // 
            // oemailTB
            // 
            this.oemailTB.Location = new System.Drawing.Point(273, 117);
            this.oemailTB.Name = "oemailTB";
            this.oemailTB.Size = new System.Drawing.Size(104, 20);
            this.oemailTB.TabIndex = 43;
            // 
            // otelnoTB
            // 
            this.otelnoTB.Location = new System.Drawing.Point(273, 91);
            this.otelnoTB.Name = "otelnoTB";
            this.otelnoTB.Size = new System.Drawing.Size(104, 20);
            this.otelnoTB.TabIndex = 42;
            // 
            // oprovTB
            // 
            this.oprovTB.Location = new System.Drawing.Point(273, 65);
            this.oprovTB.Name = "oprovTB";
            this.oprovTB.Size = new System.Drawing.Size(104, 20);
            this.oprovTB.TabIndex = 41;
            // 
            // omunTB
            // 
            this.omunTB.Location = new System.Drawing.Point(273, 39);
            this.omunTB.Name = "omunTB";
            this.omunTB.Size = new System.Drawing.Size(104, 20);
            this.omunTB.TabIndex = 40;
            // 
            // osubdTB
            // 
            this.osubdTB.Location = new System.Drawing.Point(273, 13);
            this.osubdTB.Name = "osubdTB";
            this.osubdTB.Size = new System.Drawing.Size(104, 20);
            this.osubdTB.TabIndex = 39;
            // 
            // obrgyTB
            // 
            this.obrgyTB.Location = new System.Drawing.Point(80, 117);
            this.obrgyTB.Name = "obrgyTB";
            this.obrgyTB.Size = new System.Drawing.Size(101, 20);
            this.obrgyTB.TabIndex = 38;
            // 
            // ostreetTB
            // 
            this.ostreetTB.Location = new System.Drawing.Point(80, 91);
            this.ostreetTB.Name = "ostreetTB";
            this.ostreetTB.Size = new System.Drawing.Size(101, 20);
            this.ostreetTB.TabIndex = 37;
            // 
            // ounitTB
            // 
            this.ounitTB.Location = new System.Drawing.Point(80, 65);
            this.ounitTB.Name = "ounitTB";
            this.ounitTB.Size = new System.Drawing.Size(101, 20);
            this.ounitTB.TabIndex = 36;
            // 
            // obldgTB
            // 
            this.obldgTB.Location = new System.Drawing.Point(80, 39);
            this.obldgTB.Name = "obldgTB";
            this.obldgTB.Size = new System.Drawing.Size(101, 20);
            this.obldgTB.TabIndex = 35;
            // 
            // ohouseTB
            // 
            this.ohouseTB.Location = new System.Drawing.Point(105, 13);
            this.ohouseTB.Name = "ohouseTB";
            this.ohouseTB.Size = new System.Drawing.Size(76, 20);
            this.ohouseTB.TabIndex = 34;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(187, 118);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(76, 13);
            this.label47.TabIndex = 29;
            this.label47.Text = "Email Address:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(187, 66);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(52, 13);
            this.label43.TabIndex = 25;
            this.label43.Text = "Province:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(187, 92);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(84, 13);
            this.label48.TabIndex = 30;
            this.label48.Text = "Tel./Mobile No.:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(12, 39);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(62, 13);
            this.label42.TabIndex = 24;
            this.label42.Text = "Bldg Name:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(187, 40);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(65, 13);
            this.label46.TabIndex = 28;
            this.label46.Text = "Municipality:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(12, 118);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(55, 13);
            this.label44.TabIndex = 26;
            this.label44.Text = "Barangay:";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(11, 13);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(87, 13);
            this.label51.TabIndex = 33;
            this.label51.Text = "House/Bldg No.:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(12, 92);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(38, 13);
            this.label45.TabIndex = 27;
            this.label45.Text = "Street:";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(187, 14);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(35, 13);
            this.label49.TabIndex = 31;
            this.label49.Text = "Subd:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(12, 66);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(49, 13);
            this.label50.TabIndex = 32;
            this.label50.Text = "Unit No.:";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.bemailTB);
            this.groupBox6.Controls.Add(this.btelnoTB);
            this.groupBox6.Controls.Add(this.bprovinceTB);
            this.groupBox6.Controls.Add(this.bmunTB);
            this.groupBox6.Controls.Add(this.bsubdTB);
            this.groupBox6.Controls.Add(this.bbrgyTB);
            this.groupBox6.Controls.Add(this.bstreetTB);
            this.groupBox6.Controls.Add(this.bunitTB);
            this.groupBox6.Controls.Add(this.bbldgTB);
            this.groupBox6.Controls.Add(this.bhouseTB);
            this.groupBox6.Controls.Add(this.label4);
            this.groupBox6.Controls.Add(this.label5);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.label26);
            this.groupBox6.Controls.Add(this.label27);
            this.groupBox6.Controls.Add(this.label28);
            this.groupBox6.Controls.Add(this.label29);
            this.groupBox6.Controls.Add(this.label32);
            this.groupBox6.Controls.Add(this.label33);
            this.groupBox6.Controls.Add(this.label34);
            this.groupBox6.Controls.Add(this.checkBox1);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.groupBox6.Location = new System.Drawing.Point(703, 147);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(383, 145);
            this.groupBox6.TabIndex = 338;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "                                                                                 " +
    "";
            // 
            // bemailTB
            // 
            this.bemailTB.Location = new System.Drawing.Point(273, 117);
            this.bemailTB.Name = "bemailTB";
            this.bemailTB.Size = new System.Drawing.Size(104, 20);
            this.bemailTB.TabIndex = 53;
            // 
            // btelnoTB
            // 
            this.btelnoTB.Location = new System.Drawing.Point(273, 91);
            this.btelnoTB.Name = "btelnoTB";
            this.btelnoTB.Size = new System.Drawing.Size(104, 20);
            this.btelnoTB.TabIndex = 52;
            // 
            // bprovinceTB
            // 
            this.bprovinceTB.Location = new System.Drawing.Point(273, 65);
            this.bprovinceTB.Name = "bprovinceTB";
            this.bprovinceTB.Size = new System.Drawing.Size(104, 20);
            this.bprovinceTB.TabIndex = 51;
            // 
            // bmunTB
            // 
            this.bmunTB.Location = new System.Drawing.Point(273, 39);
            this.bmunTB.Name = "bmunTB";
            this.bmunTB.Size = new System.Drawing.Size(104, 20);
            this.bmunTB.TabIndex = 50;
            // 
            // bsubdTB
            // 
            this.bsubdTB.Location = new System.Drawing.Point(273, 13);
            this.bsubdTB.Name = "bsubdTB";
            this.bsubdTB.Size = new System.Drawing.Size(104, 20);
            this.bsubdTB.TabIndex = 49;
            // 
            // bbrgyTB
            // 
            this.bbrgyTB.Location = new System.Drawing.Point(78, 117);
            this.bbrgyTB.Name = "bbrgyTB";
            this.bbrgyTB.Size = new System.Drawing.Size(101, 20);
            this.bbrgyTB.TabIndex = 48;
            // 
            // bstreetTB
            // 
            this.bstreetTB.Location = new System.Drawing.Point(78, 91);
            this.bstreetTB.Name = "bstreetTB";
            this.bstreetTB.Size = new System.Drawing.Size(101, 20);
            this.bstreetTB.TabIndex = 47;
            // 
            // bunitTB
            // 
            this.bunitTB.Location = new System.Drawing.Point(78, 65);
            this.bunitTB.Name = "bunitTB";
            this.bunitTB.Size = new System.Drawing.Size(101, 20);
            this.bunitTB.TabIndex = 46;
            // 
            // bbldgTB
            // 
            this.bbldgTB.Location = new System.Drawing.Point(78, 39);
            this.bbldgTB.Name = "bbldgTB";
            this.bbldgTB.Size = new System.Drawing.Size(101, 20);
            this.bbldgTB.TabIndex = 45;
            // 
            // bhouseTB
            // 
            this.bhouseTB.Location = new System.Drawing.Point(103, 13);
            this.bhouseTB.Name = "bhouseTB";
            this.bhouseTB.Size = new System.Drawing.Size(76, 20);
            this.bhouseTB.TabIndex = 44;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(185, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 13);
            this.label4.TabIndex = 39;
            this.label4.Text = "Email Address:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(185, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 13);
            this.label5.TabIndex = 35;
            this.label5.Text = "Province:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(185, 94);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(84, 13);
            this.label25.TabIndex = 40;
            this.label25.Text = "Tel./Mobile No.:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(10, 42);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(62, 13);
            this.label26.TabIndex = 34;
            this.label26.Text = "Bldg Name:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(185, 42);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(65, 13);
            this.label27.TabIndex = 38;
            this.label27.Text = "Municipality:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(11, 120);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(55, 13);
            this.label28.TabIndex = 36;
            this.label28.Text = "Barangay:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(11, 16);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(87, 13);
            this.label29.TabIndex = 43;
            this.label29.Text = "House/Bldg No.:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(11, 94);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(38, 13);
            this.label32.TabIndex = 37;
            this.label32.Text = "Street:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(185, 16);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(35, 13);
            this.label33.TabIndex = 41;
            this.label33.Text = "Subd:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(10, 68);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(49, 13);
            this.label34.TabIndex = 42;
            this.label34.Text = "Unit No.:";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.Transparent;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.checkBox1.Location = new System.Drawing.Point(17, -2);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(243, 17);
            this.checkBox1.TabIndex = 54;
            this.checkBox1.Text = "Business Address Same with Owner\'s Address";
            this.checkBox1.UseVisualStyleBackColor = false;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.lemailTB);
            this.groupBox7.Controls.Add(this.ltelnoTB);
            this.groupBox7.Controls.Add(this.lprovTB);
            this.groupBox7.Controls.Add(this.lmunTB);
            this.groupBox7.Controls.Add(this.lbrgyTB);
            this.groupBox7.Controls.Add(this.lstreetTB);
            this.groupBox7.Controls.Add(this.lhouseTB);
            this.groupBox7.Controls.Add(this.lmonthlyTB);
            this.groupBox7.Controls.Add(this.llnameTB);
            this.groupBox7.Controls.Add(this.lmiTB);
            this.groupBox7.Controls.Add(this.lfnameTB);
            this.groupBox7.Controls.Add(this.label57);
            this.groupBox7.Controls.Add(this.label56);
            this.groupBox7.Controls.Add(this.label58);
            this.groupBox7.Controls.Add(this.label53);
            this.groupBox7.Controls.Add(this.label59);
            this.groupBox7.Controls.Add(this.label60);
            this.groupBox7.Controls.Add(this.label61);
            this.groupBox7.Controls.Add(this.label54);
            this.groupBox7.Controls.Add(this.label52);
            this.groupBox7.Controls.Add(this.label55);
            this.groupBox7.Controls.Add(this.label62);
            this.groupBox7.Enabled = false;
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.groupBox7.Location = new System.Drawing.Point(319, 293);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(767, 85);
            this.groupBox7.TabIndex = 339;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "                                           ";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.checkBox2.Location = new System.Drawing.Point(327, 292);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(128, 17);
            this.checkBox2.TabIndex = 166;
            this.checkBox2.Text = "If Business is Rented.";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // lemailTB
            // 
            this.lemailTB.Location = new System.Drawing.Point(255, 62);
            this.lemailTB.Name = "lemailTB";
            this.lemailTB.Size = new System.Drawing.Size(163, 20);
            this.lemailTB.TabIndex = 64;
            this.lemailTB.Text = "N/A";
            // 
            // ltelnoTB
            // 
            this.ltelnoTB.Location = new System.Drawing.Point(66, 62);
            this.ltelnoTB.Name = "ltelnoTB";
            this.ltelnoTB.Size = new System.Drawing.Size(115, 20);
            this.ltelnoTB.TabIndex = 63;
            this.ltelnoTB.Text = "N/A";
            // 
            // lprovTB
            // 
            this.lprovTB.Location = new System.Drawing.Point(613, 39);
            this.lprovTB.Name = "lprovTB";
            this.lprovTB.Size = new System.Drawing.Size(86, 20);
            this.lprovTB.TabIndex = 62;
            this.lprovTB.Text = "N/A";
            // 
            // lmunTB
            // 
            this.lmunTB.Location = new System.Drawing.Point(472, 39);
            this.lmunTB.Name = "lmunTB";
            this.lmunTB.Size = new System.Drawing.Size(86, 20);
            this.lmunTB.TabIndex = 61;
            this.lmunTB.Text = "N/A";
            // 
            // lbrgyTB
            // 
            this.lbrgyTB.Location = new System.Drawing.Point(306, 39);
            this.lbrgyTB.Name = "lbrgyTB";
            this.lbrgyTB.Size = new System.Drawing.Size(101, 20);
            this.lbrgyTB.TabIndex = 60;
            this.lbrgyTB.Text = "N/A";
            // 
            // lstreetTB
            // 
            this.lstreetTB.Location = new System.Drawing.Point(169, 39);
            this.lstreetTB.Name = "lstreetTB";
            this.lstreetTB.Size = new System.Drawing.Size(80, 20);
            this.lstreetTB.TabIndex = 59;
            this.lstreetTB.Text = "N/A";
            // 
            // lhouseTB
            // 
            this.lhouseTB.Location = new System.Drawing.Point(68, 39);
            this.lhouseTB.Name = "lhouseTB";
            this.lhouseTB.Size = new System.Drawing.Size(59, 20);
            this.lhouseTB.TabIndex = 58;
            this.lhouseTB.Text = "N/A";
            // 
            // lmonthlyTB
            // 
            this.lmonthlyTB.Location = new System.Drawing.Point(528, 16);
            this.lmonthlyTB.Name = "lmonthlyTB";
            this.lmonthlyTB.Size = new System.Drawing.Size(107, 20);
            this.lmonthlyTB.TabIndex = 57;
            this.lmonthlyTB.Text = "N/A";
            // 
            // llnameTB
            // 
            this.llnameTB.Location = new System.Drawing.Point(349, 16);
            this.llnameTB.Name = "llnameTB";
            this.llnameTB.Size = new System.Drawing.Size(107, 20);
            this.llnameTB.TabIndex = 56;
            this.llnameTB.Text = "N/A";
            // 
            // lmiTB
            // 
            this.lmiTB.Location = new System.Drawing.Point(201, 16);
            this.lmiTB.Name = "lmiTB";
            this.lmiTB.Size = new System.Drawing.Size(86, 20);
            this.lmiTB.TabIndex = 55;
            this.lmiTB.Text = "N/A";
            // 
            // lfnameTB
            // 
            this.lfnameTB.Location = new System.Drawing.Point(68, 16);
            this.lfnameTB.Name = "lfnameTB";
            this.lfnameTB.Size = new System.Drawing.Size(99, 20);
            this.lfnameTB.TabIndex = 54;
            this.lfnameTB.Text = "N/A";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(131, 42);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(38, 13);
            this.label57.TabIndex = 53;
            this.label57.Text = "Street:";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(11, 42);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(61, 13);
            this.label56.TabIndex = 47;
            this.label56.Text = "House No.:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(254, 42);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(55, 13);
            this.label58.TabIndex = 49;
            this.label58.Text = "Barangay:";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(11, 19);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(60, 13);
            this.label53.TabIndex = 45;
            this.label53.Text = "First Name:";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(411, 42);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(65, 13);
            this.label59.TabIndex = 51;
            this.label59.Text = "Municipality:";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(563, 42);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(52, 13);
            this.label60.TabIndex = 48;
            this.label60.Text = "Province:";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(11, 64);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(48, 13);
            this.label61.TabIndex = 52;
            this.label61.Text = "Tel. No.:";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(171, 19);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(28, 13);
            this.label54.TabIndex = 46;
            this.label54.Text = "M.I.:";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(291, 19);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(61, 13);
            this.label52.TabIndex = 44;
            this.label52.Text = "Last Name:";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(460, 19);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(73, 13);
            this.label55.TabIndex = 43;
            this.label55.Text = "Monthly Rent:";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(185, 64);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(76, 13);
            this.label62.TabIndex = 50;
            this.label62.Text = "Email Address:";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.lguTB);
            this.groupBox8.Controls.Add(this.bareaTB);
            this.groupBox8.Controls.Add(this.establishTB);
            this.groupBox8.Controls.Add(this.pinTB);
            this.groupBox8.Controls.Add(this.label35);
            this.groupBox8.Controls.Add(this.label36);
            this.groupBox8.Controls.Add(this.label37);
            this.groupBox8.Controls.Add(this.label38);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.groupBox8.Location = new System.Drawing.Point(319, 377);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(627, 61);
            this.groupBox8.TabIndex = 340;
            this.groupBox8.TabStop = false;
            // 
            // lguTB
            // 
            this.lguTB.Location = new System.Drawing.Point(479, 36);
            this.lguTB.Name = "lguTB";
            this.lguTB.Size = new System.Drawing.Size(81, 20);
            this.lguTB.TabIndex = 27;
            // 
            // bareaTB
            // 
            this.bareaTB.Location = new System.Drawing.Point(426, 10);
            this.bareaTB.Name = "bareaTB";
            this.bareaTB.Size = new System.Drawing.Size(134, 20);
            this.bareaTB.TabIndex = 26;
            // 
            // establishTB
            // 
            this.establishTB.Location = new System.Drawing.Point(216, 36);
            this.establishTB.Name = "establishTB";
            this.establishTB.Size = new System.Drawing.Size(78, 20);
            this.establishTB.TabIndex = 25;
            // 
            // pinTB
            // 
            this.pinTB.Location = new System.Drawing.Point(159, 10);
            this.pinTB.Name = "pinTB";
            this.pinTB.Size = new System.Drawing.Size(134, 20);
            this.pinTB.TabIndex = 24;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(299, 13);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(121, 13);
            this.label35.TabIndex = 20;
            this.label35.Text = "Business Area (in sq/m):";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(300, 39);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(173, 13);
            this.label36.TabIndex = 21;
            this.label36.Text = "No. of Employees Residing in LGU:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(10, 39);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(199, 13);
            this.label37.TabIndex = 22;
            this.label37.Text = "Total No. of Employees in Establishment:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(11, 13);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(142, 13);
            this.label38.TabIndex = 23;
            this.label38.Text = "Property Index Number(PIN):";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.bnonessentialTB);
            this.groupBox9.Controls.Add(this.bessentialTB);
            this.groupBox9.Controls.Add(this.bcapitalTB);
            this.groupBox9.Controls.Add(this.bnounitTB);
            this.groupBox9.Controls.Add(this.busilineTB);
            this.groupBox9.Controls.Add(this.buscodeTB);
            this.groupBox9.Controls.Add(this.panel6);
            this.groupBox9.Controls.Add(this.panel5);
            this.groupBox9.Controls.Add(this.panel4);
            this.groupBox9.Controls.Add(this.panel3);
            this.groupBox9.Controls.Add(this.panel2);
            this.groupBox9.Controls.Add(this.label67);
            this.groupBox9.Controls.Add(this.label66);
            this.groupBox9.Controls.Add(this.label69);
            this.groupBox9.Controls.Add(this.label68);
            this.groupBox9.Controls.Add(this.label65);
            this.groupBox9.Controls.Add(this.label64);
            this.groupBox9.Controls.Add(this.label63);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.groupBox9.Location = new System.Drawing.Point(319, 440);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(627, 94);
            this.groupBox9.TabIndex = 341;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Business Activity";
            // 
            // bnonessentialTB
            // 
            this.bnonessentialTB.Location = new System.Drawing.Point(532, 35);
            this.bnonessentialTB.Multiline = true;
            this.bnonessentialTB.Name = "bnonessentialTB";
            this.bnonessentialTB.Size = new System.Drawing.Size(87, 53);
            this.bnonessentialTB.TabIndex = 38;
            // 
            // bessentialTB
            // 
            this.bessentialTB.Location = new System.Drawing.Point(429, 35);
            this.bessentialTB.Multiline = true;
            this.bessentialTB.Name = "bessentialTB";
            this.bessentialTB.Size = new System.Drawing.Size(91, 53);
            this.bessentialTB.TabIndex = 37;
            // 
            // bcapitalTB
            // 
            this.bcapitalTB.Location = new System.Drawing.Point(308, 36);
            this.bcapitalTB.Multiline = true;
            this.bcapitalTB.Name = "bcapitalTB";
            this.bcapitalTB.Size = new System.Drawing.Size(108, 52);
            this.bcapitalTB.TabIndex = 36;
            // 
            // bnounitTB
            // 
            this.bnounitTB.Location = new System.Drawing.Point(210, 35);
            this.bnounitTB.Multiline = true;
            this.bnounitTB.Name = "bnounitTB";
            this.bnounitTB.Size = new System.Drawing.Size(86, 53);
            this.bnounitTB.TabIndex = 35;
            // 
            // busilineTB
            // 
            this.busilineTB.Location = new System.Drawing.Point(109, 34);
            this.busilineTB.Multiline = true;
            this.busilineTB.Name = "busilineTB";
            this.busilineTB.Size = new System.Drawing.Size(90, 54);
            this.busilineTB.TabIndex = 34;
            // 
            // buscodeTB
            // 
            this.buscodeTB.Location = new System.Drawing.Point(9, 34);
            this.buscodeTB.Multiline = true;
            this.buscodeTB.Name = "buscodeTB";
            this.buscodeTB.Size = new System.Drawing.Size(93, 54);
            this.buscodeTB.TabIndex = 33;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Gray;
            this.panel6.Location = new System.Drawing.Point(525, 20);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(3, 72);
            this.panel6.TabIndex = 32;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Gray;
            this.panel5.Location = new System.Drawing.Point(420, 7);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(3, 85);
            this.panel5.TabIndex = 31;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gray;
            this.panel4.Location = new System.Drawing.Point(299, 7);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(3, 85);
            this.panel4.TabIndex = 30;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gray;
            this.panel3.Location = new System.Drawing.Point(201, 7);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(3, 85);
            this.panel3.TabIndex = 29;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Location = new System.Drawing.Point(104, 7);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(3, 85);
            this.panel2.TabIndex = 28;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(448, 6);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(171, 13);
            this.label67.TabIndex = 21;
            this.label67.Text = "Gross Sales/Receipts (for renewal)";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(317, 7);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(92, 26);
            this.label66.TabIndex = 22;
            this.label66.Text = "  Capitalization\r\n(for new business)";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(542, 20);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(72, 13);
            this.label69.TabIndex = 23;
            this.label69.Text = "Non-Essential";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(448, 20);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(49, 13);
            this.label68.TabIndex = 24;
            this.label68.Text = "Essential";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(222, 20);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(63, 13);
            this.label65.TabIndex = 25;
            this.label65.Text = "No. of Units";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(113, 19);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(84, 13);
            this.label64.TabIndex = 26;
            this.label64.Text = "Line of Business";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(16, 19);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(77, 13);
            this.label63.TabIndex = 27;
            this.label63.Text = "Business Code";
            // 
            // paymentCB
            // 
            this.paymentCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.paymentCB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentCB.FormattingEnabled = true;
            this.paymentCB.Items.AddRange(new object[] {
            "Annually",
            "Semi-Annually",
            "Quarterly"});
            this.paymentCB.Location = new System.Drawing.Point(531, 51);
            this.paymentCB.Name = "paymentCB";
            this.paymentCB.Size = new System.Drawing.Size(115, 21);
            this.paymentCB.TabIndex = 348;
            // 
            // appType
            // 
            this.appType.Enabled = false;
            this.appType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appType.Location = new System.Drawing.Point(318, 51);
            this.appType.Name = "appType";
            this.appType.Size = new System.Drawing.Size(108, 20);
            this.appType.TabIndex = 347;
            this.appType.Text = "Renewal";
            this.appType.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(432, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 13);
            this.label2.TabIndex = 344;
            this.label2.Text = "Mode of Payment:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(231, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 345;
            this.label3.Text = "Applicant Type:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(45, 54);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(74, 13);
            this.label39.TabIndex = 343;
            this.label39.Text = "Applicant No.:";
            // 
            // transferCB
            // 
            this.transferCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.transferCB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transferCB.FormattingEnabled = true;
            this.transferCB.Items.AddRange(new object[] {
            "Ownership",
            "Location"});
            this.transferCB.Location = new System.Drawing.Point(724, 51);
            this.transferCB.Name = "transferCB";
            this.transferCB.Size = new System.Drawing.Size(116, 21);
            this.transferCB.TabIndex = 350;
            this.transferCB.Visible = false;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(652, 54);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(66, 13);
            this.label40.TabIndex = 349;
            this.label40.Text = "Transferring:";
            this.label40.Visible = false;
            // 
            // AmmendCB
            // 
            this.AmmendCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AmmendCB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AmmendCB.FormattingEnabled = true;
            this.AmmendCB.Items.AddRange(new object[] {
            "Single to Partnership",
            "Single to Corporation",
            "Partnership to Single",
            "Partnership to Corporation",
            "Corporation to Single",
            "Corporation to Partnership"});
            this.AmmendCB.Location = new System.Drawing.Point(953, 51);
            this.AmmendCB.Name = "AmmendCB";
            this.AmmendCB.Size = new System.Drawing.Size(133, 21);
            this.AmmendCB.TabIndex = 352;
            this.AmmendCB.Visible = false;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(846, 54);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(101, 13);
            this.label41.TabIndex = 351;
            this.label41.Text = "Ammendment Type:";
            this.label41.Visible = false;
            // 
            // applicant_type
            // 
            this.applicant_type.Location = new System.Drawing.Point(834, 7);
            this.applicant_type.Name = "applicant_type";
            this.applicant_type.Size = new System.Drawing.Size(100, 20);
            this.applicant_type.TabIndex = 354;
            this.applicant_type.Visible = false;
            this.applicant_type.TextChanged += new System.EventHandler(this.applicant_type_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(716, 8);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 355;
            this.textBox1.Visible = false;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // appNo
            // 
            this.appNo.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.appNo.Enabled = false;
            this.appNo.Location = new System.Drawing.Point(125, 51);
            this.appNo.Name = "appNo";
            this.appNo.Size = new System.Drawing.Size(100, 20);
            this.appNo.TabIndex = 356;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(331, 13);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 357;
            this.textBox2.Visible = false;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // button2
            // 
            this.button2.Activecolor = System.Drawing.Color.Transparent;
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.BorderRadius = 0;
            this.button2.ButtonText = "Save";
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.DisabledColor = System.Drawing.Color.Gray;
            this.button2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button2.Iconcolor = System.Drawing.Color.Transparent;
            this.button2.Iconimage = ((System.Drawing.Image)(resources.GetObject("button2.Iconimage")));
            this.button2.Iconimage_right = null;
            this.button2.Iconimage_right_Selected = null;
            this.button2.Iconimage_Selected = null;
            this.button2.IconMarginLeft = 10;
            this.button2.IconMarginRight = 0;
            this.button2.IconRightVisible = true;
            this.button2.IconRightZoom = 0D;
            this.button2.IconVisible = true;
            this.button2.IconZoom = 35D;
            this.button2.IsTab = false;
            this.button2.Location = new System.Drawing.Point(976, 493);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Normalcolor = System.Drawing.Color.Transparent;
            this.button2.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.button2.OnHoverTextColor = System.Drawing.Color.Black;
            this.button2.selected = false;
            this.button2.Size = new System.Drawing.Size(136, 30);
            this.button2.TabIndex = 342;
            this.button2.Text = "Save";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Textcolor = System.Drawing.Color.Black;
            this.button2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // brenewal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.appNo);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.applicant_type);
            this.Controls.Add(this.AmmendCB);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.transferCB);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.paymentCB);
            this.Controls.Add(this.appType);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.Name = "brenewal";
            this.Size = new System.Drawing.Size(1165, 548);
            this.Load += new System.EventHandler(this.brenewal_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label label20;
        public System.Windows.Forms.Label label19;
        public System.Windows.Forms.Label label17;
        public System.Windows.Forms.Label label18;
        public System.Windows.Forms.Label label16;
        public System.Windows.Forms.Label label15;
        public System.Windows.Forms.Label label14;
        public System.Windows.Forms.Label label24;
        public System.Windows.Forms.Label label21;
        public System.Windows.Forms.Label label22;
        public System.Windows.Forms.Label label23;
        public System.Windows.Forms.Label label31;
        public System.Windows.Forms.Label label30;
        public System.Windows.Forms.Label label47;
        public System.Windows.Forms.Label label43;
        public System.Windows.Forms.Label label48;
        public System.Windows.Forms.Label label42;
        public System.Windows.Forms.Label label46;
        public System.Windows.Forms.Label label44;
        public System.Windows.Forms.Label label51;
        public System.Windows.Forms.Label label45;
        public System.Windows.Forms.Label label49;
        public System.Windows.Forms.Label label50;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label25;
        public System.Windows.Forms.Label label26;
        public System.Windows.Forms.Label label27;
        public System.Windows.Forms.Label label28;
        public System.Windows.Forms.Label label29;
        public System.Windows.Forms.Label label32;
        public System.Windows.Forms.Label label33;
        public System.Windows.Forms.Label label34;
        public System.Windows.Forms.CheckBox checkBox2;
        public System.Windows.Forms.Label label57;
        public System.Windows.Forms.Label label56;
        public System.Windows.Forms.Label label58;
        public System.Windows.Forms.Label label53;
        public System.Windows.Forms.Label label59;
        public System.Windows.Forms.Label label60;
        public System.Windows.Forms.Label label61;
        public System.Windows.Forms.Label label54;
        public System.Windows.Forms.Label label52;
        public System.Windows.Forms.Label label55;
        public System.Windows.Forms.Label label62;
        public System.Windows.Forms.Label label35;
        public System.Windows.Forms.Label label36;
        public System.Windows.Forms.Label label37;
        public System.Windows.Forms.Label label38;
        public System.Windows.Forms.Panel panel6;
        public System.Windows.Forms.Panel panel5;
        public System.Windows.Forms.Panel panel4;
        public System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.Label label67;
        public System.Windows.Forms.Label label66;
        public System.Windows.Forms.Label label69;
        public System.Windows.Forms.Label label68;
        public System.Windows.Forms.Label label65;
        public System.Windows.Forms.Label label64;
        public System.Windows.Forms.Label label63;
        public System.Windows.Forms.ComboBox paymentCB;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label39;
        public System.Windows.Forms.ComboBox transferCB;
        public System.Windows.Forms.Label label40;
        public System.Windows.Forms.ComboBox AmmendCB;
        public System.Windows.Forms.Label label41;
        public System.Windows.Forms.TextBox applicant_type;
        public System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.TextBox specify;
        public System.Windows.Forms.ComboBox govtCB;
        public System.Windows.Forms.TextBox dtiNo;
        public System.Windows.Forms.ComboBox orgCB;
        public System.Windows.Forms.TextBox tinTB;
        public System.Windows.Forms.TextBox ctcNo;
        public System.Windows.Forms.TextBox referenceTB;
        public System.Windows.Forms.DateTimePicker dtiDate;
        public System.Windows.Forms.DateTimePicker appDate;
        public System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.TextBox tnameTB;
        public System.Windows.Forms.TextBox bplateTB;
        public System.Windows.Forms.TextBox bnameTB;
        public System.Windows.Forms.TextBox suffixTB;
        public System.Windows.Forms.TextBox lnameTB;
        public System.Windows.Forms.TextBox mnameTB;
        public System.Windows.Forms.TextBox fnameTB;
        public System.Windows.Forms.GroupBox groupBox3;
        public System.Windows.Forms.TextBox psuffix;
        public System.Windows.Forms.TextBox plname;
        public System.Windows.Forms.TextBox pmname;
        public System.Windows.Forms.TextBox pfname;
        public System.Windows.Forms.GroupBox groupBox4;
        public System.Windows.Forms.TextBox ctelnoTB;
        public System.Windows.Forms.TextBox cfnameTB;
        public System.Windows.Forms.GroupBox groupBox5;
        public System.Windows.Forms.TextBox oemailTB;
        public System.Windows.Forms.TextBox otelnoTB;
        public System.Windows.Forms.TextBox oprovTB;
        public System.Windows.Forms.TextBox omunTB;
        public System.Windows.Forms.TextBox osubdTB;
        public System.Windows.Forms.TextBox obrgyTB;
        public System.Windows.Forms.TextBox ostreetTB;
        public System.Windows.Forms.TextBox ounitTB;
        public System.Windows.Forms.TextBox obldgTB;
        public System.Windows.Forms.TextBox ohouseTB;
        public System.Windows.Forms.GroupBox groupBox6;
        public System.Windows.Forms.CheckBox checkBox1;
        public System.Windows.Forms.TextBox bemailTB;
        public System.Windows.Forms.TextBox btelnoTB;
        public System.Windows.Forms.TextBox bprovinceTB;
        public System.Windows.Forms.TextBox bmunTB;
        public System.Windows.Forms.TextBox bsubdTB;
        public System.Windows.Forms.TextBox bbrgyTB;
        public System.Windows.Forms.TextBox bstreetTB;
        public System.Windows.Forms.TextBox bunitTB;
        public System.Windows.Forms.TextBox bbldgTB;
        public System.Windows.Forms.TextBox bhouseTB;
        public System.Windows.Forms.GroupBox groupBox7;
        public System.Windows.Forms.TextBox lemailTB;
        public System.Windows.Forms.TextBox ltelnoTB;
        public System.Windows.Forms.TextBox lprovTB;
        public System.Windows.Forms.TextBox lmunTB;
        public System.Windows.Forms.TextBox lbrgyTB;
        public System.Windows.Forms.TextBox lstreetTB;
        public System.Windows.Forms.TextBox lhouseTB;
        public System.Windows.Forms.TextBox lmonthlyTB;
        public System.Windows.Forms.TextBox llnameTB;
        public System.Windows.Forms.TextBox lmiTB;
        public System.Windows.Forms.TextBox lfnameTB;
        public System.Windows.Forms.GroupBox groupBox8;
        public System.Windows.Forms.TextBox lguTB;
        public System.Windows.Forms.TextBox bareaTB;
        public System.Windows.Forms.TextBox establishTB;
        public System.Windows.Forms.TextBox pinTB;
        public System.Windows.Forms.GroupBox groupBox9;
        public System.Windows.Forms.TextBox bnonessentialTB;
        public System.Windows.Forms.TextBox bessentialTB;
        public System.Windows.Forms.TextBox bcapitalTB;
        public System.Windows.Forms.TextBox bnounitTB;
        public System.Windows.Forms.TextBox busilineTB;
        public System.Windows.Forms.TextBox buscodeTB;
        public Bunifu.Framework.UI.BunifuFlatButton button2;
        public System.Windows.Forms.TextBox appType;
        public System.Windows.Forms.TextBox textBox1;
        public WindowsFormsControlLibrary1.BunifuCustomTextbox appNo;
        private System.Windows.Forms.TextBox textBox2;
    }
}
