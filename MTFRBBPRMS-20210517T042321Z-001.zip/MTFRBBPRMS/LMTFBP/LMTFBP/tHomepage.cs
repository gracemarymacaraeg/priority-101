﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class tHomepage : Form
    {
        MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public tHomepage()
        {
            InitializeComponent();
        }

        private void tHomepage_Load(object sender, EventArgs e)
        {
            if (Search.text == "")
            {
                SearchBtn.Visible = false;
            }
            else
            {
                SearchBtn.Visible = true;
            }

            if (uTypeLbl.Text == "Admin")
            {
                AddNew.Visible = false;
                bunifuFlatButton3.Visible = true;
                bunifuFlatButton2.Visible = false;
            }
            else
            {
                AddNew.Visible = true;
                bunifuFlatButton3.Visible = false;
                bunifuFlatButton2.Visible = true;
            }

            if (DepartmentLbl.Text == "Treasury Office")
            {
                bunifuFlatButton2.Visible = false;
                bunifuFlatButton3.Visible = false;
                AddNew.Visible = false;
            }
            else
            {
                bunifuFlatButton2.Visible = true;
                bunifuFlatButton3.Visible = true;
                AddNew.Visible = true;
            }
        }

        private void AddNew_Click(object sender, EventArgs e)
        {
            var uc1 = new NewApplication();
            panel3.Controls.Clear();
            panel3.Controls.Add(uc1);
            uc1.textBox1.Text = nameLbl.Text;
        }

        private void ViewRecords_Click(object sender, EventArgs e)
        {
            var uc1 = new tViewRecords();
            panel3.Controls.Clear();
            panel3.Controls.Add(uc1);
            uc1.textBox3.Text = nameLbl.Text;
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            var uc1 = new tApplication();
            panel3.Controls.Clear();
            panel3.Controls.Add(uc1);
        }

        private void Home_Click(object sender, EventArgs e)
        {
            panel3.Controls.Clear();
        }

        private void LogOut_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Sure to Logout?", "Warning!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if(result == DialogResult.Yes)
            {
                this.Close();
            }

        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SearchBtn_Click(object sender, EventArgs e)
        {
            var uc1 = new tView();
            panel3.Controls.Clear();
            panel3.Controls.Add(uc1);
            uc1.label4.Visible = false;
            uc1.label2.Visible = false;
            uc1.ViewRecords.Rows.Clear();
            con.Open();
            com = con.CreateCommand();
            com.CommandText = "SELECT * FROM t_records WHERE Lname = '" + Search.text + "' or Fname = '"+ Search.text + "' or Applicant_ID = '"+ Search.text + "'";
            reader = com.ExecuteReader();
            while (reader.Read())
            {
                uc1.ViewRecords.Rows.Add(reader[1].ToString(), reader[2].ToString(),
                reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), reader[6].ToString(),
                reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString(),
                reader[11].ToString(), reader[12].ToString(), reader[13].ToString(),
                reader[14].ToString(), reader[16].ToString(),
                reader[19].ToString(), reader[20].ToString());
            }
            reader.Close();
            com.ExecuteNonQuery();
            com = con.CreateCommand();
            com.CommandText = "SELECT * FROM t_renew WHERE Lname = '" + Search.text + "' or Fname = '" + Search.text + "' or Applicant_ID = '" + Search.text + "'";
            reader = com.ExecuteReader();
            while (reader.Read())
            {
                uc1.ViewRecords.Rows.Add(reader[1].ToString(), reader[2].ToString(),
                reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), reader[6].ToString(),
                reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString(),
                reader[11].ToString(), reader[12].ToString(), reader[13].ToString(),
                reader[14].ToString(), reader[16].ToString(),
                reader[19].ToString(), reader[20].ToString());
            }
            reader.Close();
            com.ExecuteNonQuery();
            con.Close();
            uc1.label2.Text = uc1.ViewRecords.Rows.Count.ToString();
        }

        private void Search_OnTextChange(object sender, EventArgs e)
        {
            if (Search.text == "")
            {
                SearchBtn.Visible = false;
            }
            else
            {
                SearchBtn.Visible = true;
            }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            var uc1 = new OrgList();
            panel3.Controls.Clear();
            panel3.Controls.Add(uc1);
        }

        private void nameLbl_Click(object sender, EventArgs e)
        {
            
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            var uc1 = new Account();
            panel3.Controls.Clear();
            panel3.Controls.Add(uc1);
        }
    }
}
