﻿namespace LMTFBP
{
    partial class tCreateAcct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(tCreateAcct));
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.Usertype = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.AccID = new System.Windows.Forms.TextBox();
            this.Fname = new System.Windows.Forms.TextBox();
            this.Mname = new System.Windows.Forms.TextBox();
            this.Lname = new System.Windows.Forms.TextBox();
            this.Suffix = new System.Windows.Forms.TextBox();
            this.Bday = new System.Windows.Forms.DateTimePicker();
            this.Gender = new System.Windows.Forms.ComboBox();
            this.Contact = new System.Windows.Forms.TextBox();
            this.Username = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.TextBox();
            this.Repass = new System.Windows.Forms.TextBox();
            this.Dept = new System.Windows.Forms.ComboBox();
            this.Type = new System.Windows.Forms.ComboBox();
            this.CreateAcc = new Bunifu.Framework.UI.BunifuFlatButton();
            this.CheckUsername = new System.Windows.Forms.Button();
            this.LblStatus = new System.Windows.Forms.Label();
            this.Close = new Bunifu.Framework.UI.BunifuImageButton();
            ((System.ComponentModel.ISupportInitialize)(this.Close)).BeginInit();
            this.SuspendLayout();
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.Transparent;
            this.checkBox1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(468, 240);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(108, 18);
            this.checkBox1.TabIndex = 51;
            this.checkBox1.Text = "Show Password";
            this.checkBox1.UseVisualStyleBackColor = false;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Location = new System.Drawing.Point(322, 219);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(118, 16);
            this.label13.TabIndex = 50;
            this.label13.Text = "Re-type Password:";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // Usertype
            // 
            this.Usertype.AutoSize = true;
            this.Usertype.BackColor = System.Drawing.Color.Transparent;
            this.Usertype.Location = new System.Drawing.Point(167, 274);
            this.Usertype.Name = "Usertype";
            this.Usertype.Size = new System.Drawing.Size(64, 16);
            this.Usertype.TabIndex = 48;
            this.Usertype.Text = "Usertype:";
            this.Usertype.Click += new System.EventHandler(this.Usertype_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Location = new System.Drawing.Point(13, 274);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 16);
            this.label12.TabIndex = 49;
            this.label12.Text = "Department:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Location = new System.Drawing.Point(167, 219);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 16);
            this.label11.TabIndex = 47;
            this.label11.Text = "Password:";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Location = new System.Drawing.Point(13, 219);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 16);
            this.label10.TabIndex = 46;
            this.label10.Text = "Username:";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Location = new System.Drawing.Point(322, 157);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 16);
            this.label9.TabIndex = 45;
            this.label9.Text = "Contact No.:";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Location = new System.Drawing.Point(167, 157);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 16);
            this.label7.TabIndex = 44;
            this.label7.Text = "Gender:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(13, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 16);
            this.label6.TabIndex = 43;
            this.label6.Text = "Birthday:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(476, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 16);
            this.label5.TabIndex = 42;
            this.label5.Text = "Suffix:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(322, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 16);
            this.label4.TabIndex = 41;
            this.label4.Text = "Last Name:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(167, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 40;
            this.label3.Text = "Middle Name:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Location = new System.Drawing.Point(13, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 16);
            this.label8.TabIndex = 38;
            this.label8.Text = "Account ID:";
            this.label8.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(13, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 16);
            this.label2.TabIndex = 39;
            this.label2.Text = "First Name:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(13, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(378, 18);
            this.label1.TabIndex = 37;
            this.label1.Text = "Create Account for Tricycle Franchise";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(0, 41);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(710, 10);
            this.panel1.TabIndex = 52;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // AccID
            // 
            this.AccID.Location = new System.Drawing.Point(95, 57);
            this.AccID.Name = "AccID";
            this.AccID.Size = new System.Drawing.Size(100, 22);
            this.AccID.TabIndex = 53;
            this.AccID.Visible = false;
            this.AccID.TextChanged += new System.EventHandler(this.AccID_TextChanged);
            // 
            // Fname
            // 
            this.Fname.Location = new System.Drawing.Point(16, 118);
            this.Fname.Name = "Fname";
            this.Fname.Size = new System.Drawing.Size(126, 22);
            this.Fname.TabIndex = 54;
            this.Fname.TextChanged += new System.EventHandler(this.Fname_TextChanged);
            // 
            // Mname
            // 
            this.Mname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Mname.Location = new System.Drawing.Point(170, 118);
            this.Mname.Name = "Mname";
            this.Mname.Size = new System.Drawing.Size(126, 22);
            this.Mname.TabIndex = 55;
            this.Mname.TextChanged += new System.EventHandler(this.Mname_TextChanged);
            // 
            // Lname
            // 
            this.Lname.Location = new System.Drawing.Point(325, 118);
            this.Lname.Name = "Lname";
            this.Lname.Size = new System.Drawing.Size(126, 22);
            this.Lname.TabIndex = 56;
            // 
            // Suffix
            // 
            this.Suffix.Location = new System.Drawing.Point(479, 118);
            this.Suffix.Name = "Suffix";
            this.Suffix.Size = new System.Drawing.Size(100, 22);
            this.Suffix.TabIndex = 57;
            // 
            // Bday
            // 
            this.Bday.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.Bday.Location = new System.Drawing.Point(16, 176);
            this.Bday.Name = "Bday";
            this.Bday.Size = new System.Drawing.Size(126, 22);
            this.Bday.TabIndex = 58;
            // 
            // Gender
            // 
            this.Gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Gender.FormattingEnabled = true;
            this.Gender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.Gender.Location = new System.Drawing.Point(170, 176);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(126, 24);
            this.Gender.TabIndex = 59;
            // 
            // Contact
            // 
            this.Contact.Location = new System.Drawing.Point(325, 176);
            this.Contact.Name = "Contact";
            this.Contact.Size = new System.Drawing.Size(126, 22);
            this.Contact.TabIndex = 60;
            // 
            // Username
            // 
            this.Username.Location = new System.Drawing.Point(16, 238);
            this.Username.Name = "Username";
            this.Username.Size = new System.Drawing.Size(126, 22);
            this.Username.TabIndex = 61;
            this.Username.TextChanged += new System.EventHandler(this.Username_TextChanged);
            // 
            // Password
            // 
            this.Password.Location = new System.Drawing.Point(170, 238);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(126, 22);
            this.Password.TabIndex = 62;
            this.Password.UseSystemPasswordChar = true;
            this.Password.TextChanged += new System.EventHandler(this.Password_TextChanged);
            // 
            // Repass
            // 
            this.Repass.Location = new System.Drawing.Point(325, 238);
            this.Repass.Name = "Repass";
            this.Repass.Size = new System.Drawing.Size(126, 22);
            this.Repass.TabIndex = 63;
            this.Repass.UseSystemPasswordChar = true;
            this.Repass.TextChanged += new System.EventHandler(this.Repass_TextChanged);
            // 
            // Dept
            // 
            this.Dept.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Dept.FormattingEnabled = true;
            this.Dept.Items.AddRange(new object[] {
            "Office of the Mayor",
            "Licensing Office",
            "Treasury Office"});
            this.Dept.Location = new System.Drawing.Point(16, 293);
            this.Dept.Name = "Dept";
            this.Dept.Size = new System.Drawing.Size(126, 24);
            this.Dept.TabIndex = 64;
            this.Dept.SelectedIndexChanged += new System.EventHandler(this.Dept_SelectedIndexChanged);
            // 
            // Type
            // 
            this.Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Type.FormattingEnabled = true;
            this.Type.Location = new System.Drawing.Point(170, 293);
            this.Type.Name = "Type";
            this.Type.Size = new System.Drawing.Size(126, 24);
            this.Type.TabIndex = 65;
            // 
            // CreateAcc
            // 
            this.CreateAcc.Activecolor = System.Drawing.Color.Transparent;
            this.CreateAcc.BackColor = System.Drawing.Color.Transparent;
            this.CreateAcc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CreateAcc.BorderRadius = 0;
            this.CreateAcc.ButtonText = "Create Account";
            this.CreateAcc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CreateAcc.DisabledColor = System.Drawing.Color.Gray;
            this.CreateAcc.Iconcolor = System.Drawing.Color.Transparent;
            this.CreateAcc.Iconimage = ((System.Drawing.Image)(resources.GetObject("CreateAcc.Iconimage")));
            this.CreateAcc.Iconimage_right = null;
            this.CreateAcc.Iconimage_right_Selected = null;
            this.CreateAcc.Iconimage_Selected = null;
            this.CreateAcc.IconMarginLeft = 0;
            this.CreateAcc.IconMarginRight = 0;
            this.CreateAcc.IconRightVisible = true;
            this.CreateAcc.IconRightZoom = 0D;
            this.CreateAcc.IconVisible = true;
            this.CreateAcc.IconZoom = 50D;
            this.CreateAcc.IsTab = false;
            this.CreateAcc.Location = new System.Drawing.Point(554, 324);
            this.CreateAcc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CreateAcc.Name = "CreateAcc";
            this.CreateAcc.Normalcolor = System.Drawing.Color.Transparent;
            this.CreateAcc.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.CreateAcc.OnHoverTextColor = System.Drawing.Color.Black;
            this.CreateAcc.selected = false;
            this.CreateAcc.Size = new System.Drawing.Size(144, 40);
            this.CreateAcc.TabIndex = 66;
            this.CreateAcc.Text = "Create Account";
            this.CreateAcc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CreateAcc.Textcolor = System.Drawing.Color.Black;
            this.CreateAcc.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CreateAcc.Click += new System.EventHandler(this.CreateAcc_Click);
            // 
            // CheckUsername
            // 
            this.CheckUsername.BackColor = System.Drawing.Color.Transparent;
            this.CheckUsername.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CheckUsername.ForeColor = System.Drawing.Color.Black;
            this.CheckUsername.Location = new System.Drawing.Point(16, 328);
            this.CheckUsername.Name = "CheckUsername";
            this.CheckUsername.Size = new System.Drawing.Size(112, 28);
            this.CheckUsername.TabIndex = 67;
            this.CheckUsername.Text = "Check";
            this.CheckUsername.UseVisualStyleBackColor = false;
            this.CheckUsername.Visible = false;
            this.CheckUsername.Click += new System.EventHandler(this.CheckUsername_Click);
            // 
            // LblStatus
            // 
            this.LblStatus.AutoSize = true;
            this.LblStatus.BackColor = System.Drawing.Color.Transparent;
            this.LblStatus.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblStatus.Location = new System.Drawing.Point(134, 335);
            this.LblStatus.Name = "LblStatus";
            this.LblStatus.Size = new System.Drawing.Size(42, 15);
            this.LblStatus.TabIndex = 68;
            this.LblStatus.Text = "Check";
            this.LblStatus.Visible = false;
            // 
            // Close
            // 
            this.Close.BackColor = System.Drawing.Color.Transparent;
            this.Close.Image = ((System.Drawing.Image)(resources.GetObject("Close.Image")));
            this.Close.ImageActive = null;
            this.Close.Location = new System.Drawing.Point(667, 6);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(40, 30);
            this.Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Close.TabIndex = 230;
            this.Close.TabStop = false;
            this.Close.Zoom = 10;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // tCreateAcct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(710, 383);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.LblStatus);
            this.Controls.Add(this.CheckUsername);
            this.Controls.Add(this.CreateAcc);
            this.Controls.Add(this.Type);
            this.Controls.Add(this.Dept);
            this.Controls.Add(this.Repass);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.Contact);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.Bday);
            this.Controls.Add(this.Suffix);
            this.Controls.Add(this.Lname);
            this.Controls.Add(this.Mname);
            this.Controls.Add(this.Fname);
            this.Controls.Add(this.AccID);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.Usertype);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "tCreateAcct";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "tCreateAcct";
            this.Load += new System.EventHandler(this.tCreateAcct_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Close)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.CheckBox checkBox1;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.Label Usertype;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox AccID;
        public System.Windows.Forms.TextBox Fname;
        public System.Windows.Forms.TextBox Mname;
        public System.Windows.Forms.TextBox Lname;
        public System.Windows.Forms.TextBox Suffix;
        public System.Windows.Forms.DateTimePicker Bday;
        public System.Windows.Forms.ComboBox Gender;
        public System.Windows.Forms.TextBox Contact;
        public System.Windows.Forms.TextBox Username;
        public System.Windows.Forms.TextBox Password;
        public System.Windows.Forms.TextBox Repass;
        public System.Windows.Forms.ComboBox Dept;
        public System.Windows.Forms.ComboBox Type;
        public System.Windows.Forms.Button CheckUsername;
        public System.Windows.Forms.Label LblStatus;
        public Bunifu.Framework.UI.BunifuImageButton Close;
        public Bunifu.Framework.UI.BunifuFlatButton CreateAcc;
    }
}