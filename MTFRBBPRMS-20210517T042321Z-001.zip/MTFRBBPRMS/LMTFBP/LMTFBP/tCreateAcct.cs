﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class tCreateAcct : Form
    {
        MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public tCreateAcct()
        {
            InitializeComponent();
        }

        private void Username_TextChanged(object sender, EventArgs e)
        {
            if (Username.Text == "")
            {
                CheckUsername.Visible = false;
            }
            else
            {
                CheckUsername.Visible = true;
            }
        }

        private void CheckUsername_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Username.Text))
            {
                con.Open();
                MySqlCommand cmd = new MySqlCommand("select * from t_account where Username=@Username", con);
                cmd.Parameters.AddWithValue("@Username", Username.Text);
                MySqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    LblStatus.Visible = true;
                    LblStatus.Text = "Username Already Taken";
                    System.Threading.Thread.Sleep(2000);

                }
                else
                {
                    LblStatus.Visible = true;
                    LblStatus.Text = "Username Available";
                    System.Threading.Thread.Sleep(2000);
                }
                con.Close();
            }
            else
            {
                CheckUsername.Visible = false;
            }
        }

        private void Dept_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Dept.Text == "Office of the Mayor")
            {
                Type.Items.Clear();
                Type.Items.Add("PRC II");
                Type.Items.Add("Admin");
            }
            else if (Dept.Text == "Licensing Office")
            {
                Type.Items.Clear();
                Type.Items.Add("Licensing Head");
                Type.Items.Add("Clerk I");
                //Type.Items.Add("Admin");
            }
            else
            {
                Type.Items.Clear();
                Type.Items.Add("Municipal treasurer");
                Type.Items.Add("RCC I");
                //Type.Items.Add("Admin");
            }
        }

        private void Close_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            this.Close();
            log.Show();
        }

        private void CreateAcc_Click(object sender, EventArgs e)
        {
            if (Lname.Text == "")
            {
                MessageBox.Show("last name must be filled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (Fname.Text == "")
            {
                MessageBox.Show("First name must be filled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (Gender.Text == "")
            {
                MessageBox.Show("please choose Gender.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (Username.Text == "")
            {
                MessageBox.Show("username must be filled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (Password.Text == "")
            {
                MessageBox.Show("password must be filled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (Repass.Text != Password.Text)
            {
                MessageBox.Show("password doesn't Match.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (Password.Text.Length < 4)
            {
                MessageBox.Show("Password must 4 to 16 Characters.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (Password.Text.Length > 16)
            {
                MessageBox.Show("last name must be filled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (Type.Text == "")
            {
                MessageBox.Show("Choose your Usertype.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (LblStatus.Visible == true)
                {
                    if (LblStatus.Text == "Username Available")
                    {
                        DialogResult result = MessageBox.Show("Create Account?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (result == DialogResult.Yes)
                        {
                            if (label1.Text == "Create Account for Tricycle Franchise")
                            {
                                if (Type.Text == "Admin")
                                {
                                    con.Open();
                                    com = con.CreateCommand();
                                    com.CommandText = "INSERT into t_account (Acc_ID, Lname, Fname, Mname, Suffix, Birthday, Gender, Contact_No, Department, Username, Password, Repass, Usertype) VALUES ('" +
                                     AccID.Text + "','" + Lname.Text + "','" + Fname.Text + "','" + Mname.Text + "','" + Suffix.Text + "','" +
                                     Bday.Text + "','" + Gender.Text + "','" + Contact.Text + "','" + Dept.Text + "','" +
                                     Username.Text + "','" + Password.Text + "','" + Repass.Text + "','" + Type.Text + "')";
                                    com.ExecuteNonQuery();
                                    con.Close();

                                    MessageBox.Show("Account has been saved.", "Complete", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                }
                                else
                                {
                                    con.Open();
                                    com = con.CreateCommand();
                                    com.CommandText = "INSERT into t_pending (Acc_ID, Lname, Fname, Mname, Suffix, Birthday, Gender, Contact_No, Department, Username, Password, Repass, Usertype) VALUES ('" +
                                        AccID.Text + "','" + Lname.Text + "','" + Fname.Text + "','" + Mname.Text + "','" + Suffix.Text + "','" +
                                     Bday.Text + "','" + Gender.Text + "','" + Contact.Text + "','" + Dept.Text + "','" +
                                     Username.Text + "','" + Password.Text + "','" + Repass.Text + "','" + Type.Text + "')";
                                    com.ExecuteNonQuery();
                                    con.Close();
                                    MessageBox.Show("Account has been Saved.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                }
                            }
                            else
                            {
                                MySqlConnection cn = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=bplo; charset= utf8");
                                
                                if (Type.Text == "Admin")
                                {
                                    cn.Open();
                                    com = con.CreateCommand();
                                    com.CommandText = "INSERT into b_account (Acc_ID, Lname, Fname, Mname, Suffix, Birthday, Gender, Contact_No, Department, Username, Password, Repass, Usertype) VALUES ('" +
                                     AccID.Text + "','" + Lname.Text + "','" + Fname.Text + "','" + Mname.Text + "','" + Suffix.Text + "','" +
                                     Bday.Text + "','" + Gender.Text + "','" + Contact.Text + "','" + Dept.Text + "','" +
                                     Username.Text + "','" + Password.Text + "','" + Repass.Text + "','" + Type.Text + "')";
                                    com.ExecuteNonQuery();
                                    cn.Close();

                                    MessageBox.Show("Account has been saved.", "Complete", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                }
                                else
                                {
                                    cn.Open();
                                    com = con.CreateCommand();
                                    com.CommandText = "INSERT into b_pendingacc (Acc_ID, Lname, Fname, Mname, Suffix, Birthday, Gender, Contact_No, Department, Username, Password, Repass, Usertype) VALUES ('" +
                                        AccID.Text + "','" + Lname.Text + "','" + Fname.Text + "','" + Mname.Text + "','" + Suffix.Text + "','" +
                                     Bday.Text + "','" + Gender.Text + "','" + Contact.Text + "','" + Dept.Text + "','" +
                                     Username.Text + "','" + Password.Text + "','" + Repass.Text + "','" + Type.Text + "')";
                                    com.ExecuteNonQuery();
                                    cn.Close();
                                    MessageBox.Show("Account has been Saved.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Username is Already Taken.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                else
                {
                    MessageBox.Show("Please Check User Availability.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Mname_TextChanged(object sender, EventArgs e)
        {
            Mname.MaxLength = 1;
        }

        private void tCreateAcct_Load(object sender, EventArgs e)
        {
            GETmaxID();
        }
        public void GETmaxID()
        {
            string proID;
            string query = "SELECT Acc_ID FROM t_account ORDER BY Acc_ID desc";

            con.Open();
            MySqlCommand com = new MySqlCommand(query, con);
            MySqlDataReader dr = com.ExecuteReader();

            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                proID = id.ToString("0");
            }
            else if (Convert.IsDBNull(dr))
            {
                proID = ("1");
            }
            else
            {
                proID = ("1");
            }
            con.Close();

            AccID.Text = proID.ToString();
        }
        private void Password_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                Repass.UseSystemPasswordChar = false;
                Password.UseSystemPasswordChar = false;
            }
            else
            {
                Repass.UseSystemPasswordChar = true;
                Password.UseSystemPasswordChar = true;
            }
        }

        private void Repass_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Fname_TextChanged(object sender, EventArgs e)
        {

        }

        private void AccID_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void Usertype_Click(object sender, EventArgs e)
        {

        }
    }
}
