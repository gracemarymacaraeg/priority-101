﻿namespace LMTFBP
{
    partial class NewApplication
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewApplication));
            this.label33 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.AppNo = new System.Windows.Forms.TextBox();
            this.AppType = new System.Windows.Forms.TextBox();
            this.Lname = new System.Windows.Forms.TextBox();
            this.Fname = new System.Windows.Forms.TextBox();
            this.MI = new System.Windows.Forms.TextBox();
            this.Suff = new System.Windows.Forms.TextBox();
            this.Gender = new System.Windows.Forms.ComboBox();
            this.HouseNo = new System.Windows.Forms.TextBox();
            this.Street = new System.Windows.Forms.TextBox();
            this.Brgy = new System.Windows.Forms.TextBox();
            this.City = new System.Windows.Forms.TextBox();
            this.Province = new System.Windows.Forms.TextBox();
            this.ContactNo = new System.Windows.Forms.TextBox();
            this.Citizenship = new System.Windows.Forms.TextBox();
            this.DualCtzn = new System.Windows.Forms.TextBox();
            this.LicenseNo = new System.Windows.Forms.TextBox();
            this.Make = new System.Windows.Forms.TextBox();
            this.Model = new System.Windows.Forms.TextBox();
            this.MotorNo = new System.Windows.Forms.TextBox();
            this.ChassisNo = new System.Windows.Forms.TextBox();
            this.PlateNo = new System.Windows.Forms.TextBox();
            this.Toda = new System.Windows.Forms.TextBox();
            this.Position = new System.Windows.Forms.ComboBox();
            this.CaseNo = new System.Windows.Forms.TextBox();
            this.StartDTP = new System.Windows.Forms.DateTimePicker();
            this.EndDTP = new System.Windows.Forms.DateTimePicker();
            this.NoUnits = new System.Windows.Forms.TextBox();
            this.OwnerType = new System.Windows.Forms.ComboBox();
            this.OtherType = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.Remove = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Save = new Bunifu.Framework.UI.BunifuFlatButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printDocument2 = new System.Drawing.Printing.PrintDocument();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(1056, 11);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(36, 16);
            this.label33.TabIndex = 96;
            this.label33.Text = "TIme";
            this.label33.Visible = false;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(911, 11);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(49, 16);
            this.label35.TabIndex = 95;
            this.label35.Text = "label35";
            this.label35.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 18);
            this.label1.TabIndex = 97;
            this.label1.Text = "Application Form";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label23.Location = new System.Drawing.Point(787, 308);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(77, 14);
            this.label23.TabIndex = 128;
            this.label23.Text = "Plate No.:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label22.Location = new System.Drawing.Point(611, 308);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(91, 14);
            this.label22.TabIndex = 127;
            this.label22.Text = "Chassis No.:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label21.Location = new System.Drawing.Point(439, 308);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 14);
            this.label21.TabIndex = 126;
            this.label21.Text = "Motor No.:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label20.Location = new System.Drawing.Point(265, 308);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 14);
            this.label20.TabIndex = 125;
            this.label20.Text = "Model:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label31.Location = new System.Drawing.Point(265, 452);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(133, 14);
            this.label31.TabIndex = 124;
            this.label31.Text = "Type of Ownership:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label29.Location = new System.Drawing.Point(787, 403);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(98, 14);
            this.label29.TabIndex = 123;
            this.label29.Text = "Validity End:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label26.Location = new System.Drawing.Point(265, 401);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(70, 14);
            this.label26.TabIndex = 122;
            this.label26.Text = "Position:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label28.Location = new System.Drawing.Point(611, 403);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(112, 14);
            this.label28.TabIndex = 121;
            this.label28.Text = "Validity Start:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label32.Location = new System.Drawing.Point(439, 452);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(112, 14);
            this.label32.TabIndex = 120;
            this.label32.Text = "Please Specify:";
            this.label32.Visible = false;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label27.Location = new System.Drawing.Point(439, 401);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(70, 14);
            this.label27.TabIndex = 119;
            this.label27.Text = "Case No.:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label30.Location = new System.Drawing.Point(88, 452);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(112, 14);
            this.label30.TabIndex = 118;
            this.label30.Text = "No. of Unit(s):";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label25.Location = new System.Drawing.Point(88, 401);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(133, 14);
            this.label25.TabIndex = 117;
            this.label25.Text = "TODA/Organization:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label19.Location = new System.Drawing.Point(88, 308);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(42, 14);
            this.label19.TabIndex = 116;
            this.label19.Text = "Make:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(31, 372);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(155, 16);
            this.label24.TabIndex = 114;
            this.label24.Text = "Franchise Information";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(24, 279);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(162, 16);
            this.label18.TabIndex = 115;
            this.label18.Text = "Motorcycle Information";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label17.Location = new System.Drawing.Point(620, 215);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(91, 14);
            this.label17.TabIndex = 113;
            this.label17.Text = "License No.:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(439, 215);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(175, 14);
            this.label16.TabIndex = 112;
            this.label16.Text = "(Dual citizen?, Specify)";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label15.Location = new System.Drawing.Point(265, 215);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 14);
            this.label15.TabIndex = 111;
            this.label15.Text = "Citizenship:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label14.Location = new System.Drawing.Point(88, 215);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(91, 14);
            this.label14.TabIndex = 110;
            this.label14.Text = "Contact No.:";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label13.Location = new System.Drawing.Point(787, 164);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 14);
            this.label13.TabIndex = 109;
            this.label13.Text = "Province:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label12.Location = new System.Drawing.Point(611, 164);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(133, 14);
            this.label12.TabIndex = 108;
            this.label12.Text = "City/Municipality:";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(439, 164);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 14);
            this.label11.TabIndex = 107;
            this.label11.Text = "Barangay:";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label10.Location = new System.Drawing.Point(265, 164);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 14);
            this.label10.TabIndex = 106;
            this.label10.Text = "Street:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(88, 164);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 14);
            this.label9.TabIndex = 105;
            this.label9.Text = "House No.:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(787, 113);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 14);
            this.label8.TabIndex = 104;
            this.label8.Text = "Gender:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(611, 113);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 14);
            this.label7.TabIndex = 103;
            this.label7.Text = "Suffix:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(439, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 14);
            this.label6.TabIndex = 102;
            this.label6.Text = "Middle Initial:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(265, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 14);
            this.label5.TabIndex = 101;
            this.label5.Text = "First Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(88, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 14);
            this.label4.TabIndex = 100;
            this.label4.Text = "Last Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(171, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 14);
            this.label3.TabIndex = 99;
            this.label3.Text = "Applicant Type:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 14);
            this.label2.TabIndex = 98;
            this.label2.Text = "Applicant No.:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(0, 36);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1169, 10);
            this.panel1.TabIndex = 129;
            // 
            // AppNo
            // 
            this.AppNo.BackColor = System.Drawing.Color.White;
            this.AppNo.Location = new System.Drawing.Point(47, 74);
            this.AppNo.Name = "AppNo";
            this.AppNo.Size = new System.Drawing.Size(100, 22);
            this.AppNo.TabIndex = 130;
            // 
            // AppType
            // 
            this.AppType.BackColor = System.Drawing.Color.White;
            this.AppType.Location = new System.Drawing.Point(192, 74);
            this.AppType.Name = "AppType";
            this.AppType.Size = new System.Drawing.Size(100, 22);
            this.AppType.TabIndex = 131;
            this.AppType.Text = "New";
            this.AppType.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Lname
            // 
            this.Lname.BackColor = System.Drawing.Color.White;
            this.Lname.Location = new System.Drawing.Point(110, 130);
            this.Lname.Name = "Lname";
            this.Lname.Size = new System.Drawing.Size(149, 22);
            this.Lname.TabIndex = 132;
            // 
            // Fname
            // 
            this.Fname.BackColor = System.Drawing.Color.White;
            this.Fname.Location = new System.Drawing.Point(277, 130);
            this.Fname.Name = "Fname";
            this.Fname.Size = new System.Drawing.Size(149, 22);
            this.Fname.TabIndex = 133;
            // 
            // MI
            // 
            this.MI.BackColor = System.Drawing.Color.White;
            this.MI.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.MI.Location = new System.Drawing.Point(451, 130);
            this.MI.Name = "MI";
            this.MI.Size = new System.Drawing.Size(149, 22);
            this.MI.TabIndex = 134;
            this.MI.TextChanged += new System.EventHandler(this.MI_TextChanged);
            // 
            // Suff
            // 
            this.Suff.BackColor = System.Drawing.Color.White;
            this.Suff.Location = new System.Drawing.Point(623, 130);
            this.Suff.Name = "Suff";
            this.Suff.Size = new System.Drawing.Size(149, 22);
            this.Suff.TabIndex = 135;
            // 
            // Gender
            // 
            this.Gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Gender.FormattingEnabled = true;
            this.Gender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.Gender.Location = new System.Drawing.Point(790, 130);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(149, 24);
            this.Gender.TabIndex = 136;
            // 
            // HouseNo
            // 
            this.HouseNo.BackColor = System.Drawing.Color.White;
            this.HouseNo.Location = new System.Drawing.Point(110, 181);
            this.HouseNo.Name = "HouseNo";
            this.HouseNo.Size = new System.Drawing.Size(149, 22);
            this.HouseNo.TabIndex = 137;
            // 
            // Street
            // 
            this.Street.BackColor = System.Drawing.Color.White;
            this.Street.Location = new System.Drawing.Point(277, 181);
            this.Street.Name = "Street";
            this.Street.Size = new System.Drawing.Size(149, 22);
            this.Street.TabIndex = 138;
            this.Street.TextChanged += new System.EventHandler(this.Street_TextChanged);
            // 
            // Brgy
            // 
            this.Brgy.BackColor = System.Drawing.Color.White;
            this.Brgy.Location = new System.Drawing.Point(451, 181);
            this.Brgy.Name = "Brgy";
            this.Brgy.Size = new System.Drawing.Size(151, 22);
            this.Brgy.TabIndex = 139;
            this.Brgy.TextChanged += new System.EventHandler(this.Brgy_TextChanged);
            // 
            // City
            // 
            this.City.BackColor = System.Drawing.Color.White;
            this.City.Location = new System.Drawing.Point(624, 181);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(149, 22);
            this.City.TabIndex = 140;
            this.City.TextChanged += new System.EventHandler(this.City_TextChanged);
            // 
            // Province
            // 
            this.Province.BackColor = System.Drawing.Color.White;
            this.Province.Location = new System.Drawing.Point(790, 181);
            this.Province.Name = "Province";
            this.Province.Size = new System.Drawing.Size(149, 22);
            this.Province.TabIndex = 141;
            // 
            // ContactNo
            // 
            this.ContactNo.BackColor = System.Drawing.Color.White;
            this.ContactNo.Location = new System.Drawing.Point(110, 232);
            this.ContactNo.Name = "ContactNo";
            this.ContactNo.Size = new System.Drawing.Size(149, 22);
            this.ContactNo.TabIndex = 142;
            this.ContactNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ContactNo_KeyPress);
            // 
            // Citizenship
            // 
            this.Citizenship.BackColor = System.Drawing.Color.White;
            this.Citizenship.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Citizenship.Location = new System.Drawing.Point(277, 232);
            this.Citizenship.Name = "Citizenship";
            this.Citizenship.Size = new System.Drawing.Size(149, 22);
            this.Citizenship.TabIndex = 143;
            // 
            // DualCtzn
            // 
            this.DualCtzn.BackColor = System.Drawing.Color.White;
            this.DualCtzn.Location = new System.Drawing.Point(451, 232);
            this.DualCtzn.Name = "DualCtzn";
            this.DualCtzn.Size = new System.Drawing.Size(151, 22);
            this.DualCtzn.TabIndex = 144;
            // 
            // LicenseNo
            // 
            this.LicenseNo.BackColor = System.Drawing.Color.White;
            this.LicenseNo.Location = new System.Drawing.Point(623, 232);
            this.LicenseNo.Name = "LicenseNo";
            this.LicenseNo.Size = new System.Drawing.Size(149, 22);
            this.LicenseNo.TabIndex = 145;
            this.LicenseNo.TextChanged += new System.EventHandler(this.LicenseNo_TextChanged);
            // 
            // Make
            // 
            this.Make.BackColor = System.Drawing.Color.White;
            this.Make.Location = new System.Drawing.Point(110, 325);
            this.Make.Name = "Make";
            this.Make.Size = new System.Drawing.Size(149, 22);
            this.Make.TabIndex = 146;
            this.Make.TextChanged += new System.EventHandler(this.Make_TextChanged);
            // 
            // Model
            // 
            this.Model.BackColor = System.Drawing.Color.White;
            this.Model.Location = new System.Drawing.Point(277, 325);
            this.Model.Name = "Model";
            this.Model.Size = new System.Drawing.Size(149, 22);
            this.Model.TabIndex = 147;
            // 
            // MotorNo
            // 
            this.MotorNo.BackColor = System.Drawing.Color.White;
            this.MotorNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.MotorNo.Location = new System.Drawing.Point(451, 325);
            this.MotorNo.Name = "MotorNo";
            this.MotorNo.Size = new System.Drawing.Size(149, 22);
            this.MotorNo.TabIndex = 148;
            this.MotorNo.TextChanged += new System.EventHandler(this.MotorNo_TextChanged);
            // 
            // ChassisNo
            // 
            this.ChassisNo.BackColor = System.Drawing.Color.White;
            this.ChassisNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ChassisNo.Location = new System.Drawing.Point(623, 325);
            this.ChassisNo.Name = "ChassisNo";
            this.ChassisNo.Size = new System.Drawing.Size(149, 22);
            this.ChassisNo.TabIndex = 149;
            // 
            // PlateNo
            // 
            this.PlateNo.BackColor = System.Drawing.Color.White;
            this.PlateNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.PlateNo.Location = new System.Drawing.Point(790, 325);
            this.PlateNo.Name = "PlateNo";
            this.PlateNo.Size = new System.Drawing.Size(149, 22);
            this.PlateNo.TabIndex = 150;
            this.PlateNo.TextChanged += new System.EventHandler(this.PlateNo_TextChanged);
            // 
            // Toda
            // 
            this.Toda.BackColor = System.Drawing.Color.White;
            this.Toda.Location = new System.Drawing.Point(110, 418);
            this.Toda.Name = "Toda";
            this.Toda.Size = new System.Drawing.Size(149, 22);
            this.Toda.TabIndex = 151;
            // 
            // Position
            // 
            this.Position.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Position.FormattingEnabled = true;
            this.Position.Items.AddRange(new object[] {
            "President",
            "Vice - President",
            "Secretary",
            "Treasurer",
            "Auditor",
            "Chairman",
            "Board Member",
            "Member",
            "None"});
            this.Position.Location = new System.Drawing.Point(277, 418);
            this.Position.Name = "Position";
            this.Position.Size = new System.Drawing.Size(149, 24);
            this.Position.TabIndex = 152;
            // 
            // CaseNo
            // 
            this.CaseNo.BackColor = System.Drawing.Color.White;
            this.CaseNo.Location = new System.Drawing.Point(451, 418);
            this.CaseNo.Name = "CaseNo";
            this.CaseNo.Size = new System.Drawing.Size(149, 22);
            this.CaseNo.TabIndex = 153;
            // 
            // StartDTP
            // 
            this.StartDTP.CalendarForeColor = System.Drawing.Color.Black;
            this.StartDTP.CalendarMonthBackground = System.Drawing.Color.Transparent;
            this.StartDTP.CalendarTitleBackColor = System.Drawing.Color.Transparent;
            this.StartDTP.CalendarTitleForeColor = System.Drawing.Color.Transparent;
            this.StartDTP.CalendarTrailingForeColor = System.Drawing.Color.Black;
            this.StartDTP.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.StartDTP.Location = new System.Drawing.Point(624, 420);
            this.StartDTP.Name = "StartDTP";
            this.StartDTP.Size = new System.Drawing.Size(149, 22);
            this.StartDTP.TabIndex = 154;
            // 
            // EndDTP
            // 
            this.EndDTP.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.EndDTP.Location = new System.Drawing.Point(790, 420);
            this.EndDTP.MaxDate = new System.DateTime(9998, 1, 21, 0, 0, 0, 0);
            this.EndDTP.Name = "EndDTP";
            this.EndDTP.Size = new System.Drawing.Size(149, 22);
            this.EndDTP.TabIndex = 155;
            this.EndDTP.Value = new System.DateTime(2021, 1, 21, 13, 57, 0, 0);
            // 
            // NoUnits
            // 
            this.NoUnits.BackColor = System.Drawing.Color.White;
            this.NoUnits.Location = new System.Drawing.Point(110, 469);
            this.NoUnits.Name = "NoUnits";
            this.NoUnits.Size = new System.Drawing.Size(149, 22);
            this.NoUnits.TabIndex = 156;
            // 
            // OwnerType
            // 
            this.OwnerType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.OwnerType.FormattingEnabled = true;
            this.OwnerType.Items.AddRange(new object[] {
            "Single Proprietorship",
            "Cooperative",
            "Corporation",
            "Other..."});
            this.OwnerType.Location = new System.Drawing.Point(277, 469);
            this.OwnerType.Name = "OwnerType";
            this.OwnerType.Size = new System.Drawing.Size(149, 24);
            this.OwnerType.TabIndex = 157;
            this.OwnerType.SelectedIndexChanged += new System.EventHandler(this.OwnerType_SelectedIndexChanged);
            // 
            // OtherType
            // 
            this.OtherType.BackColor = System.Drawing.Color.White;
            this.OtherType.Location = new System.Drawing.Point(451, 469);
            this.OtherType.Name = "OtherType";
            this.OtherType.Size = new System.Drawing.Size(149, 22);
            this.OtherType.TabIndex = 158;
            this.OtherType.Visible = false;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Remove
            // 
            this.Remove.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.Remove.BackColor = System.Drawing.Color.Transparent;
            this.Remove.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Remove.BorderRadius = 0;
            this.Remove.ButtonText = "Clear";
            this.Remove.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Remove.DisabledColor = System.Drawing.Color.Gray;
            this.Remove.ForeColor = System.Drawing.SystemColors.ControlText;
            this.errorProvider1.SetIconAlignment(this.Remove, System.Windows.Forms.ErrorIconAlignment.BottomLeft);
            this.Remove.Iconcolor = System.Drawing.Color.Transparent;
            this.Remove.Iconimage = ((System.Drawing.Image)(resources.GetObject("Remove.Iconimage")));
            this.Remove.Iconimage_right = null;
            this.Remove.Iconimage_right_Selected = null;
            this.Remove.Iconimage_Selected = null;
            this.Remove.IconMarginLeft = 10;
            this.Remove.IconMarginRight = 0;
            this.Remove.IconRightVisible = true;
            this.Remove.IconRightZoom = 0D;
            this.Remove.IconVisible = true;
            this.Remove.IconZoom = 40D;
            this.Remove.IsTab = false;
            this.Remove.Location = new System.Drawing.Point(822, 492);
            this.Remove.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Remove.Name = "Remove";
            this.Remove.Normalcolor = System.Drawing.Color.Transparent;
            this.Remove.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.Remove.OnHoverTextColor = System.Drawing.Color.Black;
            this.Remove.selected = false;
            this.Remove.Size = new System.Drawing.Size(143, 30);
            this.Remove.TabIndex = 160;
            this.Remove.Text = "Clear";
            this.Remove.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Remove.Textcolor = System.Drawing.Color.Black;
            this.Remove.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Remove.Click += new System.EventHandler(this.Remove_Click);
            // 
            // Save
            // 
            this.Save.Activecolor = System.Drawing.Color.Transparent;
            this.Save.BackColor = System.Drawing.Color.Transparent;
            this.Save.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Save.BorderRadius = 0;
            this.Save.ButtonText = "Save";
            this.Save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Save.DisabledColor = System.Drawing.Color.Gray;
            this.Save.ForeColor = System.Drawing.SystemColors.ControlText;
            this.errorProvider1.SetIconAlignment(this.Save, System.Windows.Forms.ErrorIconAlignment.BottomLeft);
            this.Save.Iconcolor = System.Drawing.Color.Transparent;
            this.Save.Iconimage = ((System.Drawing.Image)(resources.GetObject("Save.Iconimage")));
            this.Save.Iconimage_right = null;
            this.Save.Iconimage_right_Selected = null;
            this.Save.Iconimage_Selected = null;
            this.Save.IconMarginLeft = 10;
            this.Save.IconMarginRight = 0;
            this.Save.IconRightVisible = true;
            this.Save.IconRightZoom = 0D;
            this.Save.IconVisible = true;
            this.Save.IconZoom = 35D;
            this.Save.IsTab = false;
            this.Save.Location = new System.Drawing.Point(989, 492);
            this.Save.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Save.Name = "Save";
            this.Save.Normalcolor = System.Drawing.Color.Transparent;
            this.Save.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.Save.OnHoverTextColor = System.Drawing.Color.Black;
            this.Save.selected = false;
            this.Save.Size = new System.Drawing.Size(143, 30);
            this.Save.TabIndex = 159;
            this.Save.Text = "Save";
            this.Save.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Save.Textcolor = System.Drawing.Color.Black;
            this.Save.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Save.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printDocument2
            // 
            this.printDocument2.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument2_PrintPage);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(712, 8);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(173, 22);
            this.textBox1.TabIndex = 161;
            this.textBox1.Visible = false;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // NewApplication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Remove);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.OtherType);
            this.Controls.Add(this.OwnerType);
            this.Controls.Add(this.NoUnits);
            this.Controls.Add(this.EndDTP);
            this.Controls.Add(this.StartDTP);
            this.Controls.Add(this.CaseNo);
            this.Controls.Add(this.Position);
            this.Controls.Add(this.Toda);
            this.Controls.Add(this.PlateNo);
            this.Controls.Add(this.ChassisNo);
            this.Controls.Add(this.MotorNo);
            this.Controls.Add(this.Model);
            this.Controls.Add(this.Make);
            this.Controls.Add(this.LicenseNo);
            this.Controls.Add(this.DualCtzn);
            this.Controls.Add(this.Citizenship);
            this.Controls.Add(this.ContactNo);
            this.Controls.Add(this.Province);
            this.Controls.Add(this.City);
            this.Controls.Add(this.Brgy);
            this.Controls.Add(this.Street);
            this.Controls.Add(this.HouseNo);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.Suff);
            this.Controls.Add(this.MI);
            this.Controls.Add(this.Fname);
            this.Controls.Add(this.Lname);
            this.Controls.Add(this.AppType);
            this.Controls.Add(this.AppNo);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label35);
            this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "NewApplication";
            this.Size = new System.Drawing.Size(1169, 548);
            this.Load += new System.EventHandler(this.NewApplication_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label label33;
        public System.Windows.Forms.Label label35;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label23;
        public System.Windows.Forms.Label label22;
        public System.Windows.Forms.Label label21;
        public System.Windows.Forms.Label label20;
        public System.Windows.Forms.Label label31;
        public System.Windows.Forms.Label label29;
        public System.Windows.Forms.Label label26;
        public System.Windows.Forms.Label label28;
        public System.Windows.Forms.Label label32;
        public System.Windows.Forms.Label label27;
        public System.Windows.Forms.Label label30;
        public System.Windows.Forms.Label label25;
        public System.Windows.Forms.Label label19;
        public System.Windows.Forms.Label label24;
        public System.Windows.Forms.Label label18;
        public System.Windows.Forms.Label label17;
        public System.Windows.Forms.Label label16;
        public System.Windows.Forms.Label label15;
        public System.Windows.Forms.Label label14;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.TextBox AppNo;
        public System.Windows.Forms.TextBox AppType;
        public System.Windows.Forms.TextBox Lname;
        public System.Windows.Forms.TextBox Fname;
        public System.Windows.Forms.TextBox MI;
        public System.Windows.Forms.TextBox Suff;
        public System.Windows.Forms.ComboBox Gender;
        public System.Windows.Forms.TextBox HouseNo;
        public System.Windows.Forms.TextBox Street;
        public System.Windows.Forms.TextBox Brgy;
        public System.Windows.Forms.TextBox City;
        public System.Windows.Forms.TextBox Province;
        public System.Windows.Forms.TextBox ContactNo;
        public System.Windows.Forms.TextBox Citizenship;
        public System.Windows.Forms.TextBox DualCtzn;
        public System.Windows.Forms.TextBox LicenseNo;
        public System.Windows.Forms.TextBox Make;
        public System.Windows.Forms.TextBox Model;
        public System.Windows.Forms.TextBox MotorNo;
        public System.Windows.Forms.TextBox ChassisNo;
        public System.Windows.Forms.TextBox PlateNo;
        public System.Windows.Forms.TextBox Toda;
        public System.Windows.Forms.ComboBox Position;
        public System.Windows.Forms.TextBox CaseNo;
        public System.Windows.Forms.DateTimePicker StartDTP;
        public System.Windows.Forms.DateTimePicker EndDTP;
        public System.Windows.Forms.TextBox NoUnits;
        public System.Windows.Forms.ComboBox OwnerType;
        public System.Windows.Forms.TextBox OtherType;
        private Bunifu.Framework.UI.BunifuFlatButton Save;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Timer timer1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Drawing.Printing.PrintDocument printDocument2;
        private Bunifu.Framework.UI.BunifuFlatButton Remove;
        public System.Windows.Forms.TextBox textBox1;
    }
}
