﻿namespace LMTFBP
{
    partial class tViewRecords
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(tViewRecords));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.bunifuFlatButton2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.NewRecords = new Bunifu.Framework.UI.BunifuFlatButton();
            this.ExpiredBtn = new Bunifu.Framework.UI.BunifuFlatButton();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(192, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(10, 550);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(201, -1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(968, 550);
            this.panel2.TabIndex = 1;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(13, 3);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(173, 22);
            this.textBox3.TabIndex = 365;
            this.textBox3.Visible = false;
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 0;
            this.bunifuFlatButton2.ButtonText = "Archive Records";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton2.ForeColor = System.Drawing.Color.Black;
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton2.Iconimage")));
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = true;
            this.bunifuFlatButton2.IconZoom = 45D;
            this.bunifuFlatButton2.IsTab = false;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(14, 165);
            this.bunifuFlatButton2.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.Black;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(177, 35);
            this.bunifuFlatButton2.TabIndex = 2;
            this.bunifuFlatButton2.Text = "Archive Records";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.Black;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton2.Click += new System.EventHandler(this.bunifuFlatButton2_Click);
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Renew Records";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.ForeColor = System.Drawing.Color.Black;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton1.Iconimage")));
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 50D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(14, 125);
            this.bunifuFlatButton1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.Black;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(177, 35);
            this.bunifuFlatButton1.TabIndex = 1;
            this.bunifuFlatButton1.Text = "Renew Records";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.Black;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // NewRecords
            // 
            this.NewRecords.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.NewRecords.BackColor = System.Drawing.Color.Transparent;
            this.NewRecords.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.NewRecords.BorderRadius = 0;
            this.NewRecords.ButtonText = "New Records";
            this.NewRecords.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NewRecords.DisabledColor = System.Drawing.Color.Gray;
            this.NewRecords.ForeColor = System.Drawing.Color.Black;
            this.NewRecords.Iconcolor = System.Drawing.Color.Transparent;
            this.NewRecords.Iconimage = ((System.Drawing.Image)(resources.GetObject("NewRecords.Iconimage")));
            this.NewRecords.Iconimage_right = null;
            this.NewRecords.Iconimage_right_Selected = null;
            this.NewRecords.Iconimage_Selected = null;
            this.NewRecords.IconMarginLeft = 0;
            this.NewRecords.IconMarginRight = 0;
            this.NewRecords.IconRightVisible = true;
            this.NewRecords.IconRightZoom = 0D;
            this.NewRecords.IconVisible = true;
            this.NewRecords.IconZoom = 40D;
            this.NewRecords.IsTab = false;
            this.NewRecords.Location = new System.Drawing.Point(14, 84);
            this.NewRecords.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.NewRecords.Name = "NewRecords";
            this.NewRecords.Normalcolor = System.Drawing.Color.Transparent;
            this.NewRecords.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.NewRecords.OnHoverTextColor = System.Drawing.Color.Black;
            this.NewRecords.selected = false;
            this.NewRecords.Size = new System.Drawing.Size(177, 35);
            this.NewRecords.TabIndex = 0;
            this.NewRecords.Text = "New Records";
            this.NewRecords.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NewRecords.Textcolor = System.Drawing.Color.Black;
            this.NewRecords.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewRecords.Click += new System.EventHandler(this.NewRecords_Click);
            // 
            // ExpiredBtn
            // 
            this.ExpiredBtn.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.ExpiredBtn.BackColor = System.Drawing.Color.Transparent;
            this.ExpiredBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ExpiredBtn.BorderRadius = 0;
            this.ExpiredBtn.ButtonText = "Soon to Expired";
            this.ExpiredBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ExpiredBtn.DisabledColor = System.Drawing.Color.Gray;
            this.ExpiredBtn.Iconcolor = System.Drawing.Color.Transparent;
            this.ExpiredBtn.Iconimage = ((System.Drawing.Image)(resources.GetObject("ExpiredBtn.Iconimage")));
            this.ExpiredBtn.Iconimage_right = null;
            this.ExpiredBtn.Iconimage_right_Selected = null;
            this.ExpiredBtn.Iconimage_Selected = null;
            this.ExpiredBtn.IconMarginLeft = 0;
            this.ExpiredBtn.IconMarginRight = 0;
            this.ExpiredBtn.IconRightVisible = true;
            this.ExpiredBtn.IconRightZoom = 0D;
            this.ExpiredBtn.IconVisible = true;
            this.ExpiredBtn.IconZoom = 45D;
            this.ExpiredBtn.IsTab = false;
            this.ExpiredBtn.Location = new System.Drawing.Point(14, 210);
            this.ExpiredBtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ExpiredBtn.Name = "ExpiredBtn";
            this.ExpiredBtn.Normalcolor = System.Drawing.Color.Transparent;
            this.ExpiredBtn.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.ExpiredBtn.OnHoverTextColor = System.Drawing.Color.Black;
            this.ExpiredBtn.selected = false;
            this.ExpiredBtn.Size = new System.Drawing.Size(177, 35);
            this.ExpiredBtn.TabIndex = 0;
            this.ExpiredBtn.Text = "Soon to Expired";
            this.ExpiredBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ExpiredBtn.Textcolor = System.Drawing.Color.Black;
            this.ExpiredBtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExpiredBtn.Click += new System.EventHandler(this.ExpiredBtn_Click);
            // 
            // tViewRecords
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.ExpiredBtn);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.bunifuFlatButton2);
            this.Controls.Add(this.bunifuFlatButton1);
            this.Controls.Add(this.NewRecords);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Arial", 9.75F);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "tViewRecords";
            this.Size = new System.Drawing.Size(1169, 548);
            this.Load += new System.EventHandler(this.tViewRecords_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Panel panel2;
        public Bunifu.Framework.UI.BunifuFlatButton NewRecords;
        public Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        public Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton2;
        public System.Windows.Forms.TextBox textBox3;
        public Bunifu.Framework.UI.BunifuFlatButton ExpiredBtn;
    }
}
