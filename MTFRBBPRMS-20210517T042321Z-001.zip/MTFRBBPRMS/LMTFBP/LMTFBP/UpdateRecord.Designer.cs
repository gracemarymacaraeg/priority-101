﻿namespace LMTFBP
{
    partial class UpdateRecord
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateRecord));
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.OtherType = new System.Windows.Forms.TextBox();
            this.OwnerType = new System.Windows.Forms.ComboBox();
            this.NoUnits = new System.Windows.Forms.TextBox();
            this.EndDTP = new System.Windows.Forms.DateTimePicker();
            this.StartDTP = new System.Windows.Forms.DateTimePicker();
            this.CaseNo = new System.Windows.Forms.TextBox();
            this.Position = new System.Windows.Forms.ComboBox();
            this.Toda = new System.Windows.Forms.TextBox();
            this.PlateNo = new System.Windows.Forms.TextBox();
            this.ChassisNo = new System.Windows.Forms.TextBox();
            this.MotorNo = new System.Windows.Forms.TextBox();
            this.Model = new System.Windows.Forms.TextBox();
            this.Make = new System.Windows.Forms.TextBox();
            this.LicenseNo = new System.Windows.Forms.TextBox();
            this.DualCtzn = new System.Windows.Forms.TextBox();
            this.Citizenship = new System.Windows.Forms.TextBox();
            this.ContactNo = new System.Windows.Forms.TextBox();
            this.Province = new System.Windows.Forms.TextBox();
            this.City = new System.Windows.Forms.TextBox();
            this.Brgy = new System.Windows.Forms.TextBox();
            this.Street = new System.Windows.Forms.TextBox();
            this.HouseNo = new System.Windows.Forms.TextBox();
            this.Gender = new System.Windows.Forms.ComboBox();
            this.Suff = new System.Windows.Forms.TextBox();
            this.MI = new System.Windows.Forms.TextBox();
            this.Fname = new System.Windows.Forms.TextBox();
            this.Lname = new WindowsFormsControlLibrary1.BunifuCustomTextbox();
            this.AppType = new System.Windows.Forms.TextBox();
            this.AppNo = new System.Windows.Forms.TextBox();
            this.Save = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printDocument2 = new System.Drawing.Printing.PrintDocument();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SaveBtn = new Bunifu.Framework.UI.BunifuFlatButton();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(359, 77);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 295;
            this.textBox2.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(359, 49);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 294;
            this.textBox1.Visible = false;
            // 
            // OtherType
            // 
            this.OtherType.Location = new System.Drawing.Point(502, 469);
            this.OtherType.Name = "OtherType";
            this.OtherType.Size = new System.Drawing.Size(156, 22);
            this.OtherType.TabIndex = 293;
            // 
            // OwnerType
            // 
            this.OwnerType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.OwnerType.FormattingEnabled = true;
            this.OwnerType.Items.AddRange(new object[] {
            "Single Proprietorship",
            "Cooperative",
            "Corporation",
            "Other..."});
            this.OwnerType.Location = new System.Drawing.Point(303, 469);
            this.OwnerType.Name = "OwnerType";
            this.OwnerType.Size = new System.Drawing.Size(156, 24);
            this.OwnerType.TabIndex = 292;
            // 
            // NoUnits
            // 
            this.NoUnits.Location = new System.Drawing.Point(110, 469);
            this.NoUnits.Name = "NoUnits";
            this.NoUnits.Size = new System.Drawing.Size(156, 22);
            this.NoUnits.TabIndex = 291;
            // 
            // EndDTP
            // 
            this.EndDTP.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.EndDTP.Location = new System.Drawing.Point(906, 420);
            this.EndDTP.MaxDate = new System.DateTime(9998, 1, 21, 0, 0, 0, 0);
            this.EndDTP.Name = "EndDTP";
            this.EndDTP.Size = new System.Drawing.Size(156, 22);
            this.EndDTP.TabIndex = 290;
            this.EndDTP.Value = new System.DateTime(2021, 1, 21, 13, 57, 0, 0);
            // 
            // StartDTP
            // 
            this.StartDTP.CalendarForeColor = System.Drawing.Color.Black;
            this.StartDTP.CalendarMonthBackground = System.Drawing.Color.Transparent;
            this.StartDTP.CalendarTitleBackColor = System.Drawing.Color.Transparent;
            this.StartDTP.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.StartDTP.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.StartDTP.Location = new System.Drawing.Point(705, 420);
            this.StartDTP.Name = "StartDTP";
            this.StartDTP.Size = new System.Drawing.Size(156, 22);
            this.StartDTP.TabIndex = 289;
            // 
            // CaseNo
            // 
            this.CaseNo.Location = new System.Drawing.Point(502, 418);
            this.CaseNo.Name = "CaseNo";
            this.CaseNo.Size = new System.Drawing.Size(156, 22);
            this.CaseNo.TabIndex = 288;
            // 
            // Position
            // 
            this.Position.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Position.FormattingEnabled = true;
            this.Position.Items.AddRange(new object[] {
            "President",
            "Vice - President",
            "Secretary",
            "Treasurer",
            "Auditor",
            "Chairman",
            "Board Member",
            "Member",
            "None"});
            this.Position.Location = new System.Drawing.Point(303, 418);
            this.Position.Name = "Position";
            this.Position.Size = new System.Drawing.Size(156, 24);
            this.Position.TabIndex = 287;
            // 
            // Toda
            // 
            this.Toda.Location = new System.Drawing.Point(110, 418);
            this.Toda.Name = "Toda";
            this.Toda.Size = new System.Drawing.Size(156, 22);
            this.Toda.TabIndex = 286;
            // 
            // PlateNo
            // 
            this.PlateNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.PlateNo.Location = new System.Drawing.Point(906, 325);
            this.PlateNo.Name = "PlateNo";
            this.PlateNo.Size = new System.Drawing.Size(156, 22);
            this.PlateNo.TabIndex = 285;
            // 
            // ChassisNo
            // 
            this.ChassisNo.Location = new System.Drawing.Point(705, 325);
            this.ChassisNo.Name = "ChassisNo";
            this.ChassisNo.Size = new System.Drawing.Size(156, 22);
            this.ChassisNo.TabIndex = 284;
            // 
            // MotorNo
            // 
            this.MotorNo.Location = new System.Drawing.Point(502, 325);
            this.MotorNo.Name = "MotorNo";
            this.MotorNo.Size = new System.Drawing.Size(156, 22);
            this.MotorNo.TabIndex = 283;
            // 
            // Model
            // 
            this.Model.Location = new System.Drawing.Point(303, 325);
            this.Model.Name = "Model";
            this.Model.Size = new System.Drawing.Size(156, 22);
            this.Model.TabIndex = 282;
            // 
            // Make
            // 
            this.Make.Location = new System.Drawing.Point(110, 325);
            this.Make.Name = "Make";
            this.Make.Size = new System.Drawing.Size(156, 22);
            this.Make.TabIndex = 281;
            // 
            // LicenseNo
            // 
            this.LicenseNo.Location = new System.Drawing.Point(705, 232);
            this.LicenseNo.Name = "LicenseNo";
            this.LicenseNo.Size = new System.Drawing.Size(149, 22);
            this.LicenseNo.TabIndex = 280;
            // 
            // DualCtzn
            // 
            this.DualCtzn.Location = new System.Drawing.Point(493, 232);
            this.DualCtzn.Name = "DualCtzn";
            this.DualCtzn.Size = new System.Drawing.Size(149, 22);
            this.DualCtzn.TabIndex = 279;
            // 
            // Citizenship
            // 
            this.Citizenship.Location = new System.Drawing.Point(303, 232);
            this.Citizenship.Name = "Citizenship";
            this.Citizenship.Size = new System.Drawing.Size(149, 22);
            this.Citizenship.TabIndex = 278;
            // 
            // ContactNo
            // 
            this.ContactNo.Location = new System.Drawing.Point(110, 232);
            this.ContactNo.Name = "ContactNo";
            this.ContactNo.Size = new System.Drawing.Size(149, 22);
            this.ContactNo.TabIndex = 277;
            // 
            // Province
            // 
            this.Province.Location = new System.Drawing.Point(761, 181);
            this.Province.Name = "Province";
            this.Province.Size = new System.Drawing.Size(127, 22);
            this.Province.TabIndex = 276;
            // 
            // City
            // 
            this.City.Location = new System.Drawing.Point(579, 181);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(120, 22);
            this.City.TabIndex = 275;
            // 
            // Brgy
            // 
            this.Brgy.Location = new System.Drawing.Point(404, 181);
            this.Brgy.Name = "Brgy";
            this.Brgy.Size = new System.Drawing.Size(120, 22);
            this.Brgy.TabIndex = 274;
            // 
            // Street
            // 
            this.Street.Location = new System.Drawing.Point(257, 181);
            this.Street.Name = "Street";
            this.Street.Size = new System.Drawing.Size(100, 22);
            this.Street.TabIndex = 273;
            // 
            // HouseNo
            // 
            this.HouseNo.Location = new System.Drawing.Point(110, 181);
            this.HouseNo.Name = "HouseNo";
            this.HouseNo.Size = new System.Drawing.Size(100, 22);
            this.HouseNo.TabIndex = 272;
            // 
            // Gender
            // 
            this.Gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Gender.FormattingEnabled = true;
            this.Gender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.Gender.Location = new System.Drawing.Point(761, 130);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(127, 24);
            this.Gender.TabIndex = 271;
            // 
            // Suff
            // 
            this.Suff.Location = new System.Drawing.Point(619, 130);
            this.Suff.Name = "Suff";
            this.Suff.Size = new System.Drawing.Size(100, 22);
            this.Suff.TabIndex = 270;
            // 
            // MI
            // 
            this.MI.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.MI.Location = new System.Drawing.Point(478, 130);
            this.MI.Name = "MI";
            this.MI.Size = new System.Drawing.Size(100, 22);
            this.MI.TabIndex = 269;
            // 
            // Fname
            // 
            this.Fname.Location = new System.Drawing.Point(296, 129);
            this.Fname.Name = "Fname";
            this.Fname.Size = new System.Drawing.Size(149, 22);
            this.Fname.TabIndex = 268;
            // 
            // Lname
            // 
            this.Lname.BackColor = System.Drawing.SystemColors.Control;
            this.Lname.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.Lname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Lname.ForeColor = System.Drawing.Color.Black;
            this.Lname.Location = new System.Drawing.Point(110, 130);
            this.Lname.Name = "Lname";
            this.Lname.Size = new System.Drawing.Size(149, 22);
            this.Lname.TabIndex = 267;
            // 
            // AppType
            // 
            this.AppType.Enabled = false;
            this.AppType.Location = new System.Drawing.Point(192, 74);
            this.AppType.Name = "AppType";
            this.AppType.Size = new System.Drawing.Size(100, 22);
            this.AppType.TabIndex = 266;
            // 
            // AppNo
            // 
            this.AppNo.Enabled = false;
            this.AppNo.Location = new System.Drawing.Point(47, 74);
            this.AppNo.Name = "AppNo";
            this.AppNo.Size = new System.Drawing.Size(100, 22);
            this.AppNo.TabIndex = 265;
            // 
            // Save
            // 
            this.Save.Activecolor = System.Drawing.Color.Transparent;
            this.Save.BackColor = System.Drawing.Color.Transparent;
            this.Save.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Save.BorderRadius = 0;
            this.Save.ButtonText = "Save";
            this.Save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Save.DisabledColor = System.Drawing.Color.Gray;
            this.Save.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Save.Iconcolor = System.Drawing.Color.Transparent;
            this.Save.Iconimage = null;
            this.Save.Iconimage_right = null;
            this.Save.Iconimage_right_Selected = null;
            this.Save.Iconimage_Selected = null;
            this.Save.IconMarginLeft = 10;
            this.Save.IconMarginRight = 0;
            this.Save.IconRightVisible = true;
            this.Save.IconRightZoom = 0D;
            this.Save.IconVisible = true;
            this.Save.IconZoom = 75D;
            this.Save.IsTab = false;
            this.Save.Location = new System.Drawing.Point(1346, 746);
            this.Save.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Save.Name = "Save";
            this.Save.Normalcolor = System.Drawing.Color.Transparent;
            this.Save.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.Save.OnHoverTextColor = System.Drawing.Color.Black;
            this.Save.selected = false;
            this.Save.Size = new System.Drawing.Size(195, 46);
            this.Save.TabIndex = 263;
            this.Save.Text = "Save";
            this.Save.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Save.Textcolor = System.Drawing.Color.Black;
            this.Save.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(0, 36);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1171, 10);
            this.panel1.TabIndex = 262;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label23.Location = new System.Drawing.Point(896, 308);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(77, 14);
            this.label23.TabIndex = 261;
            this.label23.Text = "Plate No.:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label22.Location = new System.Drawing.Point(694, 308);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(91, 14);
            this.label22.TabIndex = 260;
            this.label22.Text = "Chassis No.:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label21.Location = new System.Drawing.Point(490, 308);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 14);
            this.label21.TabIndex = 259;
            this.label21.Text = "Motor No.:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label20.Location = new System.Drawing.Point(293, 308);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 14);
            this.label20.TabIndex = 258;
            this.label20.Text = "Model:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label31.Location = new System.Drawing.Point(293, 452);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(133, 14);
            this.label31.TabIndex = 257;
            this.label31.Text = "Type of Ownership:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label29.Location = new System.Drawing.Point(896, 401);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(98, 14);
            this.label29.TabIndex = 256;
            this.label29.Text = "Validity End:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label26.Location = new System.Drawing.Point(293, 401);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(70, 14);
            this.label26.TabIndex = 255;
            this.label26.Text = "Position:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label28.Location = new System.Drawing.Point(694, 401);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(112, 14);
            this.label28.TabIndex = 254;
            this.label28.Text = "Validity Start:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label32.Location = new System.Drawing.Point(490, 452);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(112, 14);
            this.label32.TabIndex = 253;
            this.label32.Text = "Please Specify:";
            this.label32.Visible = false;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label27.Location = new System.Drawing.Point(490, 401);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(70, 14);
            this.label27.TabIndex = 252;
            this.label27.Text = "Case No.:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label30.Location = new System.Drawing.Point(100, 452);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(112, 14);
            this.label30.TabIndex = 251;
            this.label30.Text = "No. of Unit(s):";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label25.Location = new System.Drawing.Point(100, 401);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(133, 14);
            this.label25.TabIndex = 250;
            this.label25.Text = "TODA/Organization:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label19.Location = new System.Drawing.Point(100, 308);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(42, 14);
            this.label19.TabIndex = 249;
            this.label19.Text = "Make:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(31, 372);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(155, 16);
            this.label24.TabIndex = 247;
            this.label24.Text = "Franchise Information";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(24, 279);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(162, 16);
            this.label18.TabIndex = 248;
            this.label18.Text = "Motorcycle Information";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label17.Location = new System.Drawing.Point(694, 215);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(91, 14);
            this.label17.TabIndex = 246;
            this.label17.Text = "License No.:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(490, 215);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(175, 14);
            this.label16.TabIndex = 245;
            this.label16.Text = "(Dual citizen?, Specify)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label14.Location = new System.Drawing.Point(100, 215);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(91, 14);
            this.label14.TabIndex = 243;
            this.label14.Text = "Contact No.:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label13.Location = new System.Drawing.Point(751, 164);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 14);
            this.label13.TabIndex = 242;
            this.label13.Text = "Province:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label12.Location = new System.Drawing.Point(565, 164);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(133, 14);
            this.label12.TabIndex = 241;
            this.label12.Text = "City/Municipality:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(395, 164);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 14);
            this.label11.TabIndex = 240;
            this.label11.Text = "Barangay:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label10.Location = new System.Drawing.Point(246, 164);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 14);
            this.label10.TabIndex = 239;
            this.label10.Text = "Street:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(100, 164);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 14);
            this.label9.TabIndex = 238;
            this.label9.Text = "House No.:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(751, 113);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 14);
            this.label8.TabIndex = 237;
            this.label8.Text = "Gender:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(609, 113);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 14);
            this.label7.TabIndex = 236;
            this.label7.Text = "Suffix:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(467, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 14);
            this.label6.TabIndex = 235;
            this.label6.Text = "Middle Initial:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label15.Location = new System.Drawing.Point(293, 215);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 14);
            this.label15.TabIndex = 244;
            this.label15.Text = "Citizenship:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(293, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 14);
            this.label5.TabIndex = 234;
            this.label5.Text = "First Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(100, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 14);
            this.label4.TabIndex = 233;
            this.label4.Text = "Last Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(171, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 14);
            this.label3.TabIndex = 232;
            this.label3.Text = "Applicant Type:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 14);
            this.label2.TabIndex = 231;
            this.label2.Text = "Applicant No.:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 18);
            this.label1.TabIndex = 230;
            this.label1.Text = "Update Application";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(994, 11);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(36, 16);
            this.label33.TabIndex = 229;
            this.label33.Text = "TIme";
            this.label33.Visible = false;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(911, 11);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(49, 16);
            this.label35.TabIndex = 228;
            this.label35.Text = "label35";
            this.label35.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printDocument2
            // 
            this.printDocument2.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument2_PrintPage);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // SaveBtn
            // 
            this.SaveBtn.Activecolor = System.Drawing.Color.Transparent;
            this.SaveBtn.BackColor = System.Drawing.Color.Transparent;
            this.SaveBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SaveBtn.BorderRadius = 0;
            this.SaveBtn.ButtonText = "Update Record";
            this.SaveBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SaveBtn.DisabledColor = System.Drawing.Color.Gray;
            this.SaveBtn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.SaveBtn.Iconcolor = System.Drawing.Color.Transparent;
            this.SaveBtn.Iconimage = ((System.Drawing.Image)(resources.GetObject("SaveBtn.Iconimage")));
            this.SaveBtn.Iconimage_right = null;
            this.SaveBtn.Iconimage_right_Selected = null;
            this.SaveBtn.Iconimage_Selected = null;
            this.SaveBtn.IconMarginLeft = 10;
            this.SaveBtn.IconMarginRight = 0;
            this.SaveBtn.IconRightVisible = true;
            this.SaveBtn.IconRightZoom = 0D;
            this.SaveBtn.IconVisible = true;
            this.SaveBtn.IconZoom = 55D;
            this.SaveBtn.IsTab = false;
            this.SaveBtn.Location = new System.Drawing.Point(936, 489);
            this.SaveBtn.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Normalcolor = System.Drawing.Color.Transparent;
            this.SaveBtn.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.SaveBtn.OnHoverTextColor = System.Drawing.Color.Black;
            this.SaveBtn.selected = false;
            this.SaveBtn.Size = new System.Drawing.Size(167, 37);
            this.SaveBtn.TabIndex = 264;
            this.SaveBtn.Text = "Update Record";
            this.SaveBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SaveBtn.Textcolor = System.Drawing.Color.Black;
            this.SaveBtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(721, 8);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 296;
            this.textBox3.Visible = false;
            // 
            // UpdateRecord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.OtherType);
            this.Controls.Add(this.OwnerType);
            this.Controls.Add(this.NoUnits);
            this.Controls.Add(this.EndDTP);
            this.Controls.Add(this.StartDTP);
            this.Controls.Add(this.CaseNo);
            this.Controls.Add(this.Position);
            this.Controls.Add(this.Toda);
            this.Controls.Add(this.PlateNo);
            this.Controls.Add(this.ChassisNo);
            this.Controls.Add(this.MotorNo);
            this.Controls.Add(this.Model);
            this.Controls.Add(this.Make);
            this.Controls.Add(this.LicenseNo);
            this.Controls.Add(this.DualCtzn);
            this.Controls.Add(this.Citizenship);
            this.Controls.Add(this.ContactNo);
            this.Controls.Add(this.Province);
            this.Controls.Add(this.City);
            this.Controls.Add(this.Brgy);
            this.Controls.Add(this.Street);
            this.Controls.Add(this.HouseNo);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.Suff);
            this.Controls.Add(this.MI);
            this.Controls.Add(this.Fname);
            this.Controls.Add(this.Lname);
            this.Controls.Add(this.AppType);
            this.Controls.Add(this.AppNo);
            this.Controls.Add(this.SaveBtn);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label35);
            this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "UpdateRecord";
            this.Size = new System.Drawing.Size(1165, 544);
            this.Load += new System.EventHandler(this.UpdateRecord_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox textBox2;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.TextBox OtherType;
        public System.Windows.Forms.ComboBox OwnerType;
        public System.Windows.Forms.TextBox NoUnits;
        public System.Windows.Forms.DateTimePicker EndDTP;
        public System.Windows.Forms.DateTimePicker StartDTP;
        public System.Windows.Forms.TextBox CaseNo;
        public System.Windows.Forms.ComboBox Position;
        public System.Windows.Forms.TextBox Toda;
        public System.Windows.Forms.TextBox PlateNo;
        public System.Windows.Forms.TextBox ChassisNo;
        public System.Windows.Forms.TextBox MotorNo;
        public System.Windows.Forms.TextBox Model;
        public System.Windows.Forms.TextBox Make;
        public System.Windows.Forms.TextBox LicenseNo;
        public System.Windows.Forms.TextBox DualCtzn;
        public System.Windows.Forms.TextBox Citizenship;
        public System.Windows.Forms.TextBox ContactNo;
        public System.Windows.Forms.TextBox Province;
        public System.Windows.Forms.TextBox City;
        public System.Windows.Forms.TextBox Brgy;
        public System.Windows.Forms.TextBox Street;
        public System.Windows.Forms.TextBox HouseNo;
        public System.Windows.Forms.ComboBox Gender;
        public System.Windows.Forms.TextBox Suff;
        public System.Windows.Forms.TextBox MI;
        public System.Windows.Forms.TextBox Fname;
        public WindowsFormsControlLibrary1.BunifuCustomTextbox Lname;
        public System.Windows.Forms.TextBox AppType;
        public System.Windows.Forms.TextBox AppNo;
        public Bunifu.Framework.UI.BunifuFlatButton SaveBtn;
        public Bunifu.Framework.UI.BunifuFlatButton Save;
        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Label label23;
        public System.Windows.Forms.Label label22;
        public System.Windows.Forms.Label label21;
        public System.Windows.Forms.Label label20;
        public System.Windows.Forms.Label label31;
        public System.Windows.Forms.Label label29;
        public System.Windows.Forms.Label label26;
        public System.Windows.Forms.Label label28;
        public System.Windows.Forms.Label label32;
        public System.Windows.Forms.Label label27;
        public System.Windows.Forms.Label label30;
        public System.Windows.Forms.Label label25;
        public System.Windows.Forms.Label label19;
        public System.Windows.Forms.Label label24;
        public System.Windows.Forms.Label label18;
        public System.Windows.Forms.Label label17;
        public System.Windows.Forms.Label label16;
        public System.Windows.Forms.Label label14;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label15;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label33;
        public System.Windows.Forms.Label label35;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Drawing.Printing.PrintDocument printDocument2;
        private System.Windows.Forms.Timer timer1;
        public System.Windows.Forms.TextBox textBox3;
    }
}
