﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class orgViewList : UserControl
    {
        MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public orgViewList()
        {
            InitializeComponent();
        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void orgViewList_Load(object sender, EventArgs e)
        {
            officer();
            member();
        }
        public void member()
        {
            con.Open();
            bunifuCustomDataGrid1.Rows.Clear();
            com = con.CreateCommand();
            com.CommandText = " SELECT* from t_records WHERE Position = 'Member' and Toda = '" + tName.Text + "' ORDER by Lname ASC ";
            reader = com.ExecuteReader();
            while (reader.Read())
            {
                bunifuCustomDataGrid1.Rows.Add(reader[1].ToString(), reader[3].ToString(),
                reader[4].ToString(), reader[5].ToString(), reader[6].ToString(), reader[7].ToString(),
                reader[18].ToString());
            }
            reader.Close();
            com.ExecuteNonQuery();
            con.Close();
        }
        public void officer()
        {
            con.Open();
            com = con.CreateCommand();
            com.CommandText = " SELECT* from t_tofficer WHERE Toda_Name = '" + tName.Text + "'";
            reader = com.ExecuteReader();
            while (reader.Read())
            {
                tPresident.Text = reader[3].ToString();
                tVice.Text = reader[4].ToString();
                tSecretary.Text = reader[5].ToString();
                tTreasurer.Text = reader[6].ToString();
                tAuditor.Text = reader[7].ToString();
                tChairman.Text = reader[8].ToString();
                tBoard1.Text = reader[9].ToString();
                tBoard2.Text = reader[10].ToString();
                tBoard3.Text = reader[11].ToString();
                tBoard4.Text = reader[12].ToString();
                tBoard5.Text = reader[13].ToString();
            }
            reader.Close();
            com.ExecuteNonQuery();
            con.Close();
        }
        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void tName_TextChanged(object sender, EventArgs e)
        {

        }

        private void tAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void tContact_TextChanged(object sender, EventArgs e)
        {

        }

        private void tDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void tCY_TextChanged(object sender, EventArgs e)
        {

        }

        private void tPresident_TextChanged(object sender, EventArgs e)
        {

        }

        private void tVice_TextChanged(object sender, EventArgs e)
        {

        }

        private void tSecretary_TextChanged(object sender, EventArgs e)
        {

        }

        private void tTreasurer_TextChanged(object sender, EventArgs e)
        {

        }

        private void tAuditor_TextChanged(object sender, EventArgs e)
        {

        }

        private void tChairman_TextChanged(object sender, EventArgs e)
        {

        }

        private void tBoard1_TextChanged(object sender, EventArgs e)
        {

        }

        private void bunifuCustomDataGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            member();
        }
    }
}
