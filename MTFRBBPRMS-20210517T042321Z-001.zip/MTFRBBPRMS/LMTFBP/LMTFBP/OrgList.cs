﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class OrgList : UserControl
    {
        MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public OrgList()
        {
            InitializeComponent();
        }

        private void OrgList_Load(object sender, EventArgs e)
        {
            var uc1 = new OrgView();
            panel2.Controls.Clear();
            panel2.Controls.Add(uc1);
        }

        private void OrgLists_Click(object sender, EventArgs e)
        {
            var uc1 = new OrgView();
            panel2.Controls.Clear();
            panel2.Controls.Add(uc1);
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            var uc1 = new OrgView();
            panel2.Controls.Clear();
            panel2.Controls.Add(uc1);
            uc1.ViewList.Text = "Approved Organization";
            uc1.bunifuFlatButton1.Text = "Archive Information";
            con.Open();
            uc1.dataGridView1.Rows.Clear();
            com = con.CreateCommand();
            com.CommandText = " SELECT* from t_ptodainfo ORDER by Toda_ID Asc";
            reader = com.ExecuteReader();
            while (reader.Read())
            {
                 uc1.dataGridView1.Rows.Add(reader[1].ToString(), reader[4].ToString(),
                 reader[5].ToString(), reader[6].ToString(), reader[7].ToString(), reader[12].ToString(),
                 reader[8].ToString(), reader[10].ToString());
            }
            reader.Close();
            com.ExecuteNonQuery();
            con.Close();
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            var uc1 = new OrgView();
            panel2.Controls.Clear();
            panel2.Controls.Add(uc1);
            uc1.bunifuFlatButton1.Visible = false;
            uc1.ViewList.Text = "Update Organization";
            con.Open();
            uc1.dataGridView1.Rows.Clear();
            com = con.CreateCommand();
            com.CommandText = " SELECT* from t_atodainfo ORDER by Toda_ID Asc";
            reader = com.ExecuteReader();
            while (reader.Read())
            {
                uc1.dataGridView1.Rows.Add(reader[1].ToString(), reader[4].ToString(),
                reader[5].ToString(), reader[6].ToString(), reader[7].ToString(), reader[12].ToString(),
                reader[8].ToString(), reader[10].ToString());
            }
            reader.Close();
            com.ExecuteNonQuery();
            con.Close();
        }
    }
}
