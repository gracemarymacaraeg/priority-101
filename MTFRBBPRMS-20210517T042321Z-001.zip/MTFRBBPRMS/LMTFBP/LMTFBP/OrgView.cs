﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class OrgView : UserControl
    {
        MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public OrgView()
        {
            InitializeComponent();
            FillCombo();
        }
        void FillCombo()
        {
            String constring = "datasource = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8";
            string query = "Select Toda_name from t_todainfo;";
            MySqlConnection cn = new MySqlConnection(constring);
            MySqlCommand comm = new MySqlCommand(query, cn);
            MySqlDataReader reader;
            try
            {
                cn.Open();
                reader = comm.ExecuteReader();

                while (reader.Read())
                {
                    string sName = reader.GetString("Toda_name");
                    comboBox1.Items.Add(sName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void bunifuCustomDataGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void OrgView_Load(object sender, EventArgs e)
        {
            con.Open();
            dataGridView1.Rows.Clear();
            com = con.CreateCommand();
            com.CommandText = " SELECT* from t_todainfo ORDER by Toda_ID Asc";
            reader = com.ExecuteReader();
            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader[1].ToString(), reader[4].ToString(),
                 reader[5].ToString(), reader[6].ToString(), reader[7].ToString(), reader[12].ToString(),
                 reader[8].ToString(), reader[10].ToString());
            }
            reader.Close();
            com.ExecuteNonQuery();
            con.Close();
        }

        private void SearchBtn_Click(object sender, EventArgs e)
        {
            con.Open();
            dataGridView1.Rows.Clear();
            com = con.CreateCommand();
            com.CommandText = " SELECT* from t_todainfo WHERE Toda_Name = '" + comboBox1.Text + "'";
            reader = com.ExecuteReader();
            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader[1].ToString(), reader[4].ToString(),
                 reader[5].ToString(), reader[6].ToString(), reader[7].ToString(), reader[12].ToString(),
                 reader[8].ToString(), reader[10].ToString());
            }
            reader.Close();
            com.ExecuteNonQuery();
            con.Close();
        }

        private void ViewList_Click(object sender, EventArgs e)
        {
            if (ViewList.Text == "View List")
            {
                Update ud = new Update();
                var uc1 = new orgViewList();
                ud.panel1.Controls.Clear();
                ud.panel1.Controls.Add(uc1);
                const string message = "View Profile?";
                const string caption = "View";
                var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    uc1.tName.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
                    uc1.tAddress.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
                    uc1.tContact.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
                    uc1.tDate.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
                    uc1.tCY.Text = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();
                    ud.Show();
                }
            }
            else if (ViewList.Text == "Approved Organization")
            {
                Update ud = new Update();
                var uc1 = new OrgPending();
                ud.panel1.Controls.Clear();
                ud.panel1.Controls.Add(uc1);
                const string message = "View Profile?";
                const string caption = "View";
                var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    uc1.textBox2.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
                    uc1.AddressTB.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
                    uc1.ContactTB.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
                    uc1.DateDTP.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
                    uc1.cyTB.Text = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();
                    uc1.AgencyCB.Text = this.dataGridView1.CurrentRow.Cells[6].Value.ToString();
                    uc1.LevelCB.Text = this.dataGridView1.CurrentRow.Cells[7].Value.ToString();
                    uc1.oNameTB.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
                    ud.Show();
                }
            }
            else
            {
                Update ud = new Update();
                var uc1 = new OrgPending();
                ud.panel1.Controls.Clear();
                ud.panel1.Controls.Add(uc1);
                uc1.label1.Text = "Update Organization";
                const string message = "View Profile?";
                const string caption = "View";
                var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    uc1.textBox2.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
                    uc1.AddressTB.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
                    uc1.ContactTB.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
                    uc1.DateDTP.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
                    uc1.cyTB.Text = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();
                    uc1.AgencyCB.Text = this.dataGridView1.CurrentRow.Cells[6].Value.ToString();
                    uc1.LevelCB.Text = this.dataGridView1.CurrentRow.Cells[7].Value.ToString();
                    uc1.oNameTB.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
                    ud.Show();
                }
            }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            if (bunifuFlatButton1.Text == "Archive organization")
            {
                Update ud = new Update();
                var uc1 = new OrgArchive();
                ud.panel1.Controls.Clear();
                ud.panel1.Controls.Add(uc1);
                uc1.label1.Text = "Archive Organization";
                const string message = "View Profile?";
                const string caption = "View";
                var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    uc1.textBox2.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
                    uc1.textBox1.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
                    uc1.AddressTB.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
                    uc1.ContactTB.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
                    uc1.DateDTP.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
                    uc1.cyTB.Text = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();
                    uc1.AgencyCB.Text = this.dataGridView1.CurrentRow.Cells[6].Value.ToString();
                    uc1.LevelCB.Text = this.dataGridView1.CurrentRow.Cells[7].Value.ToString();
                    uc1.oNameTB.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
                    ud.Show();
                }
            }
            else
            {
                Update ud = new Update();
                var uc1 = new OrgArchive();
                ud.panel1.Controls.Clear();
                ud.panel1.Controls.Add(uc1);
                uc1.label1.Text = "Archive Pending Organization";
                const string message = "View Profile?";
                const string caption = "View";
                var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    uc1.textBox2.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
                    uc1.textBox1.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
                    uc1.AddressTB.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
                    uc1.ContactTB.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
                    uc1.DateDTP.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
                    uc1.cyTB.Text = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();
                    uc1.AgencyCB.Text = this.dataGridView1.CurrentRow.Cells[6].Value.ToString();
                    uc1.LevelCB.Text = this.dataGridView1.CurrentRow.Cells[7].Value.ToString();
                    uc1.oNameTB.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
                    ud.Show();
                }
            }
        }
    }
}
