﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class businessApplication : UserControl
    {
        MySqlConnection cn = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=bplo; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public businessApplication()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                bhouseTB.Text = ohouseTB.Text;
                bbldgTB.Text = obldgTB.Text;
                bunitTB.Text = ounitTB.Text;
                bstreetTB.Text = ostreetTB.Text;
                bbrgyTB.Text = obrgyTB.Text;
                bsubdTB.Text = osubdTB.Text;
                bmunTB.Text = omunTB.Text;
                bprovinceTB.Text = oprovTB.Text;
                btelnoTB.Text = otelnoTB.Text;
                bemailTB.Text = oemailTB.Text;
            }
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
                if (lnameTB.Text == "")
                {
                    MessageBox.Show("Input Last Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (fnameTB.Text == "")
                {
                    MessageBox.Show("Input First Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (bnameTB.Text == "")
                {
                    MessageBox.Show("Input Business Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (bplateTB.Text == "")
                {
                    MessageBox.Show("Input Business Plate", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (obrgyTB.Text == "")
                {
                    MessageBox.Show("Input barangay", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (omunTB.Text == "")
                {
                    MessageBox.Show("Input Municipality", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    DialogResult result = MessageBox.Show("Save Application?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        information();
                    }
                    cn.Close();
                }
        }

        public void information()
        {
            cn.Open();
            com = cn.CreateCommand();
            com.CommandText = "INSERT into b_i_information (Applicant_No, Applicant_Type, Payment_type, App_Date, lname, fname, mname, suffix, bname, bplate, tname, plname, pfname, pmname, psuffix) VALUES ('" +
                appNo.Text + "','" + appType.Text + "','" + paymentCB.Text + "','" + appDate.Text + "','" + lnameTB.Text + "','" + fnameTB.Text + "','" +
                mnameTB.Text + "','" + suffixTB.Text + "','" + bnameTB.Text + "','" + bplateTB.Text + "','" + tnameTB.Text + "','" + plname.Text + "','" +
                pfname.Text + "','" + pmname.Text + "','" + psuffix.Text + "')";
            com.ExecuteNonQuery();

            com.CommandText = "INSERT into b_i_raddress (Applicant_no, llname, lfname, lmname, monthly, house_No, street, Brgy, Municipal, Province, Tel_no, Email) VALUES ('" +
                appNo.Text + "','" + llnameTB.Text + "','" + lfnameTB.Text + "','" + lmiTB.Text + "','" + lmonthlyTB.Text + "','" + lhouseTB.Text + "','" +
                lstreetTB.Text + "','" + lbrgyTB.Text + "','" + lmunTB.Text + "','" + lprovTB.Text + "','" + ltelnoTB.Text + "','" + lemailTB.Text + "')";
            com.ExecuteNonQuery();

            com.CommandText = "INSERT into b_i_baddress (Applicant_No, House_No, Bldg_name, Unit_No, Street, brgy, Subd, Municipal, province, Tel_No, Email) VALUES ('" +
                appNo.Text + "','" + bhouseTB.Text + "','" + bbldgTB.Text + "','" + bunitTB.Text + "','" + bstreetTB.Text + "','" + bbrgyTB.Text + "','" +
                bsubdTB.Text + "','" + bmunTB.Text + "','" + bprovinceTB.Text + "','" + btelnoTB.Text + "','" + bemailTB.Text + "')";
            com.ExecuteNonQuery();

            com.CommandText = " INSERT into b_i_oaddress (Applicant_No, House_No, Bldg_Name, Unit_no, Street, Brgy, Subd, Municipal, Province, tel_No, Email) VALUES ('" +
                appNo.Text + "','" + ohouseTB.Text + "','" + obldgTB.Text + "','" + ounitTB.Text + "','" + ostreetTB.Text + "','" + obrgyTB.Text + "','" +
                osubdTB.Text + "','" + omunTB.Text + "','" + oprovTB.Text + "','" + otelnoTB.Text + "','" + oemailTB.Text + "')";
            com.ExecuteNonQuery();

            com.CommandText = "INSERT into b_i_requirements (Applicant_No, Reference_no, DTI_date, DTI_no, CTC_no, TIN_no, Org_type, Govt_entity, Specify, PIN, No_Employee, Employee_LGU, Contact_Person, CPerson_No) VALUES ('" +
                appNo.Text + "','" + referenceTB.Text + "','" + dtiDate.Text + "','" + dtiNo.Text + "','" + ctcNo.Text + "','" + tinTB.Text + "','" + orgCB.Text + "','" +
                govtCB.Text + "','" + specify.Text + "','" + pinTB.Text + "','" + establishTB.Text + "','" + lguTB.Text + "','" + cfnameTB.Text + "','" + ctelnoTB.Text + "')";
            com.ExecuteNonQuery();

            com.CommandText = "INSERT into b_i_activity (Applicant_No, b_code, b_line, b_units, b_capital, bg_essential, bg_nonessential) VALUES ('" +
                appNo.Text + "','" + buscodeTB.Text + "','" + busilineTB.Text + "','" + bnounitTB.Text + "','" + bcapitalTB.Text + "','" +
                bessentialTB.Text + "','" + bnonessentialTB.Text + "')";
            com.ExecuteNonQuery();
            MessageBox.Show("Save Complete! Ready to Print", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            cn.Close();
        }
        public void GETmaxID()
        {
            string proID;
            string query = "SELECT Applicant_No FROM b_i_information ORDER BY Applicant_No Desc";

            cn.Open();
            MySqlCommand com = new MySqlCommand(query, cn);
            MySqlDataReader dr = com.ExecuteReader();

            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                proID = id.ToString("0");
            }
            else if (Convert.IsDBNull(dr))
            {
                proID = ("1");
            }
            else
            {
                proID = ("1");
            }
            cn.Close();

            appNo.Text = proID.ToString();
        }


        private void b_appform_Load(object sender, EventArgs e)
        {
            GETmaxID();
            if (appType.Text == "Renewal")
            {
                label4.Visible = true;
                label5.Visible = true;
            }
            else
            {
                label4.Visible = false;
                label5.Visible = false;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                groupBox7.Enabled = true;
                llnameTB.ResetText();
                lfnameTB.ResetText();
                lmiTB.ResetText();
                lmonthlyTB.ResetText();
                lmunTB.ResetText();
                lprovTB.ResetText();
                ltelnoTB.ResetText();
                lemailTB.ResetText();
                lhouseTB.ResetText();
                lstreetTB.ResetText();
                lbrgyTB.ResetText();
            }
            else
            {
                llnameTB.Text = "N/A";
                lfnameTB.Text = "N/A";
                lmiTB.Text = "N/A";
                lmonthlyTB.Text = "N/A";
                lmunTB.Text = "N/A";
                lprovTB.Text = "N/A";
                ltelnoTB.Text = "N/A";
                lemailTB.Text = "N/A";
                lhouseTB.Text = "N/A";
                lstreetTB.Text = "N/A";
                lbrgyTB.Text = "N/A";
            }
        }

        private void businessApplication_Load(object sender, EventArgs e)
        {
            GETmaxID();
        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void orgCB_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void govtCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (govtCB.Text == "Yes")
            {
                specify.Visible = true;
            }
            else
            {
                specify.Visible = false;
            }
        }
    }
}
