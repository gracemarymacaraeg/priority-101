﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class forgot : Form
    {
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public forgot()
        {
            InitializeComponent();
        }

        private void forgot_Load(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                Repass.UseSystemPasswordChar = false;
                Password.UseSystemPasswordChar = false;
            }
            else
            {
                Repass.UseSystemPasswordChar = true;
                Password.UseSystemPasswordChar = true;
            }
        }

        private void AccID_TextChanged(object sender, EventArgs e)
        {
            if (AccID.Text == "")
            {
                CheckID.Visible = false;
            }
            else
            {
                CheckID.Visible = true;
            }    
        }

        private void CheckID_Click(object sender, EventArgs e)
        {
            if (label1.Text == "Tricycle Franchise")
            {
                MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8");

                con.Open();
                com = con.CreateCommand();
                com.CommandText = "SELECT * FROM t_account WHERE Username LIKE '" + AccID.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    Fname.Text = reader[3].ToString();
                    Mname.Text = reader[4].ToString();
                    Lname.Text = reader[2].ToString();
                    Suffix.Text = reader[5].ToString();
                    Bday.Text = reader[6].ToString();
                    Gender.Text = reader[7].ToString();
                    Contact.Text = reader[8].ToString();
                    Username.Text = reader[10].ToString();
                    Dept.Text = reader[9].ToString();
                    Type.Text = reader[13].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                MySqlConnection cn = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=bplo; charset= utf8");
                cn.Open();
                com = cn.CreateCommand();
                com.CommandText = "SELECT * FROM b_account WHERE Username LIKE '" + AccID.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    Fname.Text = reader[3].ToString();
                    Mname.Text = reader[4].ToString();
                    Lname.Text = reader[2].ToString();
                    Suffix.Text = reader[5].ToString();
                    Bday.Text = reader[6].ToString();
                    Gender.Text = reader[7].ToString();
                    Contact.Text = reader[8].ToString();
                    Username.Text = reader[10].ToString();
                    Dept.Text = reader[9].ToString();
                    Usertype.Text = reader[13].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();
                cn.Close();
            }
        }

        private void Gender_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Dept_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Dept.Text == "Office of the Mayor")
            {
                Type.Items.Clear();
                Type.Items.Add("PRC II");
                Type.Items.Add("Admin");
            }
            else if (Dept.Text == "Licensing Office")
            {
                Type.Items.Clear();
                Type.Items.Add("Licensing Head");
                Type.Items.Add("Clerk I");
                //Type.Items.Add("Admin");
            }
            else
            {
                Type.Items.Clear();
                Type.Items.Add("Municipal treasurer");
                Type.Items.Add("RCC I");
                //Type.Items.Add("Admin");
            }
        }

        private void CreateAcc_Click(object sender, EventArgs e)
        {
            if (label1.Text == "Tricycle Franchise")
            {
                DialogResult result = MessageBox.Show("Upate Account?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {

                    MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8");
                    con.Open();
                    com = con.CreateCommand();
                    com.CommandText = "UPDATE t_account SET Password = '" + Password.Text + "', Repass = '" + Repass.Text + "' WHERE Username = '" + AccID.Text + "'";
                    com.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Account has been Updated.", "Complete", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
            {
                DialogResult result = MessageBox.Show("Upate Account?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {

                    MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=bplo; charset= utf8");
                    con.Open();
                    com = con.CreateCommand();
                    com.CommandText = "UPDATE b_account SET Password = '" + Password.Text + "', Repass = '" + Repass.Text + "' WHERE Username = '" + AccID.Text + "'";
                    com.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Account has been Updated.", "Complete", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }

        private void Close_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            this.Close();
            log.Show();
        }
    }
}
