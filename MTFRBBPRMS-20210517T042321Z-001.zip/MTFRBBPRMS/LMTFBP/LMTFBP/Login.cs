﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class Login : Form
    {
        MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        public Login()
        {
            InitializeComponent();
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            if (textBox2.Text.Length < 4)
            {
                MessageBox.Show(" Password Must be 4 to 16 Characters ", " Error ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (textBox2.Text.Length > 16)
            {
                MessageBox.Show(" Password Must be 4 to 16 Characters ", " Error ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                if (label1.Text == "Tricycle Franchise")
                {
                    string name, pass, type, lname, fname, mi, dept;

                    con.Open();
                    com = con.CreateCommand();
                    com.CommandText = " select* from t_account WHERE Username = '" + textBox1.Text + "' and Password = '" + textBox2.Text + "'";
                    com.ExecuteNonQuery();
                    MySqlDataReader tr = com.ExecuteReader();
                    if (tr.Read())
                    {
                        name = tr[10].ToString();
                        pass = tr[11].ToString();
                        type = tr[13].ToString();
                        lname = tr[2].ToString();
                        fname = tr[3].ToString();
                        mi = tr[4].ToString();
                        dept = tr[9].ToString();
                        MessageBox.Show(" Welcome  " + lname + "", " success ", MessageBoxButtons.OK, MessageBoxIcon.Information);

                       
                            tHomepage th = new tHomepage();
                            th.DepartmentLbl.Text = dept;
                            th.nameLbl.Text = fname + " " + mi + " " + lname;
                            th.uTypeLbl.Text = type;
                            this.Close();
                            th.Show();
                        
                    }
                    else
                    {
                        MessageBox.Show(" Incorrect password or username, please input the correct account ", " Error &", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    con.Close();
                }
                else
                {
                    
                    MySqlConnection mycn = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=bplo; charset= utf8");
                    string name, pass, type, lname, fname, mi, dept; 

                    mycn.Open();
                    com = mycn.CreateCommand();
                    com.CommandText = " select* from b_account WHERE Username = '" + textBox1.Text + "' and Password = '" + textBox2.Text + "'";
                    com.ExecuteNonQuery();
                    MySqlDataReader tr = com.ExecuteReader();
                    if (tr.Read())
                    {
                        name = tr[10].ToString();
                        pass = tr[11].ToString();
                        type = tr[13].ToString();
                        lname = tr[2].ToString();
                        fname = tr[3].ToString();
                        mi = tr[4].ToString();
                        dept = tr[9].ToString();
                        MessageBox.Show(" Welcome  " + lname + "", " success ", MessageBoxButtons.OK, MessageBoxIcon.Information);


                        bHomepage th = new bHomepage();
                        th.DepartmentLbl.Text = dept;
                        th.nameLbl.Text = fname + " " + mi + " " + lname;
                        th.uTypeLbl.Text = type;
                        this.Close();
                        th.Show();
                    }
                    else
                    {
                        MessageBox.Show(" Incorrect password or username, please input the correct account ", " Error &", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    mycn.Close();
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Close Program?", "Confirmation!", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (re == DialogResult.OK)
            {
                this.Close();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox2.UseSystemPasswordChar = false;
            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            tCreateAcct tc = new tCreateAcct();
            tc.Show();
            this.Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (label1.Text == "Tricycle Franchise")
            {
                forgot ft = new forgot();
                ft.Show();
                ft.label1.Text = "Tricycle Franchise";
                this.Close();
            }
            else
            {
                forgot ft = new forgot();
                ft.Show();
                ft.label1.Text = "Business Permit";
                this.Close();
            }
        }
    }
}
