﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class tViewRecords : UserControl
    {
        MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public tViewRecords()
        {
            InitializeComponent();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            if (bunifuFlatButton1.Text == "Renew Records")
            {
                var uc1 = new tView();
                panel2.Controls.Clear();
                panel2.Controls.Add(uc1); 
                uc1.Archive.Visible = true;
                uc1.bunifuFlatButton2.Visible = true;
                uc1.PrintBtn.Visible = true;
                uc1.textBox3.Text = textBox3.Text;
                con.Open();
                uc1.ViewRecords.Rows.Clear();
                com = con.CreateCommand();
                com.CommandText = " SELECT* from t_renew ORDER by Applicant_ID Asc ";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.ViewRecords.Rows.Add(reader[1].ToString(), reader[2].ToString(),
                    reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), reader[6].ToString(),
                    reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString(),
                    reader[11].ToString(), reader[12].ToString(), reader[13].ToString(),
                    reader[14].ToString(), reader[16].ToString(),
                    reader[19].ToString(), reader[20].ToString(), reader[21].ToString());
                }
                reader.Close();
                com.ExecuteNonQuery();
                con.Close();
                uc1.label2.Text = uc1.ViewRecords.Rows.Count.ToString();
            }
            else
            {
                MySqlConnection cn = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=bplo; charset= utf8");
                var uc1 = new bRecords();
                panel2.Controls.Clear();
                panel2.Controls.Add(uc1);
                cn.Open();
                uc1.dataGridView1.Rows.Clear();
                com = cn.CreateCommand();
                com.CommandText = " SELECT* from b_r_renewinfo ORDER BY Applicant_Type ASC ";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.dataGridView1.Rows.Add(reader[1].ToString(), reader[2].ToString(),
                     reader[3].ToString(), reader[6].ToString(), reader[7].ToString(), reader[8].ToString(),
                     reader[9].ToString(), reader[10].ToString(), reader[11].ToString(), reader[12].ToString(),
                     reader[13].ToString(), reader[14].ToString(), reader[15].ToString(), reader[16].ToString());
                }
                reader.Close();
                com.ExecuteNonQuery();
                cn.Close();
                uc1.label2.Text = uc1.dataGridView1.Rows.Count.ToString();
            }
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            if (bunifuFlatButton2.Text == "Archive Records")
            {
                var uc1 = new tView();
                panel2.Controls.Clear();
                uc1.textBox3.Text = textBox3.Text;
                panel2.Controls.Add(uc1);
                uc1.bunifuFlatButton2.Visible = true;
                uc1.PrintBtn.Visible = false;
                uc1.Archive.Visible = false;
                uc1.bunifuFlatButton2.Text = "Update Information";
                con.Open();
                uc1.ViewRecords.Rows.Clear();
                com = con.CreateCommand();
                com.CommandText = " SELECT* from t_archive ORDER by Applicant_Type DESC ";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.ViewRecords.Rows.Add(reader[1].ToString(), reader[2].ToString(),
                    reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), reader[6].ToString(),
                    reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString(),
                    reader[11].ToString(), reader[12].ToString(), reader[13].ToString(),
                    reader[14].ToString(), reader[16].ToString(),
                    reader[19].ToString(), reader[20].ToString());
                }
                reader.Close();
                com.ExecuteNonQuery();
                con.Close();
                uc1.label2.Text = uc1.ViewRecords.Rows.Count.ToString();
            }
            else
            {
                MySqlConnection cn = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=bplo; charset= utf8");
                var uc1 = new bRecords();
                panel2.Controls.Clear();
                panel2.Controls.Add(uc1);
                uc1.Archive.Visible = false;
                cn.Open();
                uc1.bunifuFlatButton2.Text = "Update Archive";
                uc1.dataGridView1.Rows.Clear();
                com = cn.CreateCommand();
                com.CommandText = " SELECT* from b_a_information ORDER by Applicant_No ASC ";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.dataGridView1.Rows.Add(reader[1].ToString(), reader[2].ToString(),
                     reader[3].ToString(), reader[6].ToString(), reader[7].ToString(), reader[8].ToString(),
                     reader[9].ToString(), reader[10].ToString(), reader[11].ToString(), reader[12].ToString(),
                     reader[13].ToString(), reader[14].ToString(), reader[15].ToString(), reader[16].ToString());
                }
                reader.Close();
                com.ExecuteNonQuery();
                cn.Close();
                uc1.label2.Text = uc1.dataGridView1.Rows.Count.ToString();
            }
        }

        private void tViewRecords_Load(object sender, EventArgs e)
        {
            var uc1 = new tView();
            panel2.Controls.Clear();
            panel2.Controls.Add(uc1);
        }

        private void NewRecords_Click(object sender, EventArgs e)
        {
            if (NewRecords.Text == "New Records")
            {
                var uc1 = new tView();
                panel2.Controls.Clear();
                uc1.textBox3.Text = textBox3.Text;
                uc1.Archive.Visible = true;
                uc1.bunifuFlatButton2.Visible = true;
                uc1.PrintBtn.Visible = true;
                panel2.Controls.Add(uc1);
                con.Open();
                uc1.ViewRecords.Rows.Clear();
                com = con.CreateCommand();
                com.CommandText = " SELECT* from t_records ORDER by Applicant_ID Asc ";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.ViewRecords.Rows.Add(reader[1].ToString(), reader[2].ToString(),
                    reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), reader[6].ToString(),
                    reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString(),
                    reader[11].ToString(), reader[12].ToString(), reader[13].ToString(),
                    reader[14].ToString(), reader[16].ToString(),
                    reader[19].ToString(), reader[20].ToString(), reader[21].ToString());
                }
                reader.Close();
                com.ExecuteNonQuery();
                con.Close();
                uc1.label2.Text = uc1.ViewRecords.Rows.Count.ToString();
            }
            else
            {
                MySqlConnection cn = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=bplo; charset= utf8");
                var uc1 = new bRecords();
                panel2.Controls.Clear();
                panel2.Controls.Add(uc1);
                cn.Open();
                uc1.dataGridView1.Rows.Clear();
                com = cn.CreateCommand();
                com.CommandText = " SELECT* from b_i_information ORDER BY Applicant_Type ASC ";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                     uc1.dataGridView1.Rows.Add(reader[1].ToString(), reader[2].ToString(),
                     reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), reader[6].ToString(),
                     reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString(),
                     reader[11].ToString(), reader[12].ToString(), reader[13].ToString(), reader[14].ToString());
                }
                reader.Close();
                com.ExecuteNonQuery();
                cn.Close();
                uc1.label2.Text = uc1.dataGridView1.Rows.Count.ToString();
            }
        }

        private void ExpiredBtn_Click(object sender, EventArgs e)
        {
            var uc1 = new tView();
            panel2.Controls.Clear();
            panel2.Controls.Add(uc1);
            uc1.textBox3.Text = textBox3.Text;
            uc1.Archive.Visible = true;
            uc1.bunifuFlatButton2.Visible = true;
            uc1.PrintBtn.Visible = true;
            con.Open();
            uc1.ViewRecords.Rows.Clear();
            com = con.CreateCommand();
            com.CommandText = " SELECT* FROM t_records WHERE End_Val = '" + uc1.label3.Text + "'";
            reader = com.ExecuteReader();
            while (reader.Read())
            {
                uc1.ViewRecords.Rows.Add(reader[1].ToString(), reader[2].ToString(),
                    reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), reader[6].ToString(),
                    reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString(),
                    reader[11].ToString(), reader[12].ToString(), reader[13].ToString(),
                    reader[14].ToString(), reader[16].ToString(),
                    reader[19].ToString(), reader[20].ToString(), reader[21].ToString());
            }
            reader.Close();
            com.ExecuteNonQuery();

            com.CommandText = " SELECT* FROM t_renew WHERE End_Val = '" + uc1.label3.Text + "'";
            reader = com.ExecuteReader();
            while (reader.Read())
            {
                uc1.ViewRecords.Rows.Add(reader[1].ToString(), reader[2].ToString(),
                    reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), reader[6].ToString(),
                    reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString(),
                    reader[11].ToString(), reader[12].ToString(), reader[13].ToString(),
                    reader[14].ToString(), reader[16].ToString(),
                    reader[19].ToString(), reader[20].ToString(), reader[21].ToString());
            }
            reader.Close();
            com.ExecuteNonQuery();
            con.Close();
            uc1.label2.Text = uc1.ViewRecords.Rows.Count.ToString();
        }
    }
}
