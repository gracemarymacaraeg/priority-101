﻿namespace LMTFBP
{
    partial class OrgArchive
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrgArchive));
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.otherLevel = new System.Windows.Forms.TextBox();
            this.otherAgency = new System.Windows.Forms.TextBox();
            this.requirementTB = new System.Windows.Forms.TextBox();
            this.requirementCB = new System.Windows.Forms.ComboBox();
            this.ProvideTB = new System.Windows.Forms.TextBox();
            this.financingTB = new System.Windows.Forms.TextBox();
            this.purposeTB = new System.Windows.Forms.TextBox();
            this.StatusTB = new System.Windows.Forms.TextBox();
            this.benefitTB = new System.Windows.Forms.TextBox();
            this.costsTB = new System.Windows.Forms.TextBox();
            this.projectTB = new System.Windows.Forms.TextBox();
            this.LevelCB = new System.Windows.Forms.ComboBox();
            this.AgencyCB = new System.Windows.Forms.ComboBox();
            this.cyTB = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.DateDTP = new System.Windows.Forms.DateTimePicker();
            this.ContactTB = new System.Windows.Forms.TextBox();
            this.AddressTB = new System.Windows.Forms.TextBox();
            this.oNameTB = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.bm5TB = new System.Windows.Forms.TextBox();
            this.bm4TB = new System.Windows.Forms.TextBox();
            this.bm3TB = new System.Windows.Forms.TextBox();
            this.bm2TB = new System.Windows.Forms.TextBox();
            this.bm1TB = new System.Windows.Forms.TextBox();
            this.chairmanTB = new System.Windows.Forms.TextBox();
            this.auditorTB = new System.Windows.Forms.TextBox();
            this.treasurerTB = new System.Windows.Forms.TextBox();
            this.SecretaryTB = new System.Windows.Forms.TextBox();
            this.viceTB = new System.Windows.Forms.TextBox();
            this.presTB = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 18);
            this.label1.TabIndex = 266;
            this.label1.Text = "Archive Organizatiom";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(0, 36);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1171, 10);
            this.panel1.TabIndex = 267;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.otherLevel);
            this.groupBox1.Controls.Add(this.otherAgency);
            this.groupBox1.Controls.Add(this.requirementTB);
            this.groupBox1.Controls.Add(this.requirementCB);
            this.groupBox1.Controls.Add(this.ProvideTB);
            this.groupBox1.Controls.Add(this.financingTB);
            this.groupBox1.Controls.Add(this.purposeTB);
            this.groupBox1.Controls.Add(this.StatusTB);
            this.groupBox1.Controls.Add(this.benefitTB);
            this.groupBox1.Controls.Add(this.costsTB);
            this.groupBox1.Controls.Add(this.projectTB);
            this.groupBox1.Controls.Add(this.LevelCB);
            this.groupBox1.Controls.Add(this.AgencyCB);
            this.groupBox1.Controls.Add(this.cyTB);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.DateDTP);
            this.groupBox1.Controls.Add(this.ContactTB);
            this.groupBox1.Controls.Add(this.AddressTB);
            this.groupBox1.Controls.Add(this.oNameTB);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(37, 48);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(617, 491);
            this.groupBox1.TabIndex = 268;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Application Form";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(508, 13);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 68;
            this.textBox2.Visible = false;
            // 
            // otherLevel
            // 
            this.otherLevel.Location = new System.Drawing.Point(339, 167);
            this.otherLevel.Name = "otherLevel";
            this.otherLevel.Size = new System.Drawing.Size(146, 22);
            this.otherLevel.TabIndex = 67;
            // 
            // otherAgency
            // 
            this.otherAgency.Location = new System.Drawing.Point(339, 137);
            this.otherAgency.Name = "otherAgency";
            this.otherAgency.Size = new System.Drawing.Size(146, 22);
            this.otherAgency.TabIndex = 66;
            // 
            // requirementTB
            // 
            this.requirementTB.Location = new System.Drawing.Point(251, 434);
            this.requirementTB.Multiline = true;
            this.requirementTB.Name = "requirementTB";
            this.requirementTB.Size = new System.Drawing.Size(185, 47);
            this.requirementTB.TabIndex = 65;
            // 
            // requirementCB
            // 
            this.requirementCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.requirementCB.FormattingEnabled = true;
            this.requirementCB.Location = new System.Drawing.Point(168, 404);
            this.requirementCB.Name = "requirementCB";
            this.requirementCB.Size = new System.Drawing.Size(121, 24);
            this.requirementCB.TabIndex = 64;
            // 
            // ProvideTB
            // 
            this.ProvideTB.Location = new System.Drawing.Point(11, 351);
            this.ProvideTB.Multiline = true;
            this.ProvideTB.Name = "ProvideTB";
            this.ProvideTB.Size = new System.Drawing.Size(425, 47);
            this.ProvideTB.TabIndex = 63;
            // 
            // financingTB
            // 
            this.financingTB.Location = new System.Drawing.Point(301, 282);
            this.financingTB.Multiline = true;
            this.financingTB.Name = "financingTB";
            this.financingTB.Size = new System.Drawing.Size(303, 47);
            this.financingTB.TabIndex = 62;
            // 
            // purposeTB
            // 
            this.purposeTB.Location = new System.Drawing.Point(11, 282);
            this.purposeTB.Multiline = true;
            this.purposeTB.Name = "purposeTB";
            this.purposeTB.Size = new System.Drawing.Size(284, 47);
            this.purposeTB.TabIndex = 61;
            // 
            // StatusTB
            // 
            this.StatusTB.Location = new System.Drawing.Point(438, 213);
            this.StatusTB.Multiline = true;
            this.StatusTB.Name = "StatusTB";
            this.StatusTB.Size = new System.Drawing.Size(136, 47);
            this.StatusTB.TabIndex = 60;
            // 
            // benefitTB
            // 
            this.benefitTB.Location = new System.Drawing.Point(300, 213);
            this.benefitTB.Multiline = true;
            this.benefitTB.Name = "benefitTB";
            this.benefitTB.Size = new System.Drawing.Size(136, 47);
            this.benefitTB.TabIndex = 59;
            // 
            // costsTB
            // 
            this.costsTB.Location = new System.Drawing.Point(159, 213);
            this.costsTB.Multiline = true;
            this.costsTB.Name = "costsTB";
            this.costsTB.Size = new System.Drawing.Size(136, 47);
            this.costsTB.TabIndex = 58;
            // 
            // projectTB
            // 
            this.projectTB.Location = new System.Drawing.Point(11, 213);
            this.projectTB.Multiline = true;
            this.projectTB.Name = "projectTB";
            this.projectTB.Size = new System.Drawing.Size(146, 47);
            this.projectTB.TabIndex = 57;
            // 
            // LevelCB
            // 
            this.LevelCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LevelCB.FormattingEnabled = true;
            this.LevelCB.Items.AddRange(new object[] {
            "Barangay-Based",
            "Chapter",
            "Affiliate of a Larger Organization",
            "Others... (Please Specify)..."});
            this.LevelCB.Location = new System.Drawing.Point(168, 167);
            this.LevelCB.Name = "LevelCB";
            this.LevelCB.Size = new System.Drawing.Size(165, 24);
            this.LevelCB.TabIndex = 56;
            // 
            // AgencyCB
            // 
            this.AgencyCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AgencyCB.FormattingEnabled = true;
            this.AgencyCB.Items.AddRange(new object[] {
            "Securities and Exchange Commission",
            "Cooperatives Development Authority",
            "Department of Labor and Employment",
            "Department of Social Welfare and Development",
            "Others... (Please Specify)..."});
            this.AgencyCB.Location = new System.Drawing.Point(168, 137);
            this.AgencyCB.Name = "AgencyCB";
            this.AgencyCB.Size = new System.Drawing.Size(165, 24);
            this.AgencyCB.TabIndex = 55;
            // 
            // cyTB
            // 
            this.cyTB.Location = new System.Drawing.Point(289, 109);
            this.cyTB.Name = "cyTB";
            this.cyTB.Size = new System.Drawing.Size(139, 22);
            this.cyTB.TabIndex = 54;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(6, 431);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(239, 16);
            this.label25.TabIndex = 53;
            this.label25.Text = "if No, Specify the missing requirements:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 9.75F);
            this.label24.Location = new System.Drawing.Point(8, 407);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(154, 16);
            this.label24.TabIndex = 51;
            this.label24.Text = "Requirements Complete?";
            // 
            // DateDTP
            // 
            this.DateDTP.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DateDTP.Location = new System.Drawing.Point(116, 109);
            this.DateDTP.Name = "DateDTP";
            this.DateDTP.Size = new System.Drawing.Size(132, 22);
            this.DateDTP.TabIndex = 40;
            // 
            // ContactTB
            // 
            this.ContactTB.Location = new System.Drawing.Point(451, 81);
            this.ContactTB.Name = "ContactTB";
            this.ContactTB.Size = new System.Drawing.Size(157, 22);
            this.ContactTB.TabIndex = 39;
            // 
            // AddressTB
            // 
            this.AddressTB.Location = new System.Drawing.Point(93, 81);
            this.AddressTB.Name = "AddressTB";
            this.AddressTB.Size = new System.Drawing.Size(265, 22);
            this.AddressTB.TabIndex = 38;
            // 
            // oNameTB
            // 
            this.oNameTB.Location = new System.Drawing.Point(149, 53);
            this.oNameTB.Name = "oNameTB";
            this.oNameTB.Size = new System.Drawing.Size(209, 22);
            this.oNameTB.TabIndex = 37;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(102, 25);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 36;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 28);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(90, 16);
            this.label27.TabIndex = 35;
            this.label27.Text = "Applicant No.:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(435, 194);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(50, 16);
            this.label16.TabIndex = 31;
            this.label16.Text = "Status:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(297, 194);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 16);
            this.label15.TabIndex = 32;
            this.label15.Text = "Benficiaries:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(156, 194);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 16);
            this.label14.TabIndex = 33;
            this.label14.Text = "Costs:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 194);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 16);
            this.label13.TabIndex = 34;
            this.label13.Text = "Project:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(254, 112);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 16);
            this.label12.TabIndex = 30;
            this.label12.Text = "CY:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 332);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(430, 16);
            this.label11.TabIndex = 28;
            this.label11.Text = "SERVICES THE ORGANIZATION PROVIDES OR CAN PARTICIPATE IN:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(297, 263);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(307, 16);
            this.label10.TabIndex = 29;
            this.label10.Text = "PROJECT FINANCING(SOURCES OF SCHEMES):";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 263);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(169, 16);
            this.label9.TabIndex = 27;
            this.label9.Text = "PURPOSES/OBJECTIVES:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 170);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(151, 16);
            this.label8.TabIndex = 26;
            this.label8.Text = "ORGANIZATION LEVEL:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 140);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(156, 16);
            this.label7.TabIndex = 25;
            this.label7.Text = "REGISTERING AGENCY:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 112);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 16);
            this.label6.TabIndex = 24;
            this.label6.Text = "Date Organized:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(364, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 16);
            this.label5.TabIndex = 23;
            this.label5.Text = "Contact No.:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 16);
            this.label4.TabIndex = 22;
            this.label4.Text = "Address:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 16);
            this.label3.TabIndex = 21;
            this.label3.Text = "Name of Organization:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.bm5TB);
            this.groupBox2.Controls.Add(this.bm4TB);
            this.groupBox2.Controls.Add(this.bm3TB);
            this.groupBox2.Controls.Add(this.bm2TB);
            this.groupBox2.Controls.Add(this.bm1TB);
            this.groupBox2.Controls.Add(this.chairmanTB);
            this.groupBox2.Controls.Add(this.auditorTB);
            this.groupBox2.Controls.Add(this.treasurerTB);
            this.groupBox2.Controls.Add(this.SecretaryTB);
            this.groupBox2.Controls.Add(this.viceTB);
            this.groupBox2.Controls.Add(this.presTB);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Location = new System.Drawing.Point(762, 48);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(339, 451);
            this.groupBox2.TabIndex = 269;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "List of Officers";
            // 
            // bm5TB
            // 
            this.bm5TB.Location = new System.Drawing.Point(68, 424);
            this.bm5TB.Name = "bm5TB";
            this.bm5TB.Size = new System.Drawing.Size(211, 22);
            this.bm5TB.TabIndex = 19;
            // 
            // bm4TB
            // 
            this.bm4TB.Location = new System.Drawing.Point(68, 396);
            this.bm4TB.Name = "bm4TB";
            this.bm4TB.Size = new System.Drawing.Size(211, 22);
            this.bm4TB.TabIndex = 18;
            // 
            // bm3TB
            // 
            this.bm3TB.Location = new System.Drawing.Point(68, 368);
            this.bm3TB.Name = "bm3TB";
            this.bm3TB.Size = new System.Drawing.Size(211, 22);
            this.bm3TB.TabIndex = 17;
            // 
            // bm2TB
            // 
            this.bm2TB.Location = new System.Drawing.Point(68, 340);
            this.bm2TB.Name = "bm2TB";
            this.bm2TB.Size = new System.Drawing.Size(211, 22);
            this.bm2TB.TabIndex = 16;
            // 
            // bm1TB
            // 
            this.bm1TB.Location = new System.Drawing.Point(68, 312);
            this.bm1TB.Name = "bm1TB";
            this.bm1TB.Size = new System.Drawing.Size(211, 22);
            this.bm1TB.TabIndex = 15;
            // 
            // chairmanTB
            // 
            this.chairmanTB.Location = new System.Drawing.Point(68, 268);
            this.chairmanTB.Name = "chairmanTB";
            this.chairmanTB.Size = new System.Drawing.Size(211, 22);
            this.chairmanTB.TabIndex = 14;
            // 
            // auditorTB
            // 
            this.auditorTB.Location = new System.Drawing.Point(68, 208);
            this.auditorTB.Name = "auditorTB";
            this.auditorTB.Size = new System.Drawing.Size(211, 22);
            this.auditorTB.TabIndex = 13;
            // 
            // treasurerTB
            // 
            this.treasurerTB.Location = new System.Drawing.Point(68, 164);
            this.treasurerTB.Name = "treasurerTB";
            this.treasurerTB.Size = new System.Drawing.Size(211, 22);
            this.treasurerTB.TabIndex = 12;
            // 
            // SecretaryTB
            // 
            this.SecretaryTB.Location = new System.Drawing.Point(68, 120);
            this.SecretaryTB.Name = "SecretaryTB";
            this.SecretaryTB.Size = new System.Drawing.Size(211, 22);
            this.SecretaryTB.TabIndex = 11;
            // 
            // viceTB
            // 
            this.viceTB.Location = new System.Drawing.Point(68, 76);
            this.viceTB.Name = "viceTB";
            this.viceTB.Size = new System.Drawing.Size(211, 22);
            this.viceTB.TabIndex = 10;
            // 
            // presTB
            // 
            this.presTB.Location = new System.Drawing.Point(68, 32);
            this.presTB.Name = "presTB";
            this.presTB.Size = new System.Drawing.Size(211, 22);
            this.presTB.TabIndex = 9;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(28, 293);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(104, 16);
            this.label26.TabIndex = 1;
            this.label26.Text = "Board Members:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(28, 249);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(67, 16);
            this.label23.TabIndex = 2;
            this.label23.Text = "Chairman:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(28, 233);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(237, 16);
            this.label22.TabIndex = 3;
            this.label22.Text = "Chairman of the Board/Board Members:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(28, 189);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 16);
            this.label21.TabIndex = 4;
            this.label21.Text = "Auditor:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(28, 145);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(66, 16);
            this.label20.TabIndex = 5;
            this.label20.Text = "Treasurer:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(28, 101);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(68, 16);
            this.label19.TabIndex = 6;
            this.label19.Text = "Secretary:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(28, 57);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(97, 16);
            this.label18.TabIndex = 7;
            this.label18.Text = "Vice-President:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(28, 13);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 16);
            this.label17.TabIndex = 8;
            this.label17.Text = "President:";
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Archive organization";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.ForeColor = System.Drawing.Color.Black;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton1.Iconimage")));
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 45D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(993, 503);
            this.bunifuFlatButton1.Margin = new System.Windows.Forms.Padding(3, 9, 3, 9);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.Black;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(167, 37);
            this.bunifuFlatButton1.TabIndex = 270;
            this.bunifuFlatButton1.Text = "Archive organization";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.Black;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // OrgArchive
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.bunifuFlatButton1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "OrgArchive";
            this.Size = new System.Drawing.Size(1161, 546);
            this.Load += new System.EventHandler(this.OrgArchive_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.TextBox textBox2;
        public System.Windows.Forms.TextBox otherLevel;
        public System.Windows.Forms.TextBox otherAgency;
        public System.Windows.Forms.TextBox requirementTB;
        public System.Windows.Forms.ComboBox requirementCB;
        public System.Windows.Forms.TextBox ProvideTB;
        public System.Windows.Forms.TextBox financingTB;
        public System.Windows.Forms.TextBox purposeTB;
        public System.Windows.Forms.TextBox StatusTB;
        public System.Windows.Forms.TextBox benefitTB;
        public System.Windows.Forms.TextBox costsTB;
        public System.Windows.Forms.TextBox projectTB;
        public System.Windows.Forms.ComboBox LevelCB;
        public System.Windows.Forms.ComboBox AgencyCB;
        public System.Windows.Forms.TextBox cyTB;
        public System.Windows.Forms.Label label25;
        public System.Windows.Forms.Label label24;
        public System.Windows.Forms.DateTimePicker DateDTP;
        public System.Windows.Forms.TextBox ContactTB;
        public System.Windows.Forms.TextBox AddressTB;
        public System.Windows.Forms.TextBox oNameTB;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.Label label27;
        public System.Windows.Forms.Label label16;
        public System.Windows.Forms.Label label15;
        public System.Windows.Forms.Label label14;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.TextBox bm5TB;
        public System.Windows.Forms.TextBox bm4TB;
        public System.Windows.Forms.TextBox bm3TB;
        public System.Windows.Forms.TextBox bm2TB;
        public System.Windows.Forms.TextBox bm1TB;
        public System.Windows.Forms.TextBox chairmanTB;
        public System.Windows.Forms.TextBox auditorTB;
        public System.Windows.Forms.TextBox treasurerTB;
        public System.Windows.Forms.TextBox SecretaryTB;
        public System.Windows.Forms.TextBox viceTB;
        public System.Windows.Forms.TextBox presTB;
        public System.Windows.Forms.Label label26;
        public System.Windows.Forms.Label label23;
        public System.Windows.Forms.Label label22;
        public System.Windows.Forms.Label label21;
        public System.Windows.Forms.Label label20;
        public System.Windows.Forms.Label label19;
        public System.Windows.Forms.Label label18;
        public System.Windows.Forms.Label label17;
        public Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
    }
}
