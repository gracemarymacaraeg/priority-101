﻿namespace LMTFBP
{
    partial class orgViewList
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tName = new System.Windows.Forms.TextBox();
            this.tAddress = new System.Windows.Forms.TextBox();
            this.tContact = new System.Windows.Forms.TextBox();
            this.tDate = new System.Windows.Forms.DateTimePicker();
            this.tCY = new System.Windows.Forms.TextBox();
            this.tPresident = new System.Windows.Forms.TextBox();
            this.tVice = new System.Windows.Forms.TextBox();
            this.tSecretary = new System.Windows.Forms.TextBox();
            this.tTreasurer = new System.Windows.Forms.TextBox();
            this.tAuditor = new System.Windows.Forms.TextBox();
            this.tChairman = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tBoard1 = new System.Windows.Forms.TextBox();
            this.tBoard2 = new System.Windows.Forms.TextBox();
            this.tBoard3 = new System.Windows.Forms.TextBox();
            this.tBoard4 = new System.Windows.Forms.TextBox();
            this.tBoard5 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.bunifuCustomDataGrid1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label13 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(15, 288);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 16);
            this.label12.TabIndex = 107;
            this.label12.Text = "CY:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 235);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 16);
            this.label10.TabIndex = 106;
            this.label10.Text = "Date Organized:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 184);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 16);
            this.label6.TabIndex = 105;
            this.label6.Text = "Contact No.:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 132);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 16);
            this.label8.TabIndex = 104;
            this.label8.Text = "Address:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 80);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(137, 16);
            this.label9.TabIndex = 103;
            this.label9.Text = "Name of Organization:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(280, 318);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(67, 16);
            this.label23.TabIndex = 113;
            this.label23.Text = "Chairman:";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(280, 300);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(237, 16);
            this.label22.TabIndex = 114;
            this.label22.Text = "Chairman of the Board/Board Members:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(280, 256);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 16);
            this.label5.TabIndex = 108;
            this.label5.Text = "Auditor:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(280, 212);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 16);
            this.label4.TabIndex = 109;
            this.label4.Text = "Treasurer:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(280, 168);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 16);
            this.label3.TabIndex = 110;
            this.label3.Text = "Secretary:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(280, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 16);
            this.label2.TabIndex = 111;
            this.label2.Text = "Vice-President:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(280, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 16);
            this.label1.TabIndex = 112;
            this.label1.Text = "President:";
            // 
            // tName
            // 
            this.tName.Enabled = false;
            this.tName.Location = new System.Drawing.Point(34, 99);
            this.tName.Name = "tName";
            this.tName.Size = new System.Drawing.Size(226, 22);
            this.tName.TabIndex = 115;
            this.tName.TextChanged += new System.EventHandler(this.tName_TextChanged);
            // 
            // tAddress
            // 
            this.tAddress.Enabled = false;
            this.tAddress.Location = new System.Drawing.Point(34, 151);
            this.tAddress.Name = "tAddress";
            this.tAddress.Size = new System.Drawing.Size(226, 22);
            this.tAddress.TabIndex = 116;
            this.tAddress.TextChanged += new System.EventHandler(this.tAddress_TextChanged);
            // 
            // tContact
            // 
            this.tContact.Enabled = false;
            this.tContact.Location = new System.Drawing.Point(34, 203);
            this.tContact.Name = "tContact";
            this.tContact.Size = new System.Drawing.Size(226, 22);
            this.tContact.TabIndex = 117;
            this.tContact.TextChanged += new System.EventHandler(this.tContact_TextChanged);
            // 
            // tDate
            // 
            this.tDate.CalendarForeColor = System.Drawing.Color.Transparent;
            this.tDate.CalendarMonthBackground = System.Drawing.Color.Transparent;
            this.tDate.CalendarTitleBackColor = System.Drawing.Color.Transparent;
            this.tDate.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.tDate.Enabled = false;
            this.tDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.tDate.Location = new System.Drawing.Point(34, 254);
            this.tDate.Name = "tDate";
            this.tDate.Size = new System.Drawing.Size(226, 22);
            this.tDate.TabIndex = 118;
            this.tDate.ValueChanged += new System.EventHandler(this.tDate_ValueChanged);
            // 
            // tCY
            // 
            this.tCY.Enabled = false;
            this.tCY.Location = new System.Drawing.Point(34, 307);
            this.tCY.Name = "tCY";
            this.tCY.Size = new System.Drawing.Size(129, 22);
            this.tCY.TabIndex = 119;
            this.tCY.TextChanged += new System.EventHandler(this.tCY_TextChanged);
            // 
            // tPresident
            // 
            this.tPresident.Enabled = false;
            this.tPresident.Location = new System.Drawing.Point(294, 99);
            this.tPresident.Name = "tPresident";
            this.tPresident.Size = new System.Drawing.Size(177, 22);
            this.tPresident.TabIndex = 120;
            this.tPresident.TextChanged += new System.EventHandler(this.tPresident_TextChanged);
            // 
            // tVice
            // 
            this.tVice.Enabled = false;
            this.tVice.Location = new System.Drawing.Point(294, 143);
            this.tVice.Name = "tVice";
            this.tVice.Size = new System.Drawing.Size(177, 22);
            this.tVice.TabIndex = 121;
            this.tVice.TextChanged += new System.EventHandler(this.tVice_TextChanged);
            // 
            // tSecretary
            // 
            this.tSecretary.Enabled = false;
            this.tSecretary.Location = new System.Drawing.Point(294, 187);
            this.tSecretary.Name = "tSecretary";
            this.tSecretary.Size = new System.Drawing.Size(177, 22);
            this.tSecretary.TabIndex = 122;
            this.tSecretary.TextChanged += new System.EventHandler(this.tSecretary_TextChanged);
            // 
            // tTreasurer
            // 
            this.tTreasurer.Enabled = false;
            this.tTreasurer.Location = new System.Drawing.Point(294, 231);
            this.tTreasurer.Name = "tTreasurer";
            this.tTreasurer.Size = new System.Drawing.Size(177, 22);
            this.tTreasurer.TabIndex = 123;
            this.tTreasurer.TextChanged += new System.EventHandler(this.tTreasurer_TextChanged);
            // 
            // tAuditor
            // 
            this.tAuditor.Enabled = false;
            this.tAuditor.Location = new System.Drawing.Point(294, 275);
            this.tAuditor.Name = "tAuditor";
            this.tAuditor.Size = new System.Drawing.Size(177, 22);
            this.tAuditor.TabIndex = 124;
            this.tAuditor.TextChanged += new System.EventHandler(this.tAuditor_TextChanged);
            // 
            // tChairman
            // 
            this.tChairman.Enabled = false;
            this.tChairman.Location = new System.Drawing.Point(294, 337);
            this.tChairman.Name = "tChairman";
            this.tChairman.Size = new System.Drawing.Size(177, 22);
            this.tChairman.TabIndex = 125;
            this.tChairman.TextChanged += new System.EventHandler(this.tChairman_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(280, 362);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 16);
            this.label7.TabIndex = 126;
            this.label7.Text = "Board members:";
            // 
            // tBoard1
            // 
            this.tBoard1.Enabled = false;
            this.tBoard1.Location = new System.Drawing.Point(294, 381);
            this.tBoard1.Name = "tBoard1";
            this.tBoard1.Size = new System.Drawing.Size(177, 22);
            this.tBoard1.TabIndex = 127;
            this.tBoard1.TextChanged += new System.EventHandler(this.tBoard1_TextChanged);
            // 
            // tBoard2
            // 
            this.tBoard2.Enabled = false;
            this.tBoard2.Location = new System.Drawing.Point(294, 409);
            this.tBoard2.Name = "tBoard2";
            this.tBoard2.Size = new System.Drawing.Size(177, 22);
            this.tBoard2.TabIndex = 128;
            // 
            // tBoard3
            // 
            this.tBoard3.Enabled = false;
            this.tBoard3.Location = new System.Drawing.Point(294, 437);
            this.tBoard3.Name = "tBoard3";
            this.tBoard3.Size = new System.Drawing.Size(177, 22);
            this.tBoard3.TabIndex = 129;
            this.tBoard3.TextChanged += new System.EventHandler(this.textBox13_TextChanged);
            // 
            // tBoard4
            // 
            this.tBoard4.Enabled = false;
            this.tBoard4.Location = new System.Drawing.Point(294, 465);
            this.tBoard4.Name = "tBoard4";
            this.tBoard4.Size = new System.Drawing.Size(177, 22);
            this.tBoard4.TabIndex = 130;
            // 
            // tBoard5
            // 
            this.tBoard5.Enabled = false;
            this.tBoard5.Location = new System.Drawing.Point(294, 493);
            this.tBoard5.Name = "tBoard5";
            this.tBoard5.Size = new System.Drawing.Size(177, 22);
            this.tBoard5.TabIndex = 131;
            this.tBoard5.TextChanged += new System.EventHandler(this.textBox15_TextChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(0, 36);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1171, 10);
            this.panel1.TabIndex = 263;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(9, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(258, 18);
            this.label11.TabIndex = 264;
            this.label11.Text = "Toda Officers and Members";
            // 
            // bunifuCustomDataGrid1
            // 
            this.bunifuCustomDataGrid1.AllowUserToAddRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuCustomDataGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.bunifuCustomDataGrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.bunifuCustomDataGrid1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.bunifuCustomDataGrid1.BackgroundColor = System.Drawing.Color.SkyBlue;
            this.bunifuCustomDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuCustomDataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.DeepSkyBlue;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Arial", 9.75F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuCustomDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.bunifuCustomDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bunifuCustomDataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7});
            this.bunifuCustomDataGrid1.DoubleBuffered = true;
            this.bunifuCustomDataGrid1.EnableHeadersVisualStyles = false;
            this.bunifuCustomDataGrid1.GridColor = System.Drawing.Color.White;
            this.bunifuCustomDataGrid1.HeaderBgColor = System.Drawing.Color.DeepSkyBlue;
            this.bunifuCustomDataGrid1.HeaderForeColor = System.Drawing.Color.Black;
            this.bunifuCustomDataGrid1.Location = new System.Drawing.Point(594, 80);
            this.bunifuCustomDataGrid1.Name = "bunifuCustomDataGrid1";
            this.bunifuCustomDataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.bunifuCustomDataGrid1.Size = new System.Drawing.Size(445, 379);
            this.bunifuCustomDataGrid1.TabIndex = 265;
            this.bunifuCustomDataGrid1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bunifuCustomDataGrid1_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Applicant No.";
            this.Column1.Name = "Column1";
            this.Column1.Width = 110;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Last Name";
            this.Column2.Name = "Column2";
            this.Column2.Width = 95;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "First Name";
            this.Column3.Name = "Column3";
            this.Column3.Width = 96;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Middle Initial";
            this.Column4.Name = "Column4";
            this.Column4.Width = 104;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Suffix";
            this.Column5.Name = "Column5";
            this.Column5.Width = 64;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Gender";
            this.Column6.Name = "Column6";
            this.Column6.Width = 74;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Position";
            this.Column7.Name = "Column7";
            this.Column7.Width = 79;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(579, 61);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(112, 16);
            this.label13.TabIndex = 266;
            this.label13.Text = "Lists of Members:";
            // 
            // orgViewList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.label13);
            this.Controls.Add(this.bunifuCustomDataGrid1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tBoard5);
            this.Controls.Add(this.tBoard4);
            this.Controls.Add(this.tBoard3);
            this.Controls.Add(this.tBoard2);
            this.Controls.Add(this.tBoard1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tChairman);
            this.Controls.Add(this.tAuditor);
            this.Controls.Add(this.tTreasurer);
            this.Controls.Add(this.tSecretary);
            this.Controls.Add(this.tVice);
            this.Controls.Add(this.tPresident);
            this.Controls.Add(this.tCY);
            this.Controls.Add(this.tDate);
            this.Controls.Add(this.tContact);
            this.Controls.Add(this.tAddress);
            this.Controls.Add(this.tName);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Font = new System.Drawing.Font("Arial", 9.75F);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "orgViewList";
            this.Size = new System.Drawing.Size(1163, 548);
            this.Load += new System.EventHandler(this.orgViewList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label label23;
        public System.Windows.Forms.Label label22;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox tName;
        public System.Windows.Forms.TextBox tAddress;
        public System.Windows.Forms.TextBox tContact;
        public System.Windows.Forms.DateTimePicker tDate;
        public System.Windows.Forms.TextBox tCY;
        public System.Windows.Forms.TextBox tPresident;
        public System.Windows.Forms.TextBox tVice;
        public System.Windows.Forms.TextBox tSecretary;
        public System.Windows.Forms.TextBox tTreasurer;
        public System.Windows.Forms.TextBox tAuditor;
        public System.Windows.Forms.TextBox tChairman;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.TextBox tBoard1;
        public System.Windows.Forms.TextBox tBoard2;
        public System.Windows.Forms.TextBox tBoard3;
        public System.Windows.Forms.TextBox tBoard4;
        public System.Windows.Forms.TextBox tBoard5;
        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Label label11;
        private Bunifu.Framework.UI.BunifuCustomDataGrid bunifuCustomDataGrid1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        public System.Windows.Forms.Label label13;
    }
}
