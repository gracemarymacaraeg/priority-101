﻿namespace LMTFBP
{
    partial class bHomepage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(bHomepage));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.SearchBtn = new Bunifu.Framework.UI.BunifuImageButton();
            this.Search = new Bunifu.Framework.UI.BunifuTextbox();
            this.ViewRecords = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Home = new Bunifu.Framework.UI.BunifuFlatButton();
            this.LogOut = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuFlatButton3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.AddNew = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.uTypeLbl = new System.Windows.Forms.Label();
            this.nameLbl = new System.Windows.Forms.Label();
            this.DepartmentLbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SearchBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogOut)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = global::LMTFBP.Properties.Resources.Logo;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 115);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(168, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(733, 115);
            this.panel1.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(279, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(429, 31);
            this.label3.TabIndex = 0;
            this.label3.Text = "MUNICIPAL LICENSING OFFICE";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(367, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(244, 31);
            this.label2.TabIndex = 0;
            this.label2.Text = "Province of Laguna";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(340, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(300, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Municipality of Lumban";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.SearchBtn);
            this.panel2.Controls.Add(this.Search);
            this.panel2.Controls.Add(this.ViewRecords);
            this.panel2.Controls.Add(this.Home);
            this.panel2.Controls.Add(this.LogOut);
            this.panel2.Controls.Add(this.bunifuFlatButton3);
            this.panel2.Controls.Add(this.AddNew);
            this.panel2.Location = new System.Drawing.Point(0, 148);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1169, 32);
            this.panel2.TabIndex = 3;
            // 
            // SearchBtn
            // 
            this.SearchBtn.BackColor = System.Drawing.Color.Transparent;
            this.SearchBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SearchBtn.ErrorImage = null;
            this.SearchBtn.Image = ((System.Drawing.Image)(resources.GetObject("SearchBtn.Image")));
            this.SearchBtn.ImageActive = null;
            this.SearchBtn.InitialImage = null;
            this.SearchBtn.Location = new System.Drawing.Point(582, 3);
            this.SearchBtn.Name = "SearchBtn";
            this.SearchBtn.Size = new System.Drawing.Size(35, 25);
            this.SearchBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SearchBtn.TabIndex = 0;
            this.SearchBtn.TabStop = false;
            this.SearchBtn.Zoom = 15;
            // 
            // Search
            // 
            this.Search.BackColor = System.Drawing.Color.SkyBlue;
            this.Search.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Search.BackgroundImage")));
            this.Search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Search.ForeColor = System.Drawing.Color.Black;
            this.Search.Icon = ((System.Drawing.Image)(resources.GetObject("Search.Icon")));
            this.Search.Location = new System.Drawing.Point(331, 0);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(250, 30);
            this.Search.TabIndex = 0;
            this.Search.text = "Search";
            // 
            // ViewRecords
            // 
            this.ViewRecords.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.ViewRecords.BackColor = System.Drawing.Color.Transparent;
            this.ViewRecords.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ViewRecords.BorderRadius = 0;
            this.ViewRecords.ButtonText = "View Records";
            this.ViewRecords.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ViewRecords.DisabledColor = System.Drawing.Color.Gray;
            this.ViewRecords.ForeColor = System.Drawing.Color.Black;
            this.ViewRecords.Iconcolor = System.Drawing.Color.Transparent;
            this.ViewRecords.Iconimage = ((System.Drawing.Image)(resources.GetObject("ViewRecords.Iconimage")));
            this.ViewRecords.Iconimage_right = null;
            this.ViewRecords.Iconimage_right_Selected = null;
            this.ViewRecords.Iconimage_Selected = null;
            this.ViewRecords.IconMarginLeft = 0;
            this.ViewRecords.IconMarginRight = 0;
            this.ViewRecords.IconRightVisible = true;
            this.ViewRecords.IconRightZoom = 0D;
            this.ViewRecords.IconVisible = true;
            this.ViewRecords.IconZoom = 50D;
            this.ViewRecords.IsTab = false;
            this.ViewRecords.Location = new System.Drawing.Point(0, 0);
            this.ViewRecords.Name = "ViewRecords";
            this.ViewRecords.Normalcolor = System.Drawing.Color.Transparent;
            this.ViewRecords.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.ViewRecords.OnHoverTextColor = System.Drawing.Color.Black;
            this.ViewRecords.selected = false;
            this.ViewRecords.Size = new System.Drawing.Size(158, 30);
            this.ViewRecords.TabIndex = 0;
            this.ViewRecords.Text = "View Records";
            this.ViewRecords.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ViewRecords.Textcolor = System.Drawing.Color.Black;
            this.ViewRecords.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewRecords.Click += new System.EventHandler(this.ViewRecords_Click);
            // 
            // Home
            // 
            this.Home.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.Home.BackColor = System.Drawing.Color.Transparent;
            this.Home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Home.BorderRadius = 5;
            this.Home.ButtonText = "Home";
            this.Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Home.DisabledColor = System.Drawing.Color.Gray;
            this.Home.ForeColor = System.Drawing.Color.Black;
            this.Home.Iconcolor = System.Drawing.Color.Transparent;
            this.Home.Iconimage = null;
            this.Home.Iconimage_right = ((System.Drawing.Image)(resources.GetObject("Home.Iconimage_right")));
            this.Home.Iconimage_right_Selected = null;
            this.Home.Iconimage_Selected = null;
            this.Home.IconMarginLeft = 0;
            this.Home.IconMarginRight = 0;
            this.Home.IconRightVisible = true;
            this.Home.IconRightZoom = 0D;
            this.Home.IconVisible = true;
            this.Home.IconZoom = 50D;
            this.Home.IsTab = false;
            this.Home.Location = new System.Drawing.Point(969, 0);
            this.Home.Name = "Home";
            this.Home.Normalcolor = System.Drawing.Color.Transparent;
            this.Home.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.Home.OnHoverTextColor = System.Drawing.Color.Black;
            this.Home.selected = false;
            this.Home.Size = new System.Drawing.Size(158, 30);
            this.Home.TabIndex = 3;
            this.Home.Text = "Home";
            this.Home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Home.Textcolor = System.Drawing.Color.Black;
            this.Home.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // LogOut
            // 
            this.LogOut.BackColor = System.Drawing.Color.Transparent;
            this.LogOut.Image = ((System.Drawing.Image)(resources.GetObject("LogOut.Image")));
            this.LogOut.ImageActive = null;
            this.LogOut.Location = new System.Drawing.Point(1129, 1);
            this.LogOut.Name = "LogOut";
            this.LogOut.Size = new System.Drawing.Size(38, 28);
            this.LogOut.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.LogOut.TabIndex = 3;
            this.LogOut.TabStop = false;
            this.LogOut.Zoom = 10;
            this.LogOut.Click += new System.EventHandler(this.LogOut_Click);
            // 
            // bunifuFlatButton3
            // 
            this.bunifuFlatButton3.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.bunifuFlatButton3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton3.BorderRadius = 0;
            this.bunifuFlatButton3.ButtonText = "Account\'s List";
            this.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton3.Iconimage")));
            this.bunifuFlatButton3.Iconimage_right = null;
            this.bunifuFlatButton3.Iconimage_right_Selected = null;
            this.bunifuFlatButton3.Iconimage_Selected = null;
            this.bunifuFlatButton3.IconMarginLeft = 0;
            this.bunifuFlatButton3.IconMarginRight = 0;
            this.bunifuFlatButton3.IconRightVisible = true;
            this.bunifuFlatButton3.IconRightZoom = 0D;
            this.bunifuFlatButton3.IconVisible = true;
            this.bunifuFlatButton3.IconZoom = 45D;
            this.bunifuFlatButton3.IsTab = false;
            this.bunifuFlatButton3.Location = new System.Drawing.Point(805, 0);
            this.bunifuFlatButton3.Name = "bunifuFlatButton3";
            this.bunifuFlatButton3.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.Black;
            this.bunifuFlatButton3.selected = false;
            this.bunifuFlatButton3.Size = new System.Drawing.Size(158, 30);
            this.bunifuFlatButton3.TabIndex = 1;
            this.bunifuFlatButton3.Text = "Account\'s List";
            this.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton3.Textcolor = System.Drawing.Color.Black;
            this.bunifuFlatButton3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton3.Visible = false;
            this.bunifuFlatButton3.Click += new System.EventHandler(this.bunifuFlatButton3_Click);
            // 
            // AddNew
            // 
            this.AddNew.Activecolor = System.Drawing.Color.DeepSkyBlue;
            this.AddNew.BackColor = System.Drawing.Color.Transparent;
            this.AddNew.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.AddNew.BorderRadius = 0;
            this.AddNew.ButtonText = "Add Application";
            this.AddNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddNew.DisabledColor = System.Drawing.Color.Gray;
            this.AddNew.Iconcolor = System.Drawing.Color.Transparent;
            this.AddNew.Iconimage = ((System.Drawing.Image)(resources.GetObject("AddNew.Iconimage")));
            this.AddNew.Iconimage_right = null;
            this.AddNew.Iconimage_right_Selected = null;
            this.AddNew.Iconimage_Selected = null;
            this.AddNew.IconMarginLeft = 0;
            this.AddNew.IconMarginRight = 0;
            this.AddNew.IconRightVisible = true;
            this.AddNew.IconRightZoom = 0D;
            this.AddNew.IconVisible = true;
            this.AddNew.IconZoom = 45D;
            this.AddNew.IsTab = false;
            this.AddNew.Location = new System.Drawing.Point(805, 0);
            this.AddNew.Name = "AddNew";
            this.AddNew.Normalcolor = System.Drawing.Color.Transparent;
            this.AddNew.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.AddNew.OnHoverTextColor = System.Drawing.Color.Black;
            this.AddNew.selected = false;
            this.AddNew.Size = new System.Drawing.Size(158, 30);
            this.AddNew.TabIndex = 4;
            this.AddNew.Text = "Add Application";
            this.AddNew.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AddNew.Textcolor = System.Drawing.Color.Black;
            this.AddNew.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNew.Visible = false;
            this.AddNew.Click += new System.EventHandler(this.AddNew_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Location = new System.Drawing.Point(0, 180);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1169, 548);
            this.panel3.TabIndex = 4;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.uTypeLbl);
            this.panel4.Controls.Add(this.nameLbl);
            this.panel4.Controls.Add(this.DepartmentLbl);
            this.panel4.Location = new System.Drawing.Point(956, 12);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(211, 132);
            this.panel4.TabIndex = 5;
            // 
            // uTypeLbl
            // 
            this.uTypeLbl.AutoSize = true;
            this.uTypeLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uTypeLbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.uTypeLbl.Location = new System.Drawing.Point(13, 93);
            this.uTypeLbl.Name = "uTypeLbl";
            this.uTypeLbl.Size = new System.Drawing.Size(76, 21);
            this.uTypeLbl.TabIndex = 2;
            this.uTypeLbl.Text = "User type";
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameLbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.nameLbl.Location = new System.Drawing.Point(13, 67);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(51, 21);
            this.nameLbl.TabIndex = 1;
            this.nameLbl.Text = "Name";
            this.nameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DepartmentLbl
            // 
            this.DepartmentLbl.AutoSize = true;
            this.DepartmentLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DepartmentLbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DepartmentLbl.Location = new System.Drawing.Point(13, 41);
            this.DepartmentLbl.Name = "DepartmentLbl";
            this.DepartmentLbl.Size = new System.Drawing.Size(91, 21);
            this.DepartmentLbl.TabIndex = 0;
            this.DepartmentLbl.Text = "Department";
            this.DepartmentLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "Business Permit";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bHomepage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1171, 729);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "bHomepage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "bHomepage";
            this.Load += new System.EventHandler(this.bHomepage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SearchBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogOut)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuImageButton SearchBtn;
        private Bunifu.Framework.UI.BunifuTextbox Search;
        private Bunifu.Framework.UI.BunifuFlatButton ViewRecords;
        public Bunifu.Framework.UI.BunifuFlatButton Home;
        public Bunifu.Framework.UI.BunifuImageButton LogOut;
        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.Panel panel4;
        public System.Windows.Forms.Label uTypeLbl;
        public System.Windows.Forms.Label nameLbl;
        public System.Windows.Forms.Label DepartmentLbl;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton3;
        private Bunifu.Framework.UI.BunifuFlatButton AddNew;
        public System.Windows.Forms.Label label4;
    }
}