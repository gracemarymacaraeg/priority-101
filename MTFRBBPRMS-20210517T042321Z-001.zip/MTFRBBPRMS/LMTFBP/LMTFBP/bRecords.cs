﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class bRecords : UserControl
    {
        MySqlConnection cn = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=bplo; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public bRecords()
        {
            InitializeComponent();
        }

        private void bRecords_Load(object sender, EventArgs e)
        {
            cn.Open();
            dataGridView1.Rows.Clear();
            com = cn.CreateCommand();
            com.CommandText = " SELECT* from b_i_information ORDER BY Applicant_Type ASC ";
            reader = com.ExecuteReader();
            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader[1].ToString(), reader[2].ToString(),
                 reader[3].ToString(), reader[4].ToString(), reader[5].ToString(), reader[6].ToString(),
                 reader[7].ToString(), reader[8].ToString(), reader[9].ToString(), reader[10].ToString(),
                 reader[11].ToString(), reader[12].ToString(), reader[13].ToString(), reader[14].ToString());
            }
            reader.Close();
            com.ExecuteNonQuery();
            cn.Close();
            label2.Text = dataGridView1.Rows.Count.ToString();
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            if (bunifuFlatButton2.Text == "Update Records")
            {
                cn.Open();
                com = cn.CreateCommand();
                Update ud = new Update();
                var uc1 = new brenewal();
                ud.panel1.Controls.Clear();
                ud.panel1.Controls.Add(uc1);
                uc1.label1.Text = "Renewal of Permit";
                uc1.label40.Visible = true;
                uc1.label41.Visible = true;
                uc1.transferCB.Visible = true;
                uc1.AmmendCB.Visible = true;
                uc1.textBox1.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
                uc1.applicant_type.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
                uc1.paymentCB.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
                uc1.appDate.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
                uc1.lnameTB.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
                uc1.fnameTB.Text = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();
                uc1.mnameTB.Text = this.dataGridView1.CurrentRow.Cells[6].Value.ToString();
                uc1.suffixTB.Text = this.dataGridView1.CurrentRow.Cells[7].Value.ToString();
                uc1.bnameTB.Text = this.dataGridView1.CurrentRow.Cells[8].Value.ToString();
                uc1.bplateTB.Text = this.dataGridView1.CurrentRow.Cells[9].Value.ToString();
                uc1.tnameTB.Text = this.dataGridView1.CurrentRow.Cells[10].Value.ToString();
                uc1.plname.Text = this.dataGridView1.CurrentRow.Cells[11].Value.ToString();
                uc1.pfname.Text = this.dataGridView1.CurrentRow.Cells[12].Value.ToString();
                uc1.pmname.Text = this.dataGridView1.CurrentRow.Cells[13].Value.ToString();

                if (uc1.applicant_type.Text == "New")
                {
                    com.CommandText = "SELECT * FROM b_i_information WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        uc1.psuffix.Text = reader[15].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();

                    com.CommandText = "SELECT * FROM b_i_requirements WHERE Applicant_no LIKE '" + uc1.textBox1.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        uc1.referenceTB.Text = reader[2].ToString();
                        uc1.dtiDate.Text = reader[3].ToString();
                        uc1.dtiNo.Text = reader[4].ToString();
                        uc1.ctcNo.Text = reader[5].ToString();
                        uc1.tinTB.Text = reader[6].ToString();
                        uc1.orgCB.Text = reader[7].ToString();
                        uc1.govtCB.Text = reader[8].ToString();
                        uc1.specify.Text = reader[9].ToString();
                        uc1.pinTB.Text = reader[10].ToString();
                        uc1.establishTB.Text = reader[11].ToString();
                        uc1.lguTB.Text = reader[12].ToString();
                        uc1.cfnameTB.Text = reader[13].ToString();
                        uc1.ctelnoTB.Text = reader[14].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();

                    com.CommandText = "SELECT * FROM b_i_oaddress WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        uc1.ohouseTB.Text = reader[2].ToString();
                        uc1.obldgTB.Text = reader[3].ToString();
                        uc1.ounitTB.Text = reader[4].ToString();
                        uc1.ostreetTB.Text = reader[5].ToString();
                        uc1.obrgyTB.Text = reader[6].ToString();
                        uc1.osubdTB.Text = reader[7].ToString();
                        uc1.omunTB.Text = reader[8].ToString();
                        uc1.oprovTB.Text = reader[9].ToString();
                        uc1.otelnoTB.Text = reader[10].ToString();
                        uc1.oemailTB.Text = reader[11].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();

                    com.CommandText = "SELECT * FROM b_i_baddress WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        uc1.bhouseTB.Text = reader[2].ToString();
                        uc1.bbldgTB.Text = reader[3].ToString();
                        uc1.bunitTB.Text = reader[4].ToString();
                        uc1.bstreetTB.Text = reader[5].ToString();
                        uc1.bbrgyTB.Text = reader[6].ToString();
                        uc1.bsubdTB.Text = reader[7].ToString();
                        uc1.bmunTB.Text = reader[8].ToString();
                        uc1.bprovinceTB.Text = reader[9].ToString();
                        uc1.btelnoTB.Text = reader[10].ToString();
                        uc1.bemailTB.Text = reader[11].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();

                    com.CommandText = "SELECT * FROM b_i_raddress WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        uc1.llnameTB.Text = reader[2].ToString();
                        uc1.lfnameTB.Text = reader[3].ToString();
                        uc1.lmiTB.Text = reader[4].ToString();
                        uc1.lmonthlyTB.Text = reader[5].ToString();
                        uc1.lhouseTB.Text = reader[6].ToString();
                        uc1.lstreetTB.Text = reader[7].ToString();
                        uc1.lbrgyTB.Text = reader[8].ToString();
                        uc1.lmunTB.Text = reader[9].ToString();
                        uc1.lprovTB.Text = reader[10].ToString();
                        uc1.ltelnoTB.Text = reader[11].ToString();
                        uc1.lemailTB.Text = reader[12].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();

                    com.CommandText = "SELECT * FROM b_i_activity WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        uc1.buscodeTB.Text = reader[2].ToString();
                        uc1.busilineTB.Text = reader[3].ToString();
                        uc1.bnounitTB.Text = reader[4].ToString();
                        uc1.bcapitalTB.Text = reader[5].ToString();
                        uc1.bessentialTB.Text = reader[6].ToString();
                        uc1.bnonessentialTB.Text = reader[7].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();
                    cn.Close();
                }
                else
                {
                    com.CommandText = "SELECT * FROM b_r_renewinfo WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        uc1.psuffix.Text = reader[15].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();

                    com.CommandText = "SELECT * FROM b_r_requirements WHERE Applicant_no LIKE '" + uc1.textBox1.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        uc1.referenceTB.Text = reader[2].ToString();
                        uc1.dtiDate.Text = reader[3].ToString();
                        uc1.dtiNo.Text = reader[4].ToString();
                        uc1.ctcNo.Text = reader[5].ToString();
                        uc1.tinTB.Text = reader[6].ToString();
                        uc1.orgCB.Text = reader[7].ToString();
                        uc1.govtCB.Text = reader[8].ToString();
                        uc1.specify.Text = reader[9].ToString();
                        uc1.pinTB.Text = reader[10].ToString();
                        uc1.establishTB.Text = reader[11].ToString();
                        uc1.lguTB.Text = reader[12].ToString();
                        uc1.cfnameTB.Text = reader[13].ToString();
                        uc1.ctelnoTB.Text = reader[14].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();

                    com.CommandText = "SELECT * FROM b_r_oaddress WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        uc1.ohouseTB.Text = reader[2].ToString();
                        uc1.obldgTB.Text = reader[3].ToString();
                        uc1.ounitTB.Text = reader[4].ToString();
                        uc1.ostreetTB.Text = reader[5].ToString();
                        uc1.obrgyTB.Text = reader[6].ToString();
                        uc1.osubdTB.Text = reader[7].ToString();
                        uc1.omunTB.Text = reader[8].ToString();
                        uc1.oprovTB.Text = reader[9].ToString();
                        uc1.otelnoTB.Text = reader[10].ToString();
                        uc1.oemailTB.Text = reader[11].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();

                    com.CommandText = "SELECT * FROM b_r_baddress WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        uc1.bhouseTB.Text = reader[2].ToString();
                        uc1.bbldgTB.Text = reader[3].ToString();
                        uc1.bunitTB.Text = reader[4].ToString();
                        uc1.bstreetTB.Text = reader[5].ToString();
                        uc1.bbrgyTB.Text = reader[6].ToString();
                        uc1.bsubdTB.Text = reader[7].ToString();
                        uc1.bmunTB.Text = reader[8].ToString();
                        uc1.bprovinceTB.Text = reader[9].ToString();
                        uc1.btelnoTB.Text = reader[10].ToString();
                        uc1.bemailTB.Text = reader[11].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();

                    com.CommandText = "SELECT * FROM b_r_raddress WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        uc1.llnameTB.Text = reader[2].ToString();
                        uc1.lfnameTB.Text = reader[3].ToString();
                        uc1.lmiTB.Text = reader[4].ToString();
                        uc1.lmonthlyTB.Text = reader[5].ToString();
                        uc1.lhouseTB.Text = reader[6].ToString();
                        uc1.lstreetTB.Text = reader[7].ToString();
                        uc1.lbrgyTB.Text = reader[8].ToString();
                        uc1.lmunTB.Text = reader[9].ToString();
                        uc1.lprovTB.Text = reader[10].ToString();
                        uc1.ltelnoTB.Text = reader[11].ToString();
                        uc1.lemailTB.Text = reader[12].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();

                    com.CommandText = "SELECT * FROM b_r_acrtivity WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        uc1.buscodeTB.Text = reader[2].ToString();
                        uc1.busilineTB.Text = reader[3].ToString();
                        uc1.bnounitTB.Text = reader[4].ToString();
                        uc1.bcapitalTB.Text = reader[5].ToString();
                        uc1.bessentialTB.Text = reader[6].ToString();
                        uc1.bnonessentialTB.Text = reader[7].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();
                    cn.Close();
                }
                ud.Show();
                
            }
            else
            {
                cn.Open();
                com = cn.CreateCommand();
                Update ud = new Update();
                var uc1 = new brenewal();
                ud.panel1.Controls.Clear();
                ud.panel1.Controls.Add(uc1);
                uc1.label1.Text = "Update Archive";
                uc1.label40.Visible = true;
                uc1.label41.Visible = true;
                uc1.transferCB.Visible = true;
                uc1.AmmendCB.Visible = true;
                uc1.textBox1.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
                uc1.applicant_type.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
                uc1.paymentCB.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
                uc1.appDate.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
                uc1.lnameTB.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
                uc1.fnameTB.Text = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();
                uc1.mnameTB.Text = this.dataGridView1.CurrentRow.Cells[6].Value.ToString();
                uc1.suffixTB.Text = this.dataGridView1.CurrentRow.Cells[7].Value.ToString();
                uc1.bnameTB.Text = this.dataGridView1.CurrentRow.Cells[8].Value.ToString();
                uc1.bplateTB.Text = this.dataGridView1.CurrentRow.Cells[9].Value.ToString();
                uc1.tnameTB.Text = this.dataGridView1.CurrentRow.Cells[10].Value.ToString();
                uc1.plname.Text = this.dataGridView1.CurrentRow.Cells[11].Value.ToString();
                uc1.pfname.Text = this.dataGridView1.CurrentRow.Cells[12].Value.ToString();
                uc1.pmname.Text = this.dataGridView1.CurrentRow.Cells[13].Value.ToString();

                com.CommandText = "SELECT * FROM b_a_information WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.psuffix.Text = reader[15].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM b_a_requirements WHERE Applicant_no LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.referenceTB.Text = reader[2].ToString();
                    uc1.dtiDate.Text = reader[3].ToString();
                    uc1.dtiNo.Text = reader[4].ToString();
                    uc1.ctcNo.Text = reader[5].ToString();
                    uc1.tinTB.Text = reader[6].ToString();
                    uc1.orgCB.Text = reader[7].ToString();
                    uc1.govtCB.Text = reader[8].ToString();
                    uc1.specify.Text = reader[9].ToString();
                    uc1.pinTB.Text = reader[10].ToString();
                    uc1.establishTB.Text = reader[11].ToString();
                    uc1.lguTB.Text = reader[12].ToString();
                    uc1.cfnameTB.Text = reader[13].ToString();
                    uc1.ctelnoTB.Text = reader[14].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM b_a_oaddress WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.ohouseTB.Text = reader[2].ToString();
                    uc1.obldgTB.Text = reader[3].ToString();
                    uc1.ounitTB.Text = reader[4].ToString();
                    uc1.ostreetTB.Text = reader[5].ToString();
                    uc1.obrgyTB.Text = reader[6].ToString();
                    uc1.osubdTB.Text = reader[7].ToString();
                    uc1.omunTB.Text = reader[8].ToString();
                    uc1.oprovTB.Text = reader[9].ToString();
                    uc1.otelnoTB.Text = reader[10].ToString();
                    uc1.oemailTB.Text = reader[11].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM b_a_baddress WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.bhouseTB.Text = reader[2].ToString();
                    uc1.bbldgTB.Text = reader[3].ToString();
                    uc1.bunitTB.Text = reader[4].ToString();
                    uc1.bstreetTB.Text = reader[5].ToString();
                    uc1.bbrgyTB.Text = reader[6].ToString();
                    uc1.bsubdTB.Text = reader[7].ToString();
                    uc1.bmunTB.Text = reader[8].ToString();
                    uc1.bprovinceTB.Text = reader[9].ToString();
                    uc1.btelnoTB.Text = reader[10].ToString();
                    uc1.bemailTB.Text = reader[11].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM b_a_raddress WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.llnameTB.Text = reader[2].ToString();
                    uc1.lfnameTB.Text = reader[3].ToString();
                    uc1.lmiTB.Text = reader[4].ToString();
                    uc1.lmonthlyTB.Text = reader[5].ToString();
                    uc1.lhouseTB.Text = reader[6].ToString();
                    uc1.lstreetTB.Text = reader[7].ToString();
                    uc1.lbrgyTB.Text = reader[8].ToString();
                    uc1.lmunTB.Text = reader[9].ToString();
                    uc1.lprovTB.Text = reader[10].ToString();
                    uc1.ltelnoTB.Text = reader[11].ToString();
                    uc1.lemailTB.Text = reader[12].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM b_a_activity WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.buscodeTB.Text = reader[2].ToString();
                    uc1.busilineTB.Text = reader[3].ToString();
                    uc1.bnounitTB.Text = reader[4].ToString();
                    uc1.bcapitalTB.Text = reader[5].ToString();
                    uc1.bessentialTB.Text = reader[6].ToString();
                    uc1.bnonessentialTB.Text = reader[7].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();
                cn.Close();

                ud.Show();
            }
        }

        private void Archive_Click(object sender, EventArgs e)
        {

            cn.Open();
            com = cn.CreateCommand();
            Update ud = new Update();
            var uc1 = new bArchive();
            ud.panel1.Controls.Clear();
            ud.panel1.Controls.Add(uc1);
            uc1.label1.Text = "Archive Permit";
            uc1.label40.Visible = true;
            uc1.label41.Visible = true;
            uc1.transferCB.Visible = true;
            uc1.AmmendCB.Visible = true;
            uc1.textBox1.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
            uc1.appNo.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
            uc1.applicant_type.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
            uc1.appType.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
            uc1.paymentCB.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
            uc1.appDate.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
            uc1.lnameTB.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
            uc1.fnameTB.Text = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();
            uc1.mnameTB.Text = this.dataGridView1.CurrentRow.Cells[6].Value.ToString();
            uc1.suffixTB.Text = this.dataGridView1.CurrentRow.Cells[7].Value.ToString();
            uc1.bnameTB.Text = this.dataGridView1.CurrentRow.Cells[8].Value.ToString();
            uc1.bplateTB.Text = this.dataGridView1.CurrentRow.Cells[9].Value.ToString();
            uc1.tnameTB.Text = this.dataGridView1.CurrentRow.Cells[10].Value.ToString();
            uc1.plname.Text = this.dataGridView1.CurrentRow.Cells[11].Value.ToString();
            uc1.pfname.Text = this.dataGridView1.CurrentRow.Cells[12].Value.ToString();
            uc1.pmname.Text = this.dataGridView1.CurrentRow.Cells[13].Value.ToString();
            if (uc1.applicant_type.Text == "New")
            {
                com.CommandText = "SELECT * FROM b_i_information WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.psuffix.Text = reader[15].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM b_i_requirements WHERE Applicant_no LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.referenceTB.Text = reader[2].ToString();
                    uc1.dtiDate.Text = reader[3].ToString();
                    uc1.dtiNo.Text = reader[4].ToString();
                    uc1.ctcNo.Text = reader[5].ToString();
                    uc1.tinTB.Text = reader[6].ToString();
                    uc1.orgCB.Text = reader[7].ToString();
                    uc1.govtCB.Text = reader[8].ToString();
                    uc1.specify.Text = reader[9].ToString();
                    uc1.pinTB.Text = reader[10].ToString();
                    uc1.establishTB.Text = reader[11].ToString();
                    uc1.lguTB.Text = reader[12].ToString();
                    uc1.cfnameTB.Text = reader[13].ToString();
                    uc1.ctelnoTB.Text = reader[14].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM b_i_oaddress WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.ohouseTB.Text = reader[2].ToString();
                    uc1.obldgTB.Text = reader[3].ToString();
                    uc1.ounitTB.Text = reader[4].ToString();
                    uc1.ostreetTB.Text = reader[5].ToString();
                    uc1.obrgyTB.Text = reader[6].ToString();
                    uc1.osubdTB.Text = reader[7].ToString();
                    uc1.omunTB.Text = reader[8].ToString();
                    uc1.oprovTB.Text = reader[9].ToString();
                    uc1.otelnoTB.Text = reader[10].ToString();
                    uc1.oemailTB.Text = reader[11].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM b_i_baddress WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.bhouseTB.Text = reader[2].ToString();
                    uc1.bbldgTB.Text = reader[3].ToString();
                    uc1.bunitTB.Text = reader[4].ToString();
                    uc1.bstreetTB.Text = reader[5].ToString();
                    uc1.bbrgyTB.Text = reader[6].ToString();
                    uc1.bsubdTB.Text = reader[7].ToString();
                    uc1.bmunTB.Text = reader[8].ToString();
                    uc1.bprovinceTB.Text = reader[9].ToString();
                    uc1.btelnoTB.Text = reader[10].ToString();
                    uc1.bemailTB.Text = reader[11].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM b_i_raddress WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.llnameTB.Text = reader[2].ToString();
                    uc1.lfnameTB.Text = reader[3].ToString();
                    uc1.lmiTB.Text = reader[4].ToString();
                    uc1.lmonthlyTB.Text = reader[5].ToString();
                    uc1.lhouseTB.Text = reader[6].ToString();
                    uc1.lstreetTB.Text = reader[7].ToString();
                    uc1.lbrgyTB.Text = reader[8].ToString();
                    uc1.lmunTB.Text = reader[9].ToString();
                    uc1.lprovTB.Text = reader[10].ToString();
                    uc1.ltelnoTB.Text = reader[11].ToString();
                    uc1.lemailTB.Text = reader[12].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM b_i_activity WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.buscodeTB.Text = reader[2].ToString();
                    uc1.busilineTB.Text = reader[3].ToString();
                    uc1.bnounitTB.Text = reader[4].ToString();
                    uc1.bcapitalTB.Text = reader[5].ToString();
                    uc1.bessentialTB.Text = reader[6].ToString();
                    uc1.bnonessentialTB.Text = reader[7].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();
                cn.Close();
            }
            else
            {
                com.CommandText = "SELECT * FROM b_r_renewinfo WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.psuffix.Text = reader[15].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM b_r_requirements WHERE Applicant_no LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.referenceTB.Text = reader[2].ToString();
                    uc1.dtiDate.Text = reader[3].ToString();
                    uc1.dtiNo.Text = reader[4].ToString();
                    uc1.ctcNo.Text = reader[5].ToString();
                    uc1.tinTB.Text = reader[6].ToString();
                    uc1.orgCB.Text = reader[7].ToString();
                    uc1.govtCB.Text = reader[8].ToString();
                    uc1.specify.Text = reader[9].ToString();
                    uc1.pinTB.Text = reader[10].ToString();
                    uc1.establishTB.Text = reader[11].ToString();
                    uc1.lguTB.Text = reader[12].ToString();
                    uc1.cfnameTB.Text = reader[13].ToString();
                    uc1.ctelnoTB.Text = reader[14].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM b_r_oaddress WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.ohouseTB.Text = reader[2].ToString();
                    uc1.obldgTB.Text = reader[3].ToString();
                    uc1.ounitTB.Text = reader[4].ToString();
                    uc1.ostreetTB.Text = reader[5].ToString();
                    uc1.obrgyTB.Text = reader[6].ToString();
                    uc1.osubdTB.Text = reader[7].ToString();
                    uc1.omunTB.Text = reader[8].ToString();
                    uc1.oprovTB.Text = reader[9].ToString();
                    uc1.otelnoTB.Text = reader[10].ToString();
                    uc1.oemailTB.Text = reader[11].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM b_r_baddress WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.bhouseTB.Text = reader[2].ToString();
                    uc1.bbldgTB.Text = reader[3].ToString();
                    uc1.bunitTB.Text = reader[4].ToString();
                    uc1.bstreetTB.Text = reader[5].ToString();
                    uc1.bbrgyTB.Text = reader[6].ToString();
                    uc1.bsubdTB.Text = reader[7].ToString();
                    uc1.bmunTB.Text = reader[8].ToString();
                    uc1.bprovinceTB.Text = reader[9].ToString();
                    uc1.btelnoTB.Text = reader[10].ToString();
                    uc1.bemailTB.Text = reader[11].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM b_r_raddress WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.llnameTB.Text = reader[2].ToString();
                    uc1.lfnameTB.Text = reader[3].ToString();
                    uc1.lmiTB.Text = reader[4].ToString();
                    uc1.lmonthlyTB.Text = reader[5].ToString();
                    uc1.lhouseTB.Text = reader[6].ToString();
                    uc1.lstreetTB.Text = reader[7].ToString();
                    uc1.lbrgyTB.Text = reader[8].ToString();
                    uc1.lmunTB.Text = reader[9].ToString();
                    uc1.lprovTB.Text = reader[10].ToString();
                    uc1.ltelnoTB.Text = reader[11].ToString();
                    uc1.lemailTB.Text = reader[12].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM b_r_acrtivity WHERE Applicant_No LIKE '" + uc1.textBox1.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    uc1.buscodeTB.Text = reader[2].ToString();
                    uc1.busilineTB.Text = reader[3].ToString();
                    uc1.bnounitTB.Text = reader[4].ToString();
                    uc1.bcapitalTB.Text = reader[5].ToString();
                    uc1.bessentialTB.Text = reader[6].ToString();
                    uc1.bnonessentialTB.Text = reader[7].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();
                cn.Close();
            }
            ud.Show();
        }
    }
}
