﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class Account : UserControl
    {
        MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public Account()
        {
            InitializeComponent();
        }

        private void Account_Load(object sender, EventArgs e)
        {
            
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (label1.Text == "Pending Account Registration.")
            {
                IDtb.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
                fnameTB.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
                mnameTB.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
                lnameTB.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
                suffixTB.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
                bdayDTP.Text = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();
                genderCB.Text = this.dataGridView1.CurrentRow.Cells[6].Value.ToString();
                contactTB.Text = this.dataGridView1.CurrentRow.Cells[7].Value.ToString();

                con.Open();
                com = con.CreateCommand();
                com.CommandText = "SELECT * FROM t_pending WHERE Acc_ID LIKE '" + IDtb.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    userTB.Text = reader[10].ToString();
                    pass.Text = reader[11].ToString();
                    repassTB.Text = reader[12].ToString();
                    DeptCB.Text = reader[9].ToString();
                    TypeCB.Text = reader[13].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                IDtb.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
                fnameTB.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
                mnameTB.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
                lnameTB.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
                suffixTB.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
                bdayDTP.Text = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();
                genderCB.Text = this.dataGridView1.CurrentRow.Cells[6].Value.ToString();
                contactTB.Text = this.dataGridView1.CurrentRow.Cells[7].Value.ToString();

                con.Open();
                com = con.CreateCommand();
                com.CommandText = "SELECT * from t_account WHERE Acc_ID LIKE '" + IDtb.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    userTB.Text = reader[10].ToString();
                    pass.Text = reader[11].ToString();
                    repassTB.Text = reader[12].ToString();
                    DeptCB.Text = reader[9].ToString();
                    TypeCB.Text = reader[13].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();
                con.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            if (label1.Text == "Pending Account Registration.")
            {
                con.Open();
                dataGridView1.Rows.Clear();
                com = con.CreateCommand();
                com.CommandText = " SELECT* from t_pending ORDER by Acc_ID ASC ";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    dataGridView1.Rows.Add(reader[1].ToString(), reader[3].ToString(), reader[4].ToString(),
                    reader[2].ToString(), reader[5].ToString(), reader[6].ToString(), reader[7].ToString(),
                    reader[8].ToString());
                }
                reader.Close();
                com.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                con.Open();
                dataGridView1.Rows.Clear();
                com = con.CreateCommand();
                com.CommandText = " SELECT* from t_account ORDER by Acc_ID ASC ";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    dataGridView1.Rows.Add(reader[1].ToString(), reader[3].ToString(), reader[4].ToString(),
                    reader[2].ToString(), reader[5].ToString(), reader[6].ToString(), reader[7].ToString(),
                    reader[8].ToString());
                }
                reader.Close();
                com.ExecuteNonQuery();
                con.Close();
            }
            clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            approved();
            remove();
            clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Account Removed.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            {
                remove();
                clear();
            }
        }
        public void approved()
        {
            DialogResult result = MessageBox.Show("Approve this Account?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                con.Open();
                com = con.CreateCommand();
                com.CommandText = "INSERT into t_account (Acc_ID, Lname, Fname, Mname, Suffix, Birthday, Gender, Contact_No, Department, Username, Password, Repass, Usertype) VALUES ('" +
                    IDtb.Text + "','" + lnameTB.Text + "','" + fnameTB.Text + "','" + mnameTB.Text + "','" + suffixTB.Text + "','" +
                        bdayDTP.Text + "','" + genderCB.Text + "','" + contactTB.Text + "','" + DeptCB.Text + "','" +
                        userTB.Text + "','" + pass.Text + "','" + repassTB.Text + "','" + TypeCB.Text + "')";
                com.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Account Approved.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        public void remove()
        {
            if (label1.Text == "Pending Account Registration.")
            {
                con.Open();
                com = con.CreateCommand();
                com.CommandText = "DELETE from t_pending WHERE Acc_ID = '" + IDtb.Text + "'";
                com.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                con.Open();
                com = con.CreateCommand();
                com.CommandText = "DELETE from t_account WHERE Acc_ID = '" + IDtb.Text + "'";
                com.ExecuteNonQuery();
                con.Close();
            }
        }
        public void disapproved()
        {
            DialogResult result = MessageBox.Show("Remove this Account?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.OK)
            {
                con.Open();
                com = con.CreateCommand();
                com.CommandText = "DELETE from t_pending WHERE ID = '" + IDtb.Text + "'";
                com.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Account Removed.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                pass.UseSystemPasswordChar = false;
                repassTB.UseSystemPasswordChar = false;
                checkBox1.Text = "Hide";
            }
            else
            {
                pass.UseSystemPasswordChar = true;
                repassTB.UseSystemPasswordChar = true;
                checkBox1.Text = "Show";
            }

        }
        public void clear()
        {
            fnameTB.ResetText();
            mnameTB.ResetText();
            lnameTB.ResetText();
            bdayDTP.ResetText();
            genderCB.Items.Clear();
            genderCB.Items.Add("Male");
            genderCB.Items.Add("Female");
            contactTB.ResetText();
            userTB.ResetText();
            pass.ResetText();
            repassTB.ResetText();
            DeptCB.Items.Clear();
            DeptCB.Items.Add("Office of the Mayor");
            DeptCB.Items.Add("Licensing Office");
            DeptCB.Items.Add("Treasury Office");
            DeptCB.Enabled = false;
        }

        private void DeptCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DeptCB.Text == "Office of the Mayor")
            {
                TypeCB.Items.Clear();
                TypeCB.Items.Add("PRC II");
                TypeCB.Items.Add("Admin");
            }
            else if (DeptCB.Text == "Licensing Office")
            {
                TypeCB.Items.Clear();
                TypeCB.Items.Add("Licensing Head");
                TypeCB.Items.Add("Clerk I");
                //TypeCB.Items.Add("Admin");
            }
            else
            {
                TypeCB.Items.Clear();
                TypeCB.Items.Add("Municipal treasurer");
                TypeCB.Items.Add("RCC I");
                //TypeCB.Items.Add("Admin");
            }
        }

        private void NewRecords_Click(object sender, EventArgs e)
        {
            if (NewRecords.Text == "Approved Accounts")
            {
                con.Open();
                label1.Text = "Account List.";
                com = con.CreateCommand();
                dataGridView1.Rows.Clear();
                com.CommandText = " SELECT* from t_account ORDER BY Acc_ID ASC ";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    dataGridView1.Rows.Add(reader[1].ToString(), reader[3].ToString(), reader[4].ToString(),
                        reader[2].ToString(), reader[5].ToString(), reader[6].ToString(), reader[7].ToString(),
                        reader[8].ToString());
                }
                reader.Close();
                com.ExecuteNonQuery();

                if (label1.Text == "Account List.")
                {
                    com.CommandText = "SELECT * FROM t_account WHERE Acc_ID LIKE '" + IDtb.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        TypeCB.Text = reader[13].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();
                }
                con.Close();
            }
            else
            {
                MySqlConnection mycn = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=bplo; charset= utf8");
                mycn.Open();
                label1.Text = "Account List.";
                com = mycn.CreateCommand();
                dataGridView1.Rows.Clear();
                com.CommandText = " SELECT* from b_account ORDER BY Acc_ID ASC ";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    dataGridView1.Rows.Add(reader[1].ToString(), reader[3].ToString(), reader[4].ToString(),
                        reader[2].ToString(), reader[5].ToString(), reader[6].ToString(), reader[7].ToString(),
                        reader[8].ToString());
                }
                reader.Close();
                com.ExecuteNonQuery();

                if (label1.Text == "Account List.")
                {
                    com.CommandText = "SELECT * FROM b_account WHERE Acc_ID LIKE '" + IDtb.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        TypeCB.Text = reader[13].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();
                }
                mycn.Close();
            }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            if (pending.Text == "Pending Accounts")
            {
                con.Open();
                label1.Text = "Pending Account Registration.";
                dataGridView1.Rows.Clear();
                com = con.CreateCommand();
                com.CommandText = " SELECT* from t_pending ORDER BY Acc_ID ASC ";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    dataGridView1.Rows.Add(reader[1].ToString(), reader[3].ToString(), reader[4].ToString(),
                        reader[2].ToString(), reader[5].ToString(), reader[6].ToString(), reader[7].ToString(),
                        reader[8].ToString());
                }
                reader.Close();
                com.ExecuteNonQuery();

                if (label1.Text == "Pending Account Registration.")
                {
                    com.CommandText = "SELECT * FROM t_pending WHERE Acc_ID LIKE '" + IDtb.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        TypeCB.Text = reader[13].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();
                }
                con.Close();
            }
            else
            {
                MySqlConnection mycn = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=bplo; charset= utf8");
                mycn.Open();
                label1.Text = "Pending Account Registration.";
                dataGridView1.Rows.Clear();
                com = mycn.CreateCommand();
                com.CommandText = " SELECT* from b_pendingacc ORDER BY Acc_ID ASC ";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    dataGridView1.Rows.Add(reader[1].ToString(), reader[3].ToString(), reader[4].ToString(),
                        reader[2].ToString(), reader[5].ToString(), reader[6].ToString(), reader[7].ToString(),
                        reader[8].ToString());
                }
                reader.Close();
                com.ExecuteNonQuery();

                if (label1.Text == "Pending Account Registration.")
                {
                    com.CommandText = "SELECT * FROM b_pendingacc WHERE Acc_ID LIKE '" + IDtb.Text + "'";
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        TypeCB.Text = reader[13].ToString();
                    }
                    reader.Close();
                    com.ExecuteNonQuery();
                }
                mycn.Close();
            }
        }
    }
}
