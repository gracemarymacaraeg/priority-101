﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LMTFBP
{
    public partial class Update : Form
    {
        public Update()
        {
            InitializeComponent();
        }
        private void Close_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Close Tab?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
