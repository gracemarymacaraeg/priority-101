﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace LMTFBP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bunifuTileButton1_Click(object sender, EventArgs e)
        {
            Login ft = new Login();
            ft.label1.Text = "Tricycle Franchise";
            ft.Show();
        }

        private void bunifuTileButton2_Click(object sender, EventArgs e)
        {
            Login bh = new Login();
            bh.label1.Text = "Business Permit";
            bh.Show();
        }
    }
}
