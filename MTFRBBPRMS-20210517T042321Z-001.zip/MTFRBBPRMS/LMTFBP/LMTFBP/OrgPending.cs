﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LMTFBP
{
    public partial class OrgPending : UserControl
    {
        MySqlConnection con = new MySqlConnection("server = localhost; port= 3306; username=root; password= ; database=mtfbp; charset= utf8");
        MySqlCommand com = new MySqlCommand();
        MySqlDataReader reader;
        public OrgPending()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void UpdateToda_Click(object sender, EventArgs e)
        {
            if (label1.Text == "Pending Toda Application")
            {
                todainfo();
            }
            else
            {
                todainfo();
            }
        }
        public void GETmaxID()
        {
            string proID;
            string query = "SELECT Toda_ID FROM t_todainfo ORDER BY Toda_ID desc";

            con.Open();
            MySqlCommand com = new MySqlCommand(query, con);
            MySqlDataReader dr = com.ExecuteReader();

            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                proID = id.ToString("0");
            }
            else if (Convert.IsDBNull(dr))
            {
                proID = ("1");
            }
            else
            {
                proID = ("1");
            }
            con.Close();

            textBox1.Text = proID.ToString();
        }

        private void OrgPending_Load(object sender, EventArgs e)
        {
            if (label1.Text == "Pending Toda Application")
            {
                GETmaxID();
                con.Open();
                com = con.CreateCommand();
                com.CommandText = "SELECT * FROM t_ptodainfo WHERE Toda_ID LIKE '" + textBox2.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    otherAgency.Text = reader[9].ToString();
                    otherLevel.Text = reader[11].ToString();
                    projectTB.Text = reader[13].ToString();
                    costsTB.Text = reader[14].ToString();
                    benefitTB.Text = reader[15].ToString();
                    StatusTB.Text = reader[16].ToString();
                    purposeTB.Text = reader[17].ToString();
                    financingTB.Text = reader[18].ToString();
                    ProvideTB.Text = reader[19].ToString();
                    requirementCB.Text = reader[2].ToString();
                    requirementTB.Text = reader[3].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM t_ptofficers WHERE Toda_ID LIKE '" + textBox2.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    presTB.Text = reader[3].ToString();
                    viceTB.Text = reader[4].ToString();
                    SecretaryTB.Text = reader[5].ToString();
                    treasurerTB.Text = reader[6].ToString();
                    auditorTB.Text = reader[7].ToString();
                    chairmanTB.Text = reader[8].ToString();
                    bm1TB.Text = reader[9].ToString();
                    bm2TB.Text = reader[10].ToString();
                    bm3TB.Text = reader[11].ToString();
                    bm4TB.Text = reader[12].ToString();
                    bm5TB.Text = reader[13].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                GETmaxID();
                con.Open();
                com = con.CreateCommand();
                com.CommandText = "SELECT * FROM t_atodainfo WHERE Toda_ID LIKE '" + textBox2.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    otherAgency.Text = reader[9].ToString();
                    otherLevel.Text = reader[11].ToString();
                    projectTB.Text = reader[13].ToString();
                    costsTB.Text = reader[14].ToString();
                    benefitTB.Text = reader[15].ToString();
                    StatusTB.Text = reader[16].ToString();
                    purposeTB.Text = reader[17].ToString();
                    financingTB.Text = reader[18].ToString();
                    ProvideTB.Text = reader[19].ToString();
                    requirementCB.Text = reader[2].ToString();
                    requirementTB.Text = reader[3].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();

                com.CommandText = "SELECT * FROM t_aofficer WHERE Toda_ID LIKE '" + textBox2.Text + "'";
                reader = com.ExecuteReader();
                while (reader.Read())
                {
                    presTB.Text = reader[3].ToString();
                    viceTB.Text = reader[4].ToString();
                    SecretaryTB.Text = reader[5].ToString();
                    treasurerTB.Text = reader[6].ToString();
                    auditorTB.Text = reader[7].ToString();
                    chairmanTB.Text = reader[8].ToString();
                    bm1TB.Text = reader[9].ToString();
                    bm2TB.Text = reader[10].ToString();
                    bm3TB.Text = reader[11].ToString();
                    bm4TB.Text = reader[12].ToString();
                    bm5TB.Text = reader[13].ToString();
                }
                reader.Close();
                com.ExecuteNonQuery();
                con.Close();
            }

        }
        public void todainfo()
        {
            con.Open();
            com = con.CreateCommand();
            com.CommandText = " INSERT into t_todainfo (Toda_ID, Requirements, ReqList, Toda_name, Address, Contact_No, Date_Org, Register_Agency, Specify_Agency, Org_lvl, Specify_lvl, CY, Project, Costs, Benificiaries, Status, Purpose, Proj_financing, org_provide) VALUES ('" +
                textBox1.Text + "','" + requirementCB.Text + "','" + requirementTB.Text + "','" + oNameTB.Text + "','" + AddressTB.Text + "','" + ContactTB.Text + "','" + DateDTP.Text + "','" + AgencyCB.Text + "','" +
                otherAgency.Text + "','" + LevelCB.Text + "','" + otherLevel.Text + "','" + cyTB.Text + "','" + projectTB.Text + "','" + costsTB.Text + "','" +
                benefitTB.Text + "','" + StatusTB.Text + "','" + purposeTB.Text + "','" + financingTB.Text + "','" + ProvideTB.Text + "')";
            com.ExecuteNonQuery();

            com.CommandText = "INSERT into t_tofficer (Toda_ID,Toda_Name, President, Vice_pres, Secretary, Treasurer, Auditor, Chairman, bMember1, bMember2, bMember3, bMember4, bMember5) VALUES ('" +
                textBox1.Text + "','" + oNameTB.Text + "','" + presTB.Text + "','" + viceTB.Text + "','" + SecretaryTB.Text + "','" + treasurerTB.Text + "','" + auditorTB.Text + "','" + chairmanTB.Text + "','" +
                bm1TB.Text + "','" + bm2TB.Text + "','" + bm3TB.Text + "','" + bm4TB.Text + "','" + bm5TB.Text + "')";
            com.ExecuteNonQuery();
            con.Close();
            delete();
            MessageBox.Show("Information Saved.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            UpdateToda.Enabled = false;
            reset();
        }
        public void reset()
        {
            oNameTB.ResetText();
            AddressTB.ResetText();
            ContactTB.ResetText();
            DateDTP.ResetText();
            otherAgency.ResetText();
            AgencyCB.Items.Clear();
            AgencyCB.Items.Add("Securities and Exchange Commission");
            AgencyCB.Items.Add("Cooperatives Development Authority");
            AgencyCB.Items.Add("Department of Labor and Employment");
            AgencyCB.Items.Add("Department of Social Welfare and Development");
            AgencyCB.Items.Add("Others... (Please Specify)...");
            otherLevel.ResetText();
            LevelCB.Items.Clear();
            LevelCB.Items.Add("Barangay-Based");
            LevelCB.Items.Add("Chapter");
            LevelCB.Items.Add("Affiliate of a Larger Organization");
            LevelCB.Items.Add("Others... (Please Specify)...");
            cyTB.ResetText();
            projectTB.ResetText();
            costsTB.ResetText();
            benefitTB.ResetText();
            StatusTB.ResetText();
            purposeTB.ResetText();
            financingTB.ResetText();
            ProvideTB.ResetText();
            requirementCB.ResetText();
            presTB.ResetText();
            viceTB.ResetText();
            treasurerTB.ResetText();
            SecretaryTB.ResetText();
            auditorTB.ResetText();
            chairmanTB.ResetText();
            bm1TB.ResetText();
            bm2TB.ResetText();
            bm3TB.ResetText();
            bm4TB.ResetText();
            bm5TB.ResetText();
        }

        public void delete()
        {
            if (label1.Text == "Pending Toda Application")
            {
                con.Open();
                com = con.CreateCommand();
                com.CommandText = "DELETE FROM t_ptodainfo WHERE Toda_ID = '" + textBox2.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM t_ptofficers WHERE Toda_ID = '" + textBox2.Text + "'";
                com.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                con.Open();
                com = con.CreateCommand();
                com.CommandText = "DELETE FROM t_atodainfo WHERE Toda_ID = '" + textBox2.Text + "'";
                com.ExecuteNonQuery();

                com.CommandText = "DELETE FROM t_aofficer WHERE Toda_ID = '" + textBox2.Text + "'";
                com.ExecuteNonQuery();
                con.Close();
            }
        }

        private void requirementCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (requirementCB.Text == "Complete")
            {
                requirementTB.Clear();
                requirementTB.Enabled = false;
            }
        }
    }
}
